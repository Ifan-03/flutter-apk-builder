import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "50mb" }));

  // Health check endpoint
  app.get("/api/health", (_req, res) => {
    res.json({
      status: "ok",
      hasAiKey: Boolean(process.env.GEMINI_API_KEY),
    });
  });

  // AI-powered intelligent number extraction endpoint
  app.post("/api/ai-extract", async (req, res) => {
    try {
      const { text, filename, options } = req.body;
      if (!text || typeof text !== "string") {
        return res.status(400).json({ error: "Teks dokumen diperlukan" });
      }

      const ai = getGeminiClient();
      if (!ai) {
        return res.status(503).json({
          error: "GEMINI_API_KEY tidak dikonfigurasi pada server.",
        });
      }

      const truncatedText = text.slice(0, 30000); // safety boundary for large documents

      const prompt = `Anda adalah asisten data extraction profesional khusus mengekstrak semua nomor dan entitas terkait dari dokumen PDF berikut.
Dokumen: "${filename || "Dokumen PDF"}"
Teks:
${truncatedText}

Tugas:
1. Temukan dan ekstrak SEMUA nomor penting:
   - Nomor Telepon / HP / WhatsApp (Format asli & format bersih misal 628xxx)
   - Nomor Invoice / Kwitansi / Faktur Pajak / Surat Jalan / Resi / PO / No Pesanan
   - Nomor KTP / NIK / NPWP / BPJS / Paspor / SIM / ID Identitas
   - Nomor Rekening Bank / Virtual Account (BCA, Mandiri, BRI, BNI, dll.)
   - Nominal Keuangan / Total Harga / Subtotal (misal Rp 1.500.000)
   - Nomor Seri / Kode Produk / Barcode / Tracking
   - Nomor Urut / Jumlah Item / Angka Kunci lainnya

2. Untuk setiap nomor, identifikasi label (misal "No. WhatsApp", "No. Rekening BCA", "Total Tagihan"), nama entitas / pemilik jika ada (misal "Budi Santoso", "PT Sumber Makmur"), nilai asli, nilai ternormalisasi (hanya angka / format standar internasional), serta konteks singkat (10-20 kata di sekitar angka).`;

      const response = await ai.models.generateContent({
        model: "gemini-3.7-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              summary: {
                type: Type.STRING,
                description: "Ringkasan singkat isi dokumen dan nomor yang ditemukan",
              },
              items: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    rawNumber: {
                      type: Type.STRING,
                      description: "Nomor atau angka persis seperti yang tertulis di teks",
                    },
                    normalizedNumber: {
                      type: Type.STRING,
                      description: "Nomor yang sudah dibersihkan/distandarkan (misal format 62812xxx untuk WA, atau angka murni)",
                    },
                    category: {
                      type: Type.STRING,
                      description: "Kategori: 'phone', 'invoice', 'id_card', 'bank_account', 'currency', 'serial_sku', 'other'",
                    },
                    label: {
                      type: Type.STRING,
                      description: "Label field atau deskripsi (misal: 'No. HP Pelanggan', 'Invoice Number', 'NIK', 'Total Pembayaran')",
                    },
                    entityName: {
                      type: Type.STRING,
                      description: "Nama orang/perusahaan/bank terkait nomor ini jika tertera",
                    },
                    context: {
                      type: Type.STRING,
                      description: "Kutipan kalimat atau frasa tempat nomor ini berada",
                    },
                    confidence: {
                      type: Type.NUMBER,
                      description: "Skor keyakinan 0.0 sampai 1.0",
                    },
                  },
                  required: ["rawNumber", "category", "label"],
                },
              },
            },
            required: ["items"],
          },
        },
      });

      const rawJson = response.text ? response.text.trim() : "{}";
      const parsedData = JSON.parse(rawJson);
      return res.json({
        success: true,
        data: parsedData,
      });
    } catch (err: any) {
      console.error("AI Extraction Error:", err);
      return res.status(500).json({
        error: err.message || "Gagal melakukan ekstraksi AI",
      });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
