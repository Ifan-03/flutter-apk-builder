import React, { useState } from 'react';
import { 
  X, 
  Mail, 
  Lock, 
  Eye, 
  EyeOff, 
  ArrowRight, 
  ShieldCheck, 
  Sparkles, 
  FileSpreadsheet,
  CheckCircle2
} from 'lucide-react';

interface LoginPageModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess?: (email: string) => void;
}

export const LoginPageModal: React.FC<LoginPageModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!email || !password) {
      setErrorMessage('Mohon isi alamat email dan kata sandi Anda.');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      if (onLoginSuccess) {
        onLoginSuccess(email);
      }
      onClose();
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      {/* Main Container */}
      <div 
        id="login-modal-card"
        className="relative bg-white rounded-3xl shadow-2xl border border-slate-100 max-w-4xl w-full overflow-hidden flex flex-col lg:flex-row min-h-[580px] animate-in zoom-in-95 duration-200"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-slate-100/80 hover:bg-slate-200 text-slate-600 transition-colors cursor-pointer"
          title="Tutup Modal"
        >
          <X className="w-4 h-4" />
        </button>

        {/* LEFT SECTION: Login Form */}
        <div className="w-full lg:w-7/12 p-6 sm:p-10 flex flex-col justify-between bg-white">
          <div>
            {/* Logo */}
            <div className="flex items-center gap-2.5 mb-6">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-slate-900 to-indigo-950 flex items-center justify-center text-white shadow-md">
                <FileSpreadsheet className="w-5 h-5 text-indigo-300" />
              </div>
              <div>
                <span className="text-base font-bold text-slate-900 tracking-tight block">
                  DataExtractor<span className="text-indigo-600">.io</span>
                </span>
                <span className="text-[11px] font-medium text-slate-400 block -mt-0.5">
                  Platform Analitik & Ekstraksi PDF
                </span>
              </div>
            </div>

            {/* Title & Subtitle */}
            <div className="mb-6">
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                Selamat Datang Kembali
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-1.5">
                Masukkan email dan kata sandi Anda untuk mengakses akun.
              </p>
            </div>

            {/* Error Message */}
            {errorMessage && (
              <div className="mb-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium flex items-center gap-2">
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Input Email */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Alamat Email
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    type="email"
                    id="input-login-email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="nama@perusahaan.com"
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-slate-900 focus:bg-white transition-all"
                  />
                </div>
              </div>

              {/* Input Password */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-semibold text-slate-700">
                    Kata Sandi
                  </label>
                  <a
                    href="#forgot-password"
                    onClick={(e) => {
                      e.preventDefault();
                      alert('Tautan pemulihan kata sandi telah dikirim ke email Anda.');
                    }}
                    className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 hover:underline transition-colors"
                  >
                    Lupa Kata Sandi?
                  </a>
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    id="input-login-password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-10 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-slate-900 focus:bg-white transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-700 cursor-pointer"
                    title={showPassword ? 'Sembunyikan kata sandi' : 'Tampilkan kata sandi'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Remember Me Checkbox */}
              <div className="flex items-center">
                <input
                  id="remember-me"
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 text-slate-900 bg-slate-50 border-slate-300 rounded focus:ring-slate-900 focus:ring-2 cursor-pointer"
                />
                <label htmlFor="remember-me" className="ml-2 text-xs text-slate-600 cursor-pointer select-none">
                  Ingat saya di perangkat ini
                </label>
              </div>

              {/* Elegant Dark Blue Submit Button */}
              <button
                type="submit"
                id="btn-submit-login"
                disabled={isLoading}
                className="w-full mt-2 py-3 px-4 bg-slate-900 hover:bg-slate-800 active:bg-slate-950 text-white font-semibold text-sm rounded-xl shadow-lg shadow-slate-900/10 transition-all duration-150 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
              >
                {isLoading ? (
                  <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                ) : (
                  <>
                    <span>Masuk ke Akun</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Bottom Register Footer */}
          <div className="mt-6 pt-4 border-t border-slate-100 text-center text-xs text-slate-500">
            Belum memiliki akun?{' '}
            <a
              href="#register"
              onClick={(e) => {
                e.preventDefault();
                alert('Pendaftaran akun baru dapat dilakukan melalui tim administrator.');
              }}
              className="font-semibold text-slate-900 hover:text-indigo-600 hover:underline transition-colors"
            >
              Daftar sekarang
            </a>
          </div>
        </div>

        {/* RIGHT SECTION: Aesthetic Blue-to-Purple Gradient Showcase (Hidden on Mobile) */}
        <div className="hidden lg:flex lg:w-5/12 bg-gradient-to-br from-blue-700 via-indigo-600 to-purple-800 p-8 flex-col justify-between text-white relative overflow-hidden">
          {/* Subtle Ambient Background Glowing Blobs */}
          <div className="absolute -top-20 -right-20 w-64 h-64 bg-purple-500/30 rounded-full blur-3xl pointer-events-none"></div>
          <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-blue-400/30 rounded-full blur-3xl pointer-events-none"></div>

          {/* Top Brand Pill */}
          <div className="relative z-10 flex items-center gap-2">
            <span className="px-3 py-1 bg-white/15 backdrop-blur-md rounded-full text-[11px] font-semibold text-white/90 border border-white/20 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" /> Versi Enterprise v2.4
            </span>
          </div>

          {/* Center Graphic / Value Props Card */}
          <div className="relative z-10 my-auto py-6">
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-5 shadow-2xl space-y-3.5">
              <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-white">
                <ShieldCheck className="w-5 h-5 text-emerald-300" />
              </div>
              <h3 className="text-lg font-bold text-white leading-snug">
                Ekstraksi Nomor & Dokumen Cerdas Berbasis AI
              </h3>
              <p className="text-xs text-blue-100 leading-relaxed">
                Otomatisasi pengolahan faktur, invoice, rekening bank, dan NIK dari file PDF dalam hitungan detik.
              </p>

              <div className="pt-2 border-t border-white/10 space-y-1.5 text-[11px] text-blue-50">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Akurasi ekstraksi hingga 99.8%</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Enkripsi data & privasi lokal terjamin</span>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Testimonial / Security Footer */}
          <div className="relative z-10 text-[11px] text-blue-200/80 flex items-center justify-between">
            <span>© 2026 DataExtractor System</span>
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> 256-Bit SSL
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
