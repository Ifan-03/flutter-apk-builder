import React, { useRef, useState } from 'react';
import { 
  UploadCloud, 
  FileText, 
  Trash2, 
  CheckCircle2, 
  AlertCircle, 
  Loader2, 
  Plus, 
  Sparkles,
  BookOpen,
  PenLine,
  Check,
  X
} from 'lucide-react';
import { PdfFileInfo } from '../types';

interface FileUploaderProps {
  files: PdfFileInfo[];
  isProcessing: boolean;
  onFilesSelected: (files: FileList | File[]) => void;
  onRemoveFile: (fileId: string) => void;
  onClearAll: () => void;
  onLoadSample: (type: 'invoice' | 'contacts') => void;
  onViewPdfText: (file: PdfFileInfo) => void;
  onOpenBatchRename: () => void;
  onRenameSingleFile: (fileId: string, newName: string) => void;
}

export const FileUploader: React.FC<FileUploaderProps> = ({
  files,
  isProcessing,
  onFilesSelected,
  onRemoveFile,
  onClearAll,
  onLoadSample,
  onViewPdfText,
  onOpenBatchRename,
  onRenameSingleFile,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [editingFileId, setEditingFileId] = useState<string | null>(null);
  const [editingFileName, setEditingFileName] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleStartEdit = (file: PdfFileInfo, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setEditingFileId(file.id);
    setEditingFileName(file.name);
  };

  const handleSaveEdit = (fileId: string) => {
    if (editingFileName.trim()) {
      onRenameSingleFile(fileId, editingFileName.trim());
    }
    setEditingFileId(null);
  };

  const handleCancelEdit = () => {
    setEditingFileId(null);
  };

  const handleKeyDown = (e: React.KeyboardEvent, fileId: string) => {
    if (e.key === 'Enter') {
      handleSaveEdit(fileId);
    } else if (e.key === 'Escape') {
      handleCancelEdit();
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const pdfs = (Array.from(e.dataTransfer.files) as File[]).filter(
        (f: File) => f.type === 'application/pdf' || f.name.toLowerCase().endsWith('.pdf')
      );
      if (pdfs.length > 0) {
        onFilesSelected(pdfs);
      } else {
        alert('Mohon pilih file dengan format .PDF saja.');
      }
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onFilesSelected(e.target.files);
      e.target.value = '';
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  return (
    <section id="pdf-uploader-section" className="bg-white rounded-2xl border border-slate-200 p-6 transition-all">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <div>
          <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
            Upload Source
          </label>
          <h2 className="text-base font-semibold text-slate-900 flex items-center gap-2">
            <span>Dokumen PDF Sumber</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Unggah satu atau banyak file PDF untuk diekstrak nomornya secara otomatis.
          </p>
        </div>

        {files.length > 0 && (
          <div className="flex flex-wrap items-center gap-2">
            <button
              id="btn-batch-rename-pdf"
              onClick={onOpenBatchRename}
              disabled={isProcessing}
              title="Ganti nama file PDF sekaligus (prefix, suffix, cari & ganti, penomoran)"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 hover:text-indigo-700 bg-slate-50 hover:bg-indigo-50/80 rounded-lg border border-slate-200 hover:border-indigo-200 transition-colors disabled:opacity-50 cursor-pointer shadow-2xs"
            >
              <PenLine className="w-3.5 h-3.5 text-indigo-600" />
              <span>Ganti Nama Massal</span>
            </button>
            <button
              id="btn-add-more-pdf"
              onClick={() => fileInputRef.current?.click()}
              disabled={isProcessing}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg border border-indigo-100 transition-colors disabled:opacity-50 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Tambah PDF</span>
            </button>
            <button
              id="btn-clear-all-pdf"
              onClick={onClearAll}
              disabled={isProcessing}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-rose-600 bg-slate-50 hover:bg-rose-50 rounded-lg border border-slate-200 transition-colors disabled:opacity-50 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Hapus Semua</span>
            </button>
          </div>
        )}
      </div>

      {/* Hidden File Input */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept=".pdf,application/pdf"
        className="hidden"
        onChange={handleInputChange}
      />

      {/* Drop Zone Area */}
      {files.length === 0 ? (
        <div
          id="dropzone-area"
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-xl p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-all duration-200 ${
            isDragging
              ? 'border-indigo-600 bg-indigo-50/40 scale-[0.99]'
              : 'border-slate-200 bg-slate-50/60 hover:bg-slate-50 hover:border-slate-300'
          }`}
        >
          <div className="w-12 h-12 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center mb-3">
            <UploadCloud className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-medium text-slate-800">
            Tarik & Lepas PDF ke Sini, atau <span className="text-indigo-600 font-semibold underline">Pilih File</span>
          </h3>
          <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
            Mendukung file invoice, rekening koran, formulir, daftar kontak, resi, hingga 50MB (bisa multi-dokumen sekaligus)
          </p>

          {/* Quick Demo Templates */}
          <div className="mt-5 pt-4 border-t border-slate-200/70 flex flex-wrap items-center justify-center gap-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mr-1 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-indigo-500" /> Contoh Demo:
            </span>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onLoadSample('invoice');
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-white hover:bg-slate-100 text-slate-700 rounded-lg border border-slate-200 shadow-2xs transition-colors"
            >
              <FileText className="w-3.5 h-3.5 text-indigo-600" />
              <span>Sample Invoice & Rekening Bank</span>
            </button>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onLoadSample('contacts');
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-white hover:bg-slate-100 text-slate-700 rounded-lg border border-slate-200 shadow-2xs transition-colors"
            >
              <FileText className="w-3.5 h-3.5 text-indigo-600" />
              <span>Sample Direktori 12 Kontak WA & NIK</span>
            </button>
          </div>
        </div>
      ) : (
        /* Uploaded Files Grid */
        <div className="space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {files.map((file) => {
              const isEditingThis = editingFileId === file.id;

              return (
                <div
                  key={file.id}
                  id={`file-card-${file.id}`}
                  className="bg-slate-50/60 hover:bg-slate-50 border border-slate-200 rounded-xl p-3.5 flex flex-col justify-between gap-2.5 relative group transition-all"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-2.5 min-w-0 flex-1">
                      <div className="w-8 h-8 shrink-0 rounded bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold text-[11px] mt-0.5">
                        PDF
                      </div>
                      
                      <div className="min-w-0 flex-1">
                        {isEditingThis ? (
                          <div className="flex items-center gap-1">
                            <input
                              type="text"
                              value={editingFileName}
                              onChange={(e) => setEditingFileName(e.target.value)}
                              onKeyDown={(e) => handleKeyDown(e, file.id)}
                              autoFocus
                              className="w-full px-2 py-0.5 text-xs font-medium text-slate-900 bg-white border border-indigo-500 rounded outline-hidden"
                            />
                            <button
                              onClick={() => handleSaveEdit(file.id)}
                              className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
                              title="Simpan nama"
                            >
                              <Check className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={handleCancelEdit}
                              className="p-1 text-slate-400 hover:bg-slate-200 rounded"
                              title="Batal"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1.5 group/name">
                            <p 
                              className="text-xs font-medium text-slate-900 truncate" 
                              title={file.name}
                            >
                              {file.name}
                            </p>
                            <button
                              onClick={(e) => handleStartEdit(file, e)}
                              className="opacity-0 group-hover:opacity-100 group-hover/name:opacity-100 p-0.5 text-slate-400 hover:text-indigo-600 rounded transition-opacity"
                              title="Ubah nama file"
                            >
                              <PenLine className="w-3 h-3" />
                            </button>
                          </div>
                        )}
                        <p className="text-[11px] text-slate-400 font-mono mt-0.5">
                          {formatFileSize(file.size)} • {file.totalPages > 0 ? `${file.totalPages} Hal.` : 'Memproses...'}
                        </p>
                      </div>
                    </div>

                    {!isEditingThis && (
                      <button
                        onClick={() => onRemoveFile(file.id)}
                        title="Hapus file ini"
                        className="text-slate-400 hover:text-rose-600 p-1 rounded hover:bg-rose-50 transition-colors shrink-0"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-200/60 text-xs">
                    {file.status === 'completed' && (
                      <div className="flex items-center gap-1.5 text-indigo-700 font-medium">
                        <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600" />
                        <span className="font-mono">{file.extractedCount} nomor</span>
                      </div>
                    )}

                    {file.status === 'parsing' && (
                      <div className="flex items-center gap-1.5 text-slate-600 font-medium">
                        <Loader2 className="w-3.5 h-3.5 animate-spin text-indigo-600" />
                        <span>Mengekstrak...</span>
                      </div>
                    )}

                    {file.status === 'error' && (
                      <div className="flex items-center gap-1.5 text-rose-700 font-medium">
                        <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
                        <span className="truncate max-w-[150px]">{file.error || 'Gagal'}</span>
                      </div>
                    )}

                    <button
                      onClick={() => onViewPdfText(file)}
                      className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-500 hover:text-indigo-600 cursor-pointer"
                      title="Lihat teks halaman dan metadata dokumen PDF"
                    >
                      <BookOpen className="w-3 h-3" />
                      <span>Lihat Detail & Teks</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Add more files drop hint */}
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border border-dashed rounded-xl p-2.5 text-center cursor-pointer transition-colors text-xs text-slate-500 font-medium ${
              isDragging ? 'border-indigo-600 bg-indigo-50/40' : 'border-slate-200 hover:border-indigo-300 hover:bg-slate-50'
            }`}
          >
            + Tarik file PDF tambahan ke sini atau <span className="text-indigo-600 font-semibold underline">klik untuk menambah</span>
          </div>
        </div>
      )}
    </section>
  );
};

