import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  X,
  Copy,
  Check,
  ChevronLeft,
  ChevronRight,
  FileText,
  Info,
  User,
  Search,
  Sparkles,
  ExternalLink,
  MessageSquare,
  AlertCircle,
  AlertTriangle,
  ZoomIn,
  ZoomOut,
  Layers,
  LayoutGrid,
  PanelLeftClose,
  PanelLeftOpen,
  Filter,
  Eye,
  Crosshair,
  FileSpreadsheet,
  RotateCw
} from 'lucide-react';
import { PdfFileInfo, ExtractedNumber, NumberCategory } from '../types';
import { PdfMetadataViewer } from './PdfMetadataViewer';

interface PdfViewerModalProps {
  file: PdfFileInfo | null;
  initialPage?: number;
  highlightText?: string;
  highlightItem?: ExtractedNumber | null;
  extractedNumbers?: ExtractedNumber[];
  onClose: () => void;
}

const CATEGORY_STYLES: Record<
  NumberCategory,
  {
    bg: string;
    text: string;
    border: string;
    hoverBg: string;
    ring: string;
    label: string;
    dotBg: string;
  }
> = {
  phone: {
    bg: 'bg-emerald-100',
    text: 'text-emerald-900',
    border: 'border-emerald-300',
    hoverBg: 'hover:bg-emerald-200',
    ring: 'ring-emerald-400',
    label: 'No. Telepon',
    dotBg: 'bg-emerald-500',
  },
  invoice: {
    bg: 'bg-blue-100',
    text: 'text-blue-900',
    border: 'border-blue-300',
    hoverBg: 'hover:bg-blue-200',
    ring: 'ring-blue-400',
    label: 'Invoice/PO',
    dotBg: 'bg-blue-500',
  },
  id_card: {
    bg: 'bg-amber-100',
    text: 'text-amber-900',
    border: 'border-amber-300',
    hoverBg: 'hover:bg-amber-200',
    ring: 'ring-amber-400',
    label: 'NIK / NPWP',
    dotBg: 'bg-amber-500',
  },
  bank_account: {
    bg: 'bg-purple-100',
    text: 'text-purple-900',
    border: 'border-purple-300',
    hoverBg: 'hover:bg-purple-200',
    ring: 'ring-purple-400',
    label: 'Rekening Bank',
    dotBg: 'bg-purple-500',
  },
  currency: {
    bg: 'bg-cyan-100',
    text: 'text-cyan-900',
    border: 'border-cyan-300',
    hoverBg: 'hover:bg-cyan-200',
    ring: 'ring-cyan-400',
    label: 'Nominal / Harga',
    dotBg: 'bg-cyan-500',
  },
  serial_sku: {
    bg: 'bg-indigo-100',
    text: 'text-indigo-900',
    border: 'border-indigo-300',
    hoverBg: 'hover:bg-indigo-200',
    ring: 'ring-indigo-400',
    label: 'Serial / SKU',
    dotBg: 'bg-indigo-500',
  },
  date_time: {
    bg: 'bg-teal-100',
    text: 'text-teal-900',
    border: 'border-teal-300',
    hoverBg: 'hover:bg-teal-200',
    ring: 'ring-teal-400',
    label: 'Tanggal/Waktu',
    dotBg: 'bg-teal-500',
  },
  custom: {
    bg: 'bg-rose-100',
    text: 'text-rose-900',
    border: 'border-rose-300',
    hoverBg: 'hover:bg-rose-200',
    ring: 'ring-rose-400',
    label: 'Custom Regex',
    dotBg: 'bg-rose-500',
  },
  other: {
    bg: 'bg-slate-100',
    text: 'text-slate-800',
    border: 'border-slate-300',
    hoverBg: 'hover:bg-slate-200',
    ring: 'ring-slate-400',
    label: 'Nomor Lainnya',
    dotBg: 'bg-slate-500',
  },
};

export const PdfViewerModal: React.FC<PdfViewerModalProps> = ({
  file,
  initialPage = 1,
  highlightText,
  highlightItem,
  extractedNumbers = [],
  onClose,
}) => {
  const [currentPage, setCurrentPage] = useState(initialPage);
  const [showThumbnails, setShowThumbnails] = useState(true);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'preview' | 'metadata'>('preview');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [textSize, setTextSize] = useState<'sm' | 'base' | 'lg'>('sm');
  const [rotation, setRotation] = useState(0);
  const [focusedItemId, setFocusedItemId] = useState<string | null>(highlightItem?.id || null);
  const [hoveredNumberItem, setHoveredNumberItem] = useState<ExtractedNumber | null>(null);
  const [showBottomList, setShowBottomList] = useState(true);

  const textContainerRef = useRef<HTMLDivElement>(null);

  // Sync initialPage when it changes
  useEffect(() => {
    if (initialPage && initialPage >= 1) {
      setCurrentPage(initialPage);
    }
  }, [initialPage]);

  // Sync initial highlightItem
  useEffect(() => {
    if (highlightItem) {
      setFocusedItemId(highlightItem.id);
      setCurrentPage(highlightItem.pageNumber);
    }
  }, [highlightItem]);

  if (!file) return null;

  const totalPages = file.pages.length || 1;
  const activePageData = file.pages.find((p) => p.pageNumber === currentPage) || file.pages[0];
  const pageText = activePageData ? activePageData.text : 'Tidak ada teks';
  const meta = file.metadata;

  // Group extracted numbers by page
  const numbersByPage = useMemo(() => {
    const map = new Map<number, ExtractedNumber[]>();
    for (let p = 1; p <= totalPages; p++) {
      map.set(p, []);
    }
    extractedNumbers.forEach((item) => {
      const pNum = item.pageNumber || 1;
      const list = map.get(pNum) || [];
      list.push(item);
      map.set(pNum, list);
    });
    return map;
  }, [extractedNumbers, totalPages]);

  // Extracted numbers for the current active page
  const activePageNumbers = useMemo(() => {
    return numbersByPage.get(currentPage) || [];
  }, [numbersByPage, currentPage]);

  // Filtered active page numbers based on category filter
  const filteredActivePageNumbers = useMemo(() => {
    if (selectedCategoryFilter === 'all') return activePageNumbers;
    return activePageNumbers.filter((n) => n.category === selectedCategoryFilter);
  }, [activePageNumbers, selectedCategoryFilter]);

  // Copy full page text
  const handleCopyPage = () => {
    navigator.clipboard.writeText(pageText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Scroll to focused number in text view
  const scrollToItem = (itemId: string, rawText?: string) => {
    setFocusedItemId(itemId);
    const element = document.getElementById(`highlight-item-${itemId}`);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  // Render text with interactive highlights
  const renderHighlightedContent = () => {
    if (!pageText) return <p className="text-slate-400 italic">Halaman ini kosong.</p>;

    if (filteredActivePageNumbers.length === 0 && !searchQuery.trim()) {
      return <span>{pageText}</span>;
    }

    // Build occurrence spans sorted by startIndex
    interface HighlightRange {
      start: number;
      end: number;
      item?: ExtractedNumber;
      isSearchMatch?: boolean;
      rawMatchText: string;
    }

    const ranges: HighlightRange[] = [];

    // 1. Add extracted number ranges
    filteredActivePageNumbers.forEach((item) => {
      if (!item.rawNumber) return;
      let startIndex = 0;
      while ((startIndex = pageText.indexOf(item.rawNumber, startIndex)) !== -1) {
        ranges.push({
          start: startIndex,
          end: startIndex + item.rawNumber.length,
          item,
          rawMatchText: item.rawNumber,
        });
        startIndex += item.rawNumber.length;
      }
    });

    // 2. Add search query ranges if provided
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const lowerText = pageText.toLowerCase();
      let sIdx = 0;
      while ((sIdx = lowerText.indexOf(q, sIdx)) !== -1) {
        ranges.push({
          start: sIdx,
          end: sIdx + searchQuery.length,
          isSearchMatch: true,
          rawMatchText: pageText.slice(sIdx, sIdx + searchQuery.length),
        });
        sIdx += searchQuery.length;
      }
    }

    // Sort ranges by start position
    ranges.sort((a, b) => a.start - b.start);

    // Filter out overlapping ranges
    const nonOverlappingRanges: HighlightRange[] = [];
    let lastEnd = 0;
    ranges.forEach((r) => {
      if (r.start >= lastEnd) {
        nonOverlappingRanges.push(r);
        lastEnd = r.end;
      }
    });

    // Build segments
    const elements: React.ReactNode[] = [];
    let currentIndex = 0;

    nonOverlappingRanges.forEach((range, idx) => {
      // Add preceding plain text
      if (range.start > currentIndex) {
        elements.push(
          <span key={`plain-${currentIndex}`}>
            {pageText.substring(currentIndex, range.start)}
          </span>
        );
      }

      const matchText = pageText.substring(range.start, range.end);
      const isFocused = range.item && focusedItemId === range.item.id;
      const isSearch = range.isSearchMatch;
      const categoryStyle = range.item ? CATEGORY_STYLES[range.item.category] || CATEGORY_STYLES.other : null;

      if (isSearch) {
        elements.push(
          <mark
            key={`search-${idx}-${range.start}`}
            className="bg-yellow-300 text-slate-900 font-bold px-1 rounded shadow-2xs"
          >
            {matchText}
          </mark>
        );
      } else if (range.item && categoryStyle) {
        elements.push(
          <span
            key={`highlight-${range.item.id}-${idx}`}
            id={`highlight-item-${range.item.id}`}
            onClick={() => setFocusedItemId(range.item!.id)}
            onMouseEnter={() => setHoveredNumberItem(range.item!)}
            onMouseLeave={() => setHoveredNumberItem(null)}
            className={`inline-flex items-center gap-1 mx-0.5 px-1.5 py-0.5 rounded font-mono text-xs font-semibold border transition-all cursor-pointer select-text ${
              categoryStyle.bg
            } ${categoryStyle.text} ${categoryStyle.border} ${categoryStyle.hoverBg} ${
              isFocused
                ? `ring-2 ring-indigo-600 font-extrabold shadow-md scale-105 ${categoryStyle.ring} bg-amber-200 text-amber-950 border-amber-400`
                : ''
            }`}
            title={`Klik untuk detail: [${categoryStyle.label}] ${range.item.label}`}
          >
            <span className={`w-1.5 h-1.5 rounded-full ${categoryStyle.dotBg}`}></span>
            <span>{matchText}</span>
          </span>
        );
      }

      currentIndex = range.end;
    });

    // Add trailing text
    if (currentIndex < pageText.length) {
      elements.push(
        <span key={`plain-end-${currentIndex}`}>{pageText.substring(currentIndex)}</span>
      );
    }

    return elements;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        id="pdf-viewer-modal-card"
        className="bg-white rounded-3xl border border-slate-200 max-w-6xl w-full overflow-hidden flex flex-col h-[92vh] shadow-2xl animate-in zoom-in-95 duration-150"
      >
        {/* ======================================================== */}
        {/* TOP HEADER: File Information & View Tabs */}
        {/* ======================================================== */}
        <header className="px-5 py-3.5 border-b border-slate-200 bg-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-slate-900 to-indigo-950 text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-md">
              <FileSpreadsheet className="w-5 h-5 text-indigo-300" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-100">
                  Pratinjau Dokumen PDF
                </span>
                <span className="text-xs text-slate-400 font-medium">
                  {totalPages} Halaman • {extractedNumbers.length} Nomor Terdeteksi
                </span>
              </div>
              <h2 className="text-sm sm:text-base font-bold text-slate-900 truncate mt-0.5" title={file.name}>
                {file.name}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* View Selection Tabs */}
            <div className="hidden sm:flex items-center bg-slate-100 p-0.5 rounded-xl border border-slate-200">
              <button
                type="button"
                id="btn-tab-preview-doc"
                onClick={() => setActiveTab('preview')}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  activeTab === 'preview'
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                <FileText className="w-3.5 h-3.5 text-indigo-600" />
                <span>Dokumen & Lokasi Nomor</span>
              </button>

              <button
                type="button"
                id="btn-tab-metadata-doc"
                onClick={() => setActiveTab('metadata')}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  activeTab === 'metadata'
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                <Info className="w-3.5 h-3.5 text-emerald-600" />
                <span>Metadata & Properti</span>
              </button>
            </div>

            {/* Close Button */}
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-slate-700 p-2 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer"
              title="Tutup Modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </header>

        {/* ======================================================== */}
        {/* TAB 1: PREVIEW DOKUMEN & THUMBNAIL PANEL */}
        {/* ======================================================== */}
        {activeTab === 'preview' ? (
          <div className="flex-1 flex overflow-hidden bg-slate-100">
            {/* ==================================================== */}
            {/* LEFT SIDE PANEL: THUMBNAILS LIST */}
            {/* ==================================================== */}
            <aside
              className={`${
                showThumbnails ? 'w-64 sm:w-72' : 'w-0 hidden'
              } bg-white border-r border-slate-200 flex flex-col shrink-0 transition-all duration-200 z-10`}
            >
              {/* Thumbnail Panel Header */}
              <div className="p-3.5 border-b border-slate-100 bg-slate-50/70 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <LayoutGrid className="w-4 h-4 text-indigo-600" />
                  <span className="text-xs font-bold text-slate-800">
                    Thumbnail Halaman ({totalPages})
                  </span>
                </div>
                <span className="text-[10px] font-semibold text-slate-400 bg-white px-2 py-0.5 rounded border border-slate-200">
                  Navigasi Visual
                </span>
              </div>

              {/* File Metadata Summary */}
              <div className="px-4 py-3 border-b border-slate-200 bg-slate-50/40 flex flex-col gap-2">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-semibold text-slate-500">Ukuran File</span>
                  <span className="font-mono font-medium text-slate-700">{(file.size / 1024).toFixed(1)} KB</span>
                </div>
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-semibold text-slate-500">Total Halaman</span>
                  <span className="font-mono font-medium text-slate-700">{totalPages}</span>
                </div>
                {meta?.creationDate && (
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-semibold text-slate-500">Dibuat</span>
                    <span className="font-mono font-medium text-slate-700 truncate max-w-[120px]" title={meta.creationDate}>
                      {meta.creationDate.replace(/^D:/, '')}
                    </span>
                  </div>
                )}
              </div>

              {/* Thumbnail Items Scroll Area */}
              <div className="flex-1 overflow-y-auto p-3 space-y-3">
                {file.pages.map((p) => {
                  const pageNums = numbersByPage.get(p.pageNumber) || [];
                  const isActive = currentPage === p.pageNumber;
                  const snippetLines = p.text
                    .split('\n')
                    .map((l) => l.trim())
                    .filter(Boolean)
                    .slice(0, 5);

                  const hasPhone = pageNums.some((n) => n.category === 'phone');
                  const hasInvoice = pageNums.some((n) => n.category === 'invoice');
                  const hasBank = pageNums.some((n) => n.category === 'bank_account');
                  const hasNik = pageNums.some((n) => n.category === 'id_card');

                  return (
                    <button
                      key={`thumb-page-${p.pageNumber}`}
                      type="button"
                      onClick={() => setCurrentPage(p.pageNumber)}
                      className={`w-full text-left rounded-2xl border p-2.5 transition-all cursor-pointer flex flex-col gap-2 ${
                        isActive
                          ? 'bg-indigo-50/60 border-indigo-600 ring-2 ring-indigo-500/20 shadow-md'
                          : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/80 shadow-2xs'
                      }`}
                    >
                      {/* Top Header of Thumbnail */}
                      <div className="flex items-center justify-between">
                        <span
                          className={`text-xs font-bold px-2 py-0.5 rounded-lg ${
                            isActive
                              ? 'bg-indigo-600 text-white shadow-2xs'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          Halaman {p.pageNumber}
                        </span>

                        {pageNums.length > 0 ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                            <Sparkles className="w-3 h-3 text-emerald-600" />
                            {pageNums.length} Nomor
                          </span>
                        ) : (
                          <span className="text-[10px] text-slate-400 font-medium">
                            0 Nomor
                          </span>
                        )}
                      </div>

                      {/* Miniature Visual Layout Skeleton (Simulates the PDF page) */}
                      <div className="w-full bg-slate-50 border border-slate-200/80 rounded-xl p-2 h-24 overflow-hidden relative select-none flex flex-col justify-between">
                        <div className="space-y-1.5 opacity-70">
                          {snippetLines.length > 0 ? (
                            snippetLines.map((line, lIdx) => (
                              <div
                                key={lIdx}
                                className="text-[9px] font-mono text-slate-500 truncate leading-tight tracking-tight"
                              >
                                {line}
                              </div>
                            ))
                          ) : (
                            <div className="text-[9px] text-slate-400 italic">
                              Halaman Kosong
                            </div>
                          )}
                        </div>

                        {/* Visual Marker Badges at bottom of miniature card */}
                        {pageNums.length > 0 && (
                          <div className="pt-1.5 border-t border-slate-200/60 flex items-center gap-1 flex-wrap">
                            {hasPhone && (
                              <span className="w-2 h-2 rounded-full bg-emerald-500" title="Ada No. Telepon" />
                            )}
                            {hasInvoice && (
                              <span className="w-2 h-2 rounded-full bg-blue-500" title="Ada Invoice" />
                            )}
                            {hasBank && (
                              <span className="w-2 h-2 rounded-full bg-purple-500" title="Ada Rekening" />
                            )}
                            {hasNik && (
                              <span className="w-2 h-2 rounded-full bg-amber-500" title="Ada NIK" />
                            )}
                            <span className="text-[9px] font-bold text-slate-600 ml-auto">
                              {p.text.length} chars
                            </span>
                          </div>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </aside>

            {/* ==================================================== */}
            {/* RIGHT MAIN VIEWPORT: DOCUMENT TEXT & VERIFICATION */}
            {/* ==================================================== */}
            <section className="flex-1 flex flex-col overflow-hidden bg-slate-50">
              
              {/* Secondary Navigation & Verification Toolbar */}
              <div className="px-4 py-2.5 bg-white border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 shrink-0">
                {/* Left Controls: Sidebar toggle & Page switcher */}
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowThumbnails(!showThumbnails)}
                    className="p-1.5 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 transition-colors cursor-pointer"
                    title={showThumbnails ? 'Sembunyikan Thumbnail' : 'Tampilkan Thumbnail'}
                  >
                    {showThumbnails ? (
                      <PanelLeftClose className="w-4 h-4 text-indigo-600" />
                    ) : (
                      <PanelLeftOpen className="w-4 h-4 text-slate-600" />
                    )}
                  </button>

                  <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200">
                    <button
                      onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                      disabled={currentPage <= 1}
                      className="p-1 rounded-lg bg-white border border-slate-200 disabled:opacity-30 hover:bg-slate-50 cursor-pointer shadow-2xs"
                      title="Halaman Sebelumnya"
                    >
                      <ChevronLeft className="w-4 h-4 text-slate-700" />
                    </button>
                    <span className="px-2 font-bold text-xs text-slate-800 font-mono">
                      {currentPage} / {totalPages}
                    </span>
                    <button
                      onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                      disabled={currentPage >= totalPages}
                      className="p-1 rounded-lg bg-white border border-slate-200 disabled:opacity-30 hover:bg-slate-50 cursor-pointer shadow-2xs"
                      title="Halaman Selanjutnya"
                    >
                      <ChevronRight className="w-4 h-4 text-slate-700" />
                    </button>
                  </div>

                  {/* Summary of active page detections */}
                  <span className="hidden md:inline-flex items-center gap-1.5 text-xs text-slate-600 font-medium bg-slate-50 px-2.5 py-1 rounded-lg border border-slate-200">
                    <Crosshair className="w-3.5 h-3.5 text-indigo-600" />
                    <span>{activePageNumbers.length} nomor di halaman {currentPage}</span>
                  </span>
                </div>

                {/* Center / Right Controls: Search, Category Filter, Zoom, Copy */}
                <div className="flex items-center gap-2 flex-wrap">
                  
                  {/* Category Highlight Filter */}
                  <div className="flex items-center gap-1">
                    <Filter className="w-3.5 h-3.5 text-slate-400" />
                    <select
                      value={selectedCategoryFilter}
                      onChange={(e) => setSelectedCategoryFilter(e.target.value)}
                      className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-900 cursor-pointer"
                    >
                      <option value="all">Semua Kategori ({activePageNumbers.length})</option>
                      <option value="phone">No. Telepon</option>
                      <option value="invoice">Invoice / PO</option>
                      <option value="id_card">NIK / NPWP</option>
                      <option value="bank_account">Rekening Bank</option>
                      <option value="currency">Nominal Harga</option>
                      <option value="serial_sku">Serial / SKU</option>
                    </select>
                  </div>

                  {/* Search in page */}
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                    <input
                      type="text"
                      placeholder="Cari teks di halaman..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-8 pr-3 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-900 w-36 sm:w-44 transition-all"
                    />
                    {searchQuery && (
                      <button
                        onClick={() => setSearchQuery('')}
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs"
                      >
                        ×
                      </button>
                    )}
                  </div>

                  {/* Text Size Switcher */}
                  <div className="hidden lg:flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200 text-[11px] font-semibold text-slate-600">
                    <button
                      onClick={() => setTextSize('sm')}
                      className={`px-1.5 py-0.5 rounded ${
                        textSize === 'sm' ? 'bg-white text-slate-900 shadow-2xs font-bold' : ''
                      }`}
                      title="Font Kecil"
                    >
                      A
                    </button>
                    <button
                      onClick={() => setTextSize('base')}
                      className={`px-1.5 py-0.5 rounded ${
                        textSize === 'base' ? 'bg-white text-slate-900 shadow-2xs font-bold' : ''
                      }`}
                      title="Font Standar"
                    >
                      A+
                    </button>
                    <button
                      onClick={() => setTextSize('lg')}
                      className={`px-1.5 py-0.5 rounded ${
                        textSize === 'lg' ? 'bg-white text-slate-900 shadow-2xs font-bold' : ''
                      }`}
                      title="Font Besar"
                    >
                      A++
                    </button>
                  </div>

                  {/* Rotate Button */}
                  <button
                    onClick={() => setRotation((prev) => (prev + 90) % 360)}
                    className="p-1.5 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-lg text-slate-700 transition-colors shadow-2xs cursor-pointer"
                    title="Putar 90°"
                  >
                    <RotateCw className="w-4 h-4" />
                  </button>

                  {/* Copy Page Text Button */}
                  <button
                    onClick={handleCopyPage}
                    className="inline-flex items-center gap-1 px-2.5 py-1 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 transition-colors shadow-2xs cursor-pointer"
                    title="Salin Teks Halaman Ini"
                  >
                    {copied ? (
                      <Check className="w-3.5 h-3.5 text-indigo-600" />
                    ) : (
                      <Copy className="w-3.5 h-3.5 text-slate-400" />
                    )}
                    <span>{copied ? 'Tersalin' : 'Salin Teks'}</span>
                  </button>
                </div>
              </div>

              {/* Hover Popover Tooltip for Number Detail */}
              {hoveredNumberItem && (
                <div className="px-5 py-2 bg-slate-900 text-white text-xs flex items-center justify-between gap-4 border-b border-slate-800 animate-in fade-in duration-100">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span className="font-bold uppercase tracking-wider text-slate-400 text-[10px]">
                      {CATEGORY_STYLES[hoveredNumberItem.category]?.label || hoveredNumberItem.category}:
                    </span>
                    <span className="font-mono font-bold text-amber-300">
                      {hoveredNumberItem.rawNumber}
                    </span>
                    <span className="text-slate-400">→</span>
                    <span className="font-mono text-emerald-300">
                      {hoveredNumberItem.normalizedNumber}
                    </span>
                    <span className="text-slate-400">({hoveredNumberItem.label})</span>
                  </div>
                  <div className="text-[11px] text-slate-300 font-medium">
                    Klik untuk memilih & memfokuskan
                  </div>
                </div>
              )}

              {/* Main Document Content Canvas */}
              <div
                className={`p-6 sm:p-8 overflow-y-auto flex-1 font-mono leading-relaxed whitespace-pre-wrap bg-white border-b border-slate-200 shadow-inner select-text ${
                  textSize === 'sm' ? 'text-xs' : textSize === 'base' ? 'text-sm' : 'text-base'
                }`}
              >
                <div
                  ref={textContainerRef}
                  style={{
                    transform: `rotate(${rotation}deg)`,
                    transformOrigin: 'center center',
                    transition: 'transform 0.3s ease-in-out'
                  }}
                  className="min-h-full"
                >
                  {renderHighlightedContent()}
                </div>
              </div>

              {/* ==================================================== */}
              {/* BOTTOM DRAWER: DETECTED NUMBERS JUMP LIST */}
              {/* ==================================================== */}
              <div className="bg-white border-t border-slate-200 shrink-0">
                <div className="px-4 py-2 bg-slate-50/90 border-b border-slate-200/80 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setShowBottomList(!showBottomList)}
                    className="flex items-center gap-2 text-xs font-bold text-slate-800 hover:text-slate-900 cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Daftar Nomor Terdeteksi di Halaman {currentPage} ({activePageNumbers.length})</span>
                    <span className="text-[11px] font-normal text-slate-400">
                      {showBottomList ? '(Sembunyikan)' : '(Tampilkan)'}
                    </span>
                  </button>

                  <span className="text-[11px] text-slate-400 font-medium">
                    Klik nomor untuk fokus & menyorot langsung di teks PDF
                  </span>
                </div>

                {showBottomList && (
                  <div className="p-3 max-h-36 overflow-y-auto">
                    {activePageNumbers.length === 0 ? (
                      <div className="py-2 text-center text-xs text-slate-400 italic">
                        Tidak ada nomor terdeteksi pada halaman ini.
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                        {activePageNumbers.map((item, idx) => {
                          const cat = CATEGORY_STYLES[item.category] || CATEGORY_STYLES.other;
                          const isFocused = focusedItemId === item.id;
                          const isPhone = item.category === 'phone';
                          const cleanWaDigits = item.normalizedNumber.replace(/\D/g, '');

                          return (
                            <div
                              key={item.id}
                              onClick={() => scrollToItem(item.id, item.rawNumber)}
                              className={`p-2 rounded-xl border text-xs flex items-center justify-between gap-2 transition-all cursor-pointer ${
                                isFocused
                                  ? 'bg-indigo-50/80 border-indigo-500 ring-2 ring-indigo-400/30 shadow-xs'
                                  : 'bg-slate-50/60 hover:bg-slate-100/80 border-slate-200'
                              }`}
                            >
                              <div className="min-w-0">
                                <div className="flex items-center gap-1.5">
                                  <span className={`w-1.5 h-1.5 rounded-full ${cat.dotBg}`}></span>
                                  <span className="font-mono font-bold text-slate-900 truncate">
                                    {item.normalizedNumber}
                                  </span>
                                </div>
                                <div className="text-[10px] text-slate-500 truncate mt-0.5">
                                  {item.label} • {cat.label}
                                </div>
                              </div>

                              <div className="flex items-center gap-1 shrink-0">
                                {isPhone && cleanWaDigits && (
                                  <a
                                    href={`https://wa.me/${
                                      cleanWaDigits.startsWith('0')
                                        ? '62' + cleanWaDigits.slice(1)
                                        : cleanWaDigits
                                    }`}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    onClick={(e) => e.stopPropagation()}
                                    title="Hubungi di WhatsApp"
                                    className="p-1 rounded bg-emerald-100 hover:bg-emerald-200 text-emerald-800 transition-colors"
                                  >
                                    <MessageSquare className="w-3 h-3" />
                                  </a>
                                )}

                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    navigator.clipboard.writeText(item.normalizedNumber);
                                  }}
                                  title="Salin Nomor"
                                  className="p-1 rounded hover:bg-slate-200 text-slate-500 transition-colors"
                                >
                                  <Copy className="w-3 h-3" />
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </section>
          </div>
        ) : (
          /* ======================================================== */
          /* TAB 2: METADATA & DOCUMENT PROPERTIES VIEWER */
          /* ======================================================== */
          <div className="p-6 overflow-y-auto flex-1 bg-white">
            <PdfMetadataViewer file={file} />
          </div>
        )}

        {/* ======================================================== */}
        {/* MODAL FOOTER */}
        {/* ======================================================== */}
        <footer className="px-5 py-3 border-t border-slate-200 bg-white flex items-center justify-between text-xs text-slate-500 shrink-0">
          <div className="flex items-center gap-3">
            <span>
              Total Halaman: <strong>{totalPages}</strong>
            </span>
            <span className="hidden sm:inline text-slate-300">•</span>
            <span className="hidden sm:inline">
              Ukuran: <strong>{(file.size / 1024).toFixed(1)} KB</strong>
            </span>
            {meta?.producer && (
              <>
                <span className="hidden md:inline text-slate-300">•</span>
                <span className="hidden md:inline truncate max-w-xs text-slate-400">
                  Engine: {meta.producer}
                </span>
              </>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors cursor-pointer shadow-2xs"
            >
              Tutup Pratinjau
            </button>
          </div>
        </footer>
      </div>
    </div>
  );
};
