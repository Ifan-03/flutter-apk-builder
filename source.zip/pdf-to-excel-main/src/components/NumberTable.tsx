import React, { useState, useEffect, useRef } from 'react';
import { 
  Copy, 
  Check, 
  Trash2, 
  MessageSquare, 
  Download, 
  Eye, 
  Edit3,
  ArrowUpDown,
  Layers,
  AlertCircle,
  AlertTriangle,
  Activity,
  Wrench,
  Brain,
  Sparkles,
  Replace,
  Combine,
  MoreVertical,
  UserPlus,
  FileText
} from 'lucide-react';
import { ExtractedNumber, NumberCategory } from '../types';
import { getCategoryBadgeStyle, exportCleanPhoneNumbersToTxt } from '../utils/exportUtils';

interface NumberTableProps {
  items: ExtractedNumber[];
  onDeleteItem: (id: string) => void;
  onDeleteSelected: (ids: string[]) => void;
  onToggleSelect: (id: string) => void;
  onSelectAll: (select: boolean) => void;
  onEditItem: (item: ExtractedNumber) => void;
  onViewContext: (item: ExtractedNumber) => void;
  onOpenExportModal: (selectedOnly?: boolean) => void;
  onQuickCopyWaList: (itemsToCopy: ExtractedNumber[]) => void;
  onOpenHealthModal?: () => void;
  healthIssueCount?: number;
  onOpenMlModal?: () => void;
  mlCandidateCount?: number;
  onOpenFindReplace?: () => void;
  onMergeDuplicates?: () => void;
  onBatchChangeCategory?: (category: NumberCategory) => void;
  onExtractPages?: () => void;
}

import { getAccessToken } from '../firebase';

export const NumberTable: React.FC<NumberTableProps> = ({
  items,
  onDeleteItem,
  onDeleteSelected,
  onToggleSelect,
  onSelectAll,
  onEditItem,
  onViewContext,
  onOpenExportModal,
  onQuickCopyWaList,
  onOpenHealthModal,
  healthIssueCount = 0,
  onOpenMlModal,
  mlCandidateCount = 0,
  onOpenFindReplace,
  onMergeDuplicates,
  onBatchChangeCategory,
  onExtractPages,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [sortField, setSortField] = useState<keyof ExtractedNumber | null>(null);
  const [sortAsc, setSortAsc] = useState(true);
  const [openDropdownId, setOpenDropdownId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Quick copy individual number
  const handleCopySingle = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const handleDropdownAction = async (action: string, item: ExtractedNumber) => {
    setOpenDropdownId(null);
    if (action === 'copy') {
      navigator.clipboard.writeText(item.normalizedNumber);
      setToastMessage(`Berhasil menyalin: ${item.normalizedNumber}`);
      setTimeout(() => setToastMessage(null), 3000);
    } else if (action === 'contact') {
      const vCard = `BEGIN:VCARD\nVERSION:3.0\nFN:${item.entityName || item.label}\nTEL:${item.normalizedNumber}\nEND:VCARD`;
      const blob = new Blob([vCard], { type: 'text/vcard;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${item.entityName || item.label || 'Contact'}.vcf`;
      document.body.appendChild(link);
      link.click();
      setTimeout(() => {
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      }, 100);
    } else if (action === 'google_contact') {
      const token = getAccessToken();
      if (!token) {
        alert('Anda harus login dengan Google dan memberikan izin kontak.');
        return;
      }
      try {
        const response = await fetch('https://people.googleapis.com/v1/people:createContact', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            names: [{ givenName: item.entityName || item.label || 'Unknown Contact' }],
            phoneNumbers: [{ value: item.normalizedNumber }]
          })
        });
        
        if (response.ok) {
          setToastMessage(`Tersimpan di Google Contacts: ${item.entityName || item.label || 'Kontak Baru'}`);
          setTimeout(() => setToastMessage(null), 3000);
        } else {
          const errorData = await response.json();
          alert(`Gagal menyimpan kontak: ${errorData.error?.message || 'Terjadi kesalahan'}`);
        }
      } catch (error) {
        alert('Gagal menghubungi Google Contacts API.');
        console.error(error);
      }
    } else if (action === 'export_selected_txt') {
      const selectedPhoneItems = items.filter(i => i.selected && i.category === 'phone');
      const itemsToExport = selectedPhoneItems.length > 0 ? selectedPhoneItems : [item].filter(i => i.category === 'phone');
      if (itemsToExport.length > 0) {
        exportCleanPhoneNumbersToTxt(itemsToExport, 'Daftar_Nomor_Telepon.txt');
        setToastMessage(`Berhasil menyimpan file TXT berisi ${itemsToExport.length} nomor.`);
        setTimeout(() => setToastMessage(null), 3000);
      } else {
        alert('Tidak ada nomor telepon yang dapat diekspor. Pastikan kategori item adalah "phone".');
      }
    } else if (action === 'txt') {
      const txtContent = `Nama: ${item.entityName || item.label || 'Unknown'}\nNomor: ${item.normalizedNumber}\nKategori: ${item.category}\nHalaman: ${item.pageIndex + 1}`;
      const blob = new Blob([txtContent], { type: 'text/plain;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${item.entityName || item.label || item.normalizedNumber}.txt`;
      document.body.appendChild(link);
      link.click();
      setTimeout(() => {
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      }, 100);
      setToastMessage(`Berhasil menyimpan file TXT`);
      setTimeout(() => setToastMessage(null), 3000);
    }
  };

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (!(e.target as Element).closest('.action-dropdown-container')) {
        setOpenDropdownId(null);
      }
    };
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  const selectedItems = items.filter((i) => i.selected);
  const isAllSelected = items.length > 0 && selectedItems.length === items.length;

  const handleSort = (field: keyof ExtractedNumber) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(true);
    }
  };

  const sortedItems = [...items].sort((a, b) => {
    if (!sortField) return 0;
    const valA = String(a[sortField] || '');
    const valB = String(b[sortField] || '');
    return sortAsc ? valA.localeCompare(valB) : valB.localeCompare(valA);
  });

  return (
    <section id="extracted-numbers-table-section" className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
      {/* Top Table Action Header */}
      <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <input
              id="checkbox-select-all-header"
              type="checkbox"
              checked={isAllSelected}
              onChange={(e) => onSelectAll(e.target.checked)}
              className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300 cursor-pointer"
            />
            <span className="text-xs font-semibold text-slate-800">
              {selectedItems.length > 0
                ? `${selectedItems.length} dari ${items.length} dipilih`
                : `Total ${items.length} Nomor Terdeteksi`}
            </span>
          </div>

          {selectedItems.length > 0 && (
            <button
              id="btn-delete-selected"
              onClick={() => onDeleteSelected(selectedItems.map((i) => i.id))}
              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-rose-600 hover:bg-rose-50 rounded-md border border-rose-200 transition-colors cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Hapus ({selectedItems.length})</span>
            </button>
          )}
        </div>

        {/* Primary Actions & Health Check & ML */}
        <div className="flex items-center gap-2 flex-wrap">
          {onOpenMlModal && (
            <button
              id="btn-table-ml-categorizer"
              onClick={onOpenMlModal}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-lg shadow-2xs transition-all cursor-pointer"
              title="Klasifikasikan nomor ambigu/tak dikenal menggunakan Machine Learning"
            >
              <Brain className="w-3.5 h-3.5 text-indigo-600" />
              <span>Auto-Categorizer ML</span>
              {mlCandidateCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-indigo-600 text-white">
                  {mlCandidateCount}
                </span>
              )}
            </button>
          )}

          {onOpenHealthModal && (
            <button
              id="btn-table-health-check"
              onClick={onOpenHealthModal}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-all cursor-pointer ${
                healthIssueCount > 0
                  ? 'bg-rose-50 hover:bg-rose-100 text-rose-700 border-rose-200'
                  : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border-emerald-200'
              }`}
              title="Periksa kesehatan data dan anomali ekstraksi"
            >
              <Activity className="w-3.5 h-3.5" />
              <span>Data Health</span>
              {healthIssueCount > 0 ? (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-rose-600 text-white">
                  {healthIssueCount}
                </span>
              ) : (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-emerald-600 text-white">
                  Valid
                </span>
              )}
            </button>
          )}

          {onOpenFindReplace && (
            <button
              id="btn-table-find-replace"
              onClick={onOpenFindReplace}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-2xs transition-all cursor-pointer"
              title="Cari dan ganti label, kategori, atau nilai nomor secara massal"
            >
              <Replace className="w-3.5 h-3.5 text-indigo-600" />
              <span>Find & Replace {selectedItems.length > 0 ? `(${selectedItems.length})` : ''}</span>
            </button>
          )}

          {onMergeDuplicates && (
            <button
              id="btn-merge-duplicates"
              onClick={onMergeDuplicates}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-amber-700 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-lg shadow-2xs transition-all cursor-pointer"
              title="Gabungkan entri duplikat dan agregasi konteks serta jumlah kemunculannya"
            >
              <Combine className="w-3.5 h-3.5 text-amber-600" />
              <span>Gabung Duplikat</span>
            </button>
          )}

          {onBatchChangeCategory && selectedItems.length > 0 && (
            <div className="relative flex items-center">
              <select
                value=""
                onChange={(e) => {
                  if (e.target.value) {
                    onBatchChangeCategory(e.target.value as NumberCategory);
                  }
                }}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                title="Ubah Kategori Massal"
              >
                <option value="" disabled>Ubah Kategori...</option>
                <option value="phone">Telepon / WhatsApp</option>
                <option value="invoice">Nomor Invoice</option>
                <option value="id_card">NIK / KTP</option>
                <option value="bank_account">Rekening Bank</option>
                <option value="currency">Nominal Uang</option>
                <option value="serial_sku">Nomor Seri / SKU</option>
                <option value="date_time">Tanggal / Waktu</option>
                <option value="custom">Format Custom</option>
                <option value="other">Lainnya</option>
              </select>
              <button
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg shadow-2xs transition-all pointer-events-none"
              >
                <Wrench className="w-3.5 h-3.5 text-slate-500" />
                <span>Ubah Kategori</span>
              </button>
            </div>
          )}

          {onExtractPages && selectedItems.length > 0 && (
            <button
              onClick={onExtractPages}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg shadow-2xs transition-colors cursor-pointer"
              title="Ekstrak halaman PDF tempat data ini ditemukan menjadi file terpisah"
            >
              <Layers className="w-3.5 h-3.5 text-emerald-600" />
              <span>Pisahkan PDF Halaman</span>
            </button>
          )}

          <button
            id="btn-quick-copy-wa"
            onClick={() => onQuickCopyWaList(selectedItems.length > 0 ? selectedItems : items)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-2xs transition-colors cursor-pointer"
          >
            <Copy className="w-3.5 h-3.5 text-slate-400" />
            <span>Salin WA List</span>
          </button>

          <button
            id="btn-open-export-modal"
            onClick={() => onOpenExportModal(selectedItems.length > 0)}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs transition-all cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Ekspor Excel / CSV {selectedItems.length > 0 ? `(${selectedItems.length})` : ''}</span>
          </button>
        </div>
      </div>

      {/* Table Container */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50 text-slate-400 border-b border-slate-100 text-[11px] font-bold uppercase tracking-wider">
              <th className="p-3 w-10 text-center">
                <input
                  type="checkbox"
                  checked={isAllSelected}
                  onChange={(e) => onSelectAll(e.target.checked)}
                  className="w-3.5 h-3.5 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300 cursor-pointer"
                />
              </th>
              <th className="p-3 w-12 text-center font-semibold">#</th>
              <th 
                className="p-3 cursor-pointer hover:text-slate-700 transition-colors"
                onClick={() => handleSort('normalizedNumber')}
              >
                <div className="flex items-center gap-1.5">
                  <span>Nomor / Nilai Bersih</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th 
                className="p-3 cursor-pointer hover:text-slate-700 transition-colors"
                onClick={() => handleSort('category')}
              >
                <div className="flex items-center gap-1.5">
                  <span>Kategori</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th className="p-3">Label & Entitas</th>
              <th 
                className="p-3 cursor-pointer hover:text-slate-700 transition-colors"
                onClick={() => handleSort('fileName')}
              >
                <div className="flex items-center gap-1.5">
                  <span>File & Hal.</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th className="p-3 min-w-[200px]">Konteks Dokumen</th>
              <th className="p-3 w-28 text-center">Aksi Cepat</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-700">
            {sortedItems.length === 0 ? (
              <tr>
                <td colSpan={8} className="p-12 text-center text-slate-400">
                  <div className="max-w-sm mx-auto flex flex-col items-center">
                    <div className="w-12 h-12 rounded-full bg-slate-50 text-slate-400 flex items-center justify-center mb-3">
                      <Layers className="w-6 h-6" />
                    </div>
                    <p className="text-sm font-semibold text-slate-700">Tidak ada nomor yang cocok</p>
                    <p className="text-xs text-slate-400 mt-1">
                      Coba sesuaikan kata kunci pencarian, centang kategori lain, atau unggah file PDF.
                    </p>
                  </div>
                </td>
              </tr>
            ) : (
              sortedItems.map((item, idx) => {
                const badge = getCategoryBadgeStyle(item.category);
                const isPhone = item.category === 'phone';
                const cleanWaDigits = item.normalizedNumber.replace(/\D/g, '');
                const hasIssues = item.healthIssues && item.healthIssues.length > 0;
                const criticalIssue = item.healthIssues?.find((i) => i.severity === 'critical');
                const warningIssue = item.healthIssues?.find((i) => i.severity === 'warning');
                const primaryIssue = criticalIssue || warningIssue || item.healthIssues?.[0];

                return (
                  <tr
                    key={item.id}
                    id={`row-${item.id}`}
                    className={`hover:bg-slate-50/60 transition-colors ${
                      item.selected ? 'bg-indigo-50/20' : ''
                    } ${
                      hasIssues 
                        ? criticalIssue 
                          ? 'bg-rose-50/20 hover:bg-rose-50/40' 
                          : 'bg-amber-50/15 hover:bg-amber-50/30'
                        : ''
                    }`}
                  >
                    {/* Checkbox */}
                    <td className="p-3 text-center">
                      <input
                        type="checkbox"
                        checked={Boolean(item.selected)}
                        onChange={() => onToggleSelect(item.id)}
                        className="w-3.5 h-3.5 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300 cursor-pointer"
                      />
                    </td>

                    {/* Index */}
                    <td className="p-3 text-center font-mono text-slate-400">
                      {idx + 1}
                    </td>

                    {/* Normalized / Clean Number */}
                    <td className="p-3 font-semibold text-slate-900">
                      <div className="flex items-center gap-2">
                        <span className={`font-mono text-xs md:text-sm tracking-tight px-2 py-0.5 rounded border ${
                          hasIssues 
                            ? criticalIssue 
                              ? 'bg-rose-50 text-rose-900 border-rose-200' 
                              : 'bg-amber-50 text-amber-900 border-amber-200'
                            : 'text-slate-900 bg-slate-50 border-slate-200/80'
                        }`}>
                          {item.normalizedNumber}
                        </span>
                        
                        {(item.occurrences || 1) > 1 && (
                          <span className="inline-flex items-center justify-center px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300" title={`${item.occurrences} Kemunculan`}>
                            {item.occurrences}x
                          </span>
                        )}

                        <button
                          onClick={() => handleCopySingle(item.id, item.normalizedNumber)}
                          title="Salin nomor"
                          className="text-slate-400 hover:text-indigo-600 p-1 rounded hover:bg-slate-100 transition-colors cursor-pointer"
                        >
                          {copiedId === item.id ? (
                            <Check className="w-3.5 h-3.5 text-indigo-600" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>

                      {/* Raw Number */}
                      {item.rawNumber !== item.normalizedNumber && (
                        <p className="text-[11px] text-slate-400 font-mono mt-0.5">
                          Asli: {item.rawNumber}
                        </p>
                      )}

                      {/* Health Issue Badge on Row */}
                      {hasIssues && primaryIssue && (
                        <div 
                          onClick={onOpenHealthModal}
                          className={`inline-flex items-center gap-1 mt-1 px-1.5 py-0.5 rounded text-[10px] font-semibold cursor-pointer border transition-colors ${
                            primaryIssue.severity === 'critical'
                              ? 'bg-rose-100 hover:bg-rose-200 text-rose-800 border-rose-200'
                              : primaryIssue.severity === 'warning'
                              ? 'bg-amber-100 hover:bg-amber-200 text-amber-800 border-amber-200'
                              : 'bg-slate-200 hover:bg-slate-300 text-slate-800 border-slate-300'
                          }`}
                          title={`${primaryIssue.title}: ${primaryIssue.description}`}
                        >
                          {primaryIssue.severity === 'critical' ? (
                            <AlertCircle className="w-3 h-3 text-rose-600" />
                          ) : (
                            <AlertTriangle className="w-3 h-3 text-amber-600" />
                          )}
                          <span className="truncate max-w-[170px]">{primaryIssue.title}</span>
                          {primaryIssue.canAutoFix && (
                            <Wrench className="w-2.5 h-2.5 text-indigo-600 ml-0.5" />
                          )}
                        </div>
                      )}
                    </td>

                    {/* Category Badge */}
                    <td className="p-3">
                      <div className="flex flex-col gap-1 items-start">
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium border ${badge.bg} ${badge.text} ${badge.border}`}
                        >
                          {badge.label}
                        </span>

                        {item.isMlCategorized && (
                          <span
                            className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded text-[9.5px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200"
                            title={item.mlExplanation || 'Diklasifikasikan otomatis oleh Machine Learning NLP'}
                          >
                            <Brain className="w-2.5 h-2.5" />
                            <span>ML Auto</span>
                            {item.mlConfidence && (
                              <span className="font-mono text-[9px] text-indigo-600">
                                {Math.round(item.mlConfidence * 100)}%
                              </span>
                            )}
                          </span>
                        )}
                      </div>
                    </td>

                    {/* Label & Entity Name */}
                    <td className="p-3">
                      <p className="font-medium text-slate-900">{item.label}</p>
                      {item.entityName && (
                        <p className="text-[11px] text-slate-400 font-medium">{item.entityName}</p>
                      )}
                    </td>

                    {/* File & Page */}
                    <td className="p-3">
                      <p className="font-medium text-slate-800 truncate max-w-[140px]" title={item.fileName}>
                        {item.fileName}
                      </p>
                      <span className="text-[11px] text-slate-400 font-mono">Hal. {item.pageNumber}</span>
                    </td>

                    {/* Context Snippet */}
                    <td className="p-3">
                      <p className="text-slate-500 text-xs leading-relaxed line-clamp-2 max-w-xs" title={item.context}>
                        "{item.context}"
                      </p>
                    </td>

                    {/* Quick Action Buttons */}
                    <td className="p-3 text-center">
                      <div className="flex items-center justify-center gap-1">
                        {isPhone && cleanWaDigits && (
                          <a
                            href={`https://wa.me/${cleanWaDigits.startsWith('0') ? '62' + cleanWaDigits.slice(1) : cleanWaDigits}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            title="Buka Chat WhatsApp"
                            className="p-1.5 rounded bg-emerald-50 hover:bg-emerald-100 text-emerald-700 transition-colors cursor-pointer"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                          </a>
                        )}

                        <button
                          onClick={() => onViewContext(item)}
                          title="Lihat konteks penuh"
                          className="p-1.5 rounded hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => onEditItem(item)}
                          title="Edit baris"
                          className="p-1.5 rounded hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => onDeleteItem(item.id)}
                          title="Hapus baris ini"
                          className="p-1.5 rounded hover:bg-rose-50 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>

                        <div className="relative action-dropdown-container">
                          <button
                            onClick={() => setOpenDropdownId(openDropdownId === item.id ? null : item.id)}
                            title="Tindakan cepat"
                            className="p-1.5 rounded hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
                          >
                            <MoreVertical className="w-3.5 h-3.5" />
                          </button>
                          
                          {openDropdownId === item.id && (
                            <div className="absolute right-0 top-full mt-1 w-40 bg-white border border-slate-200 rounded-lg shadow-lg overflow-hidden z-20 animate-in fade-in zoom-in-95 duration-100 origin-top-right">
                              {isPhone && (
                                <>
                                  <button
                                    onClick={() => handleDropdownAction('contact', item)}
                                    className="w-full flex items-center gap-2 px-3 py-2 text-left text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
                                  >
                                    <UserPlus className="w-3.5 h-3.5 text-slate-400" />
                                    Unduh Kontak (.vcf)
                                  </button>
                                  <button
                                    onClick={() => handleDropdownAction('google_contact', item)}
                                    className="w-full flex items-center gap-2 px-3 py-2 text-left text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
                                  >
                                    <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                                      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                                      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                                      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                                      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                                    </svg>
                                    Simpan ke Google
                                  </button>
                                </>
                              )}
                              <button
                                onClick={() => handleDropdownAction('copy', item)}
                                className="w-full flex items-center gap-2 px-3 py-2 text-left text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
                              >
                                <Copy className="w-3.5 h-3.5 text-slate-400" />
                                Salin Nilai
                              </button>
                              <button
                                onClick={() => handleDropdownAction('txt', item)}
                                className="w-full flex items-center gap-2 px-3 py-2 text-left text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
                              >
                                <FileText className="w-3.5 h-3.5 text-slate-400" />
                                Info Detail (TXT)
                              </button>
                              <button
                                onClick={() => handleDropdownAction('export_selected_txt', item)}
                                className="w-full flex items-center gap-2 px-3 py-2 text-left text-xs font-medium text-emerald-700 hover:bg-emerald-50 transition-colors cursor-pointer border-t border-slate-100 mt-1 pt-1"
                              >
                                <FileText className="w-3.5 h-3.5 text-emerald-500" />
                                {item.selected && items.filter(i => i.selected).length > 1 ? `Export ${items.filter(i => i.selected).length} Terpilih (TXT)` : 'Export Nomor Saja (TXT)'}
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Footer info bar */}
      <div className="p-3.5 bg-slate-50/50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
        <span>Menampilkan {sortedItems.length} baris nomor</span>
        <div className="flex items-center gap-3">
          <span>Tip: Klik tanda peringatan untuk melihat detail anomali data</span>
        </div>
      </div>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-2xl flex items-center gap-3 animate-in slide-in-from-bottom-5 fade-in duration-300">
          <div className="bg-emerald-500/20 p-1.5 rounded-full">
            <Check className="w-4 h-4 text-emerald-400" />
          </div>
          <span className="text-sm font-medium tracking-tight pr-2">{toastMessage}</span>
        </div>
      )}
    </section>
  );
};
