import React, { useMemo, useState } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  AreaChart,
  Area
} from 'recharts';
import { ExtractedNumber, PdfFileInfo, NumberCategory } from '../types';
import { Activity, PieChart as PieChartIcon, TrendingUp, Layers, ChevronUp, ChevronDown } from 'lucide-react';

interface DashboardOverviewProps {
  items: ExtractedNumber[];
  files: PdfFileInfo[];
}

const CATEGORY_COLORS: Record<NumberCategory | string, string> = {
  phone: '#22c55e', // emerald-500
  invoice: '#3b82f6', // blue-500
  id_card: '#eab308', // yellow-500
  bank_account: '#a855f7', // purple-500
  currency: '#f97316', // orange-500
  serial_sku: '#ec4899', // pink-500
  date_time: '#14b8a6', // teal-500
  custom: '#6366f1', // indigo-500
  other: '#94a3b8', // slate-400
};

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({ items, files }) => {
  const [isMinimized, setIsMinimized] = useState(false);
  
  // 1. Total Records by Category
  const categoryData = useMemo(() => {
    const counts: Record<string, number> = {};
    items.forEach(item => {
      counts[item.category] = (counts[item.category] || 0) + 1;
    });
    return Object.entries(counts).map(([name, value]) => ({
      name,
      value
    })).sort((a, b) => b.value - a.value);
  }, [items]);

  // 2. Data Extraction Trend (Simulated Time / Pages)
  const trendData = useMemo(() => {
    // Group by page number to show distribution across document lengths
    const pages: Record<number, number> = {};
    items.forEach(item => {
      pages[item.pageNumber] = (pages[item.pageNumber] || 0) + 1;
    });
    
    // Sort pages
    const sortedPages = Object.keys(pages).map(Number).sort((a, b) => a - b);
    return sortedPages.map(page => ({
      name: `Page ${page}`,
      count: pages[page]
    }));
  }, [items]);

  // 3. File Processing Distribution
  const fileData = useMemo(() => {
    const counts: Record<string, number> = {};
    items.forEach(item => {
      counts[item.fileName] = (counts[item.fileName] || 0) + 1;
    });
    return Object.entries(counts).map(([name, value]) => ({
      name: name.length > 20 ? name.substring(0, 20) + '...' : name,
      value
    }));
  }, [items]);
  
  const COLORS = ['#6366f1', '#3b82f6', '#0ea5e9', '#06b6d4', '#14b8a6', '#22c55e', '#84cc16', '#eab308'];

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-slate-500">
        <Activity className="w-12 h-12 mb-4 text-slate-300" />
        <h3 className="text-lg font-medium text-slate-700">Belum Ada Data Ekstraksi</h3>
        <p className="text-sm">Silakan unggah dokumen PDF untuk melihat analitik dasbor.</p>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto w-full animate-in fade-in duration-300">
      
      <div className="flex items-center justify-between gap-2 mb-2">
        <div className="flex items-center gap-2">
          <TrendingUp className="w-6 h-6 text-indigo-600" />
          <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Executive Analytics</h2>
        </div>
        <button
          onClick={() => setIsMinimized(!isMinimized)}
          className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors"
          title={isMinimized ? "Perluas Dasbor" : "Sembunyikan Dasbor"}
        >
          {isMinimized ? (
            <ChevronDown className="w-5 h-5 text-slate-500" />
          ) : (
            <ChevronUp className="w-5 h-5 text-slate-500" />
          )}
        </button>
      </div>

      {!isMinimized && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Chart 1: Total Records by Category */}
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200">
          <div className="flex items-center gap-2 mb-6">
            <Layers className="w-5 h-5 text-blue-500" />
            <h3 className="font-semibold text-slate-800">Distribusi Kategori Ekstraksi</h3>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={categoryData} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" />
                <XAxis type="number" />
                <YAxis dataKey="name" type="category" tick={{fontSize: 12}} width={90} />
                <Tooltip 
                  cursor={{fill: '#f8fafc'}}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={CATEGORY_COLORS[entry.name] || '#94a3b8'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Extraction Trend across Pages */}
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200">
          <div className="flex items-center gap-2 mb-6">
            <Activity className="w-5 h-5 text-emerald-500" />
            <h3 className="font-semibold text-slate-800">Kepadatan Data per Halaman</h3>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trendData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="name" tick={{fontSize: 12}} />
                <YAxis />
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)' }}
                />
                <Area type="monotone" dataKey="count" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorCount)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 3: File Contribution Pie */}
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200 lg:col-span-2">
          <div className="flex items-center gap-2 mb-6">
            <PieChartIcon className="w-5 h-5 text-purple-500" />
            <h3 className="font-semibold text-slate-800">Kontribusi File terhadap Total Data</h3>
          </div>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={fileData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={120}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {fileData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)' }}
                />
                <Legend verticalAlign="bottom" height={36}/>
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>
      )}
    </div>
  );
};
