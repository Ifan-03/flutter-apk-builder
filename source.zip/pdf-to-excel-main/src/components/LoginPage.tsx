import React, { useState, useEffect, useRef } from 'react';
import { 
  Mail, 
  Lock, 
  Eye, 
  EyeOff, 
  ArrowRight, 
  FileSpreadsheet,
  FileText,
  KeyRound,
  Sparkles
} from 'lucide-react';
import { auth, googleProvider, signInWithPopup, setAccessToken } from '../firebase';
import { GoogleAuthProvider } from 'firebase/auth';

interface LoginPageProps {
  onLoginSuccess: (email: string) => void;
  onContinueAsGuest?: () => void;
}

// Particle Network Background Component
const ParticleNetwork: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let particles: Particle[] = [];
    let animationFrameId: number;
    let w = canvas.width = window.innerWidth;
    let h = canvas.height = window.innerHeight;

    class Particle {
      x: number;
      y: number;
      vx: number;
      vy: number;
      radius: number;

      constructor() {
        this.x = Math.random() * w;
        this.y = Math.random() * h;
        this.vx = (Math.random() - 0.5) * 1.5;
        this.vy = (Math.random() - 0.5) * 1.5;
        this.radius = Math.random() * 2 + 1;
      }

      update() {
        this.x += this.vx;
        this.y += this.vy;
        
        if (this.x < 0 || this.x > w) this.vx = -this.vx;
        if (this.y < 0 || this.y > h) this.vy = -this.vy;
      }

      draw() {
        if (!ctx) return;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(34, 211, 238, 0.6)'; // Cyan nodes
        ctx.fill();
      }
    }

    const init = () => {
      particles = [];
      const numParticles = Math.floor((w * h) / 15000);
      for (let i = 0; i < numParticles; i++) {
        particles.push(new Particle());
      }
    };

    const animate = () => {
      ctx.clearRect(0, 0, w, h);
      
      for (let i = 0; i < particles.length; i++) {
        particles[i].update();
        particles[i].draw();
        
        for (let j = i; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          
          if (dist < 120) {
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.strokeStyle = `rgba(34, 211, 238, ${1 - dist / 120})`; // Cyan lines fading
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }
      }
      animationFrameId = requestAnimationFrame(animate);
    };

    const handleResize = () => {
      w = canvas.width = window.innerWidth;
      h = canvas.height = window.innerHeight;
      init();
    };

    window.addEventListener('resize', handleResize);
    init();
    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas 
      ref={canvasRef} 
      className="absolute inset-0 z-0 pointer-events-none"
    />
  );
};

export const LoginPage: React.FC<LoginPageProps> = ({
  onLoginSuccess,
  onContinueAsGuest,
}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [toastNotification, setToastNotification] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setToastNotification(msg);
    setTimeout(() => setToastNotification(null), 3500);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!email.trim() || !password.trim()) {
      setErrorMessage('Silakan lengkapi alamat email dan kata sandi Anda.');
      return;
    }

    if (!email.includes('@') || !email.includes('.')) {
      setErrorMessage('Format alamat email tidak valid.');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLoginSuccess(email.trim());
    }, 700);
  };

  const handleGoogleLogin = async () => {
    try {
      setIsLoading(true);
      const result = await signInWithPopup(auth, googleProvider);
      const credential = GoogleAuthProvider.credentialFromResult(result);
      if (credential?.accessToken) {
        setAccessToken(credential.accessToken);
      }
      if (result.user && result.user.email) {
        onLoginSuccess(result.user.email);
      } else {
        setErrorMessage('Gagal login dengan Google: Email tidak ditemukan.');
      }
    } catch (error: any) {
      console.error(error);
      setErrorMessage(error.message || 'Gagal login dengan Google');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <main className="min-h-screen relative flex items-center justify-center p-4 sm:p-8 font-sans overflow-hidden bg-slate-950">
      
      {/* Deep cosmic gradient background */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-[#1e1b4b] via-[#0f172a] to-[#020617] z-0"></div>
      
      {/* Swirling Network of Digital Data Streams */}
      <ParticleNetwork />

      {/* Embedded CSS for animations */}
      <style>{`
        @keyframes float-pdf {
          0%, 100% { transform: translateY(0) rotate(-10deg); }
          50% { transform: translateY(-30px) rotate(-5deg) scale(1.05); }
        }
        @keyframes float-excel {
          0%, 100% { transform: translateY(0) rotate(15deg); }
          50% { transform: translateY(-25px) rotate(20deg) scale(1.05); }
        }
        @keyframes float-pdf-2 {
          0%, 100% { transform: translateY(0) rotate(25deg); }
          50% { transform: translateY(20px) rotate(15deg) scale(0.95); }
        }
        @keyframes neon-pulse {
          0%, 100% { 
            box-shadow: 0 0 10px rgba(34,211,238,0.5), inset 0 0 5px rgba(34,211,238,0.2); 
            border-color: rgba(34,211,238,0.8);
          }
          50% { 
            box-shadow: 0 0 25px rgba(34,211,238,0.9), inset 0 0 10px rgba(34,211,238,0.4); 
            border-color: rgba(34,211,238,1);
          }
        }
        .animate-float-pdf { animation: float-pdf 6s ease-in-out infinite; }
        .animate-float-excel { animation: float-excel 7s ease-in-out infinite reverse; }
        .animate-float-pdf-2 { animation: float-pdf-2 8s ease-in-out infinite; }
        .input-neon-focus:focus {
          animation: neon-pulse 1.5s infinite;
          outline: none;
        }
      `}</style>

      {/* Floating 3D-like Icons */}
      <div className="absolute top-[15%] left-[10%] animate-float-pdf z-10 opacity-80 mix-blend-screen hidden md:block">
        <div className="w-20 h-20 bg-rose-500/20 rounded-2xl backdrop-blur-md border border-rose-500/40 flex items-center justify-center shadow-[0_0_30px_rgba(244,63,94,0.3)]">
          <FileText className="w-10 h-10 text-rose-400 drop-shadow-[0_0_10px_rgba(244,63,94,0.8)]" />
        </div>
      </div>
      
      <div className="absolute bottom-[20%] right-[12%] animate-float-excel z-10 opacity-80 mix-blend-screen hidden md:block">
        <div className="w-24 h-24 bg-emerald-500/20 rounded-2xl backdrop-blur-md border border-emerald-500/40 flex items-center justify-center shadow-[0_0_30px_rgba(16,185,129,0.3)]">
          <FileSpreadsheet className="w-12 h-12 text-emerald-400 drop-shadow-[0_0_10px_rgba(16,185,129,0.8)]" />
        </div>
      </div>

      <div className="absolute top-[25%] right-[20%] animate-float-pdf-2 z-10 opacity-60 mix-blend-screen hidden lg:block">
        <div className="w-16 h-16 bg-rose-500/10 rounded-xl backdrop-blur-sm border border-rose-500/30 flex items-center justify-center shadow-[0_0_20px_rgba(244,63,94,0.2)]">
          <FileText className="w-8 h-8 text-rose-400 drop-shadow-[0_0_5px_rgba(244,63,94,0.5)]" />
        </div>
      </div>

      {/* Toast Notification */}
      {toastNotification && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 bg-slate-900/80 backdrop-blur-md text-cyan-50 text-sm px-5 py-3 rounded-full shadow-[0_0_20px_rgba(34,211,238,0.3)] flex items-center gap-2 border border-cyan-500/50 animate-in fade-in slide-in-from-top-4 duration-300">
          <Sparkles className="w-4 h-4 text-cyan-400 shrink-0" />
          <span>{toastNotification}</span>
        </div>
      )}

      {/* Main Glassmorphism Card */}
      <div className="relative z-20 w-full max-w-md bg-slate-900/40 backdrop-blur-2xl rounded-3xl p-8 sm:p-10 border border-white/10 shadow-[0_0_50px_rgba(0,0,0,0.5),inset_0_0_20px_rgba(255,255,255,0.05)] transform transition-all">
        
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br from-cyan-400/20 to-blue-600/20 border border-cyan-400/30 mb-4 shadow-[0_0_20px_rgba(34,211,238,0.2)]">
            <FileSpreadsheet className="w-7 h-7 text-cyan-300 drop-shadow-[0_0_8px_rgba(34,211,238,0.8)]" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-blue-200 to-purple-300 tracking-tight mb-2">
            DataExtractor.pro
          </h1>
          <h2 className="text-lg text-slate-200 font-semibold mb-1">
            Selamat Datang Kembali
          </h2>
          <p className="text-sm text-slate-400">
            Akses platform cerdas ekstraksi PDF & Excel
          </p>
        </div>

        {errorMessage && (
          <div className="mb-6 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs font-medium flex items-center gap-2 backdrop-blur-sm">
            <div className="w-1.5 h-1.5 rounded-full bg-rose-400 shrink-0 shadow-[0_0_5px_rgba(251,113,133,0.8)]"></div>
            <span>{errorMessage}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          
          {/* Email Input */}
          <div className="space-y-1.5">
            <label className="block text-xs font-medium text-slate-300 ml-1">
              Alamat Email
            </label>
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <Mail className="w-4 h-4 text-cyan-500/60 group-focus-within:text-cyan-400 transition-colors" />
              </div>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@enterprise.com"
                className="input-neon-focus w-full pl-11 pr-4 py-3.5 bg-slate-950/50 border border-slate-700/50 rounded-xl text-sm text-white placeholder:text-slate-600 transition-all duration-300"
              />
            </div>
          </div>

          {/* Password Input */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center ml-1 mr-1">
              <label className="block text-xs font-medium text-slate-300">
                Kata Sandi
              </label>
              <button
                type="button"
                onClick={() => showNotification('Silakan hubungi administrator sistem.')}
                className="text-[10px] text-cyan-400 hover:text-cyan-300 hover:underline transition-colors"
              >
                Lupa Sandi?
              </button>
            </div>
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <Lock className="w-4 h-4 text-cyan-500/60 group-focus-within:text-cyan-400 transition-colors" />
              </div>
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="input-neon-focus w-full pl-11 pr-12 py-3.5 bg-slate-950/50 border border-slate-700/50 rounded-xl text-sm text-white placeholder:text-slate-600 transition-all duration-300"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-4 flex items-center text-slate-500 hover:text-cyan-400 transition-colors cursor-pointer"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Buttons */}
          <div className="pt-4 space-y-4">
            <button
              type="submit"
              disabled={isLoading}
              className="relative w-full py-3.5 px-6 bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white font-bold text-sm rounded-xl shadow-[0_0_20px_rgba(14,165,233,0.4)] hover:shadow-[0_0_30px_rgba(14,165,233,0.6)] active:scale-[0.98] transition-all duration-200 flex items-center justify-center gap-2 group overflow-hidden"
            >
              <div className="absolute inset-0 w-full h-full bg-white/20 -translate-x-full group-hover:translate-x-full transition-transform duration-500 ease-out transform skew-x-12"></div>
              {isLoading ? (
                <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
              ) : (
                <>
                  <span>Masuk ke Akun</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </>
              )}
            </button>

            <button
              type="button"
              onClick={handleGoogleLogin}
              disabled={isLoading}
              className="w-full py-3.5 px-4 text-xs font-semibold text-slate-900 bg-white rounded-xl shadow-md hover:bg-slate-50 transition-all duration-300 flex items-center justify-center gap-2"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
              </svg>
              <span>Lanjut dengan Google</span>
            </button>

            {onContinueAsGuest && (
              <button
                type="button"
                onClick={onContinueAsGuest}
                className="w-full py-3.5 px-4 text-xs font-semibold text-cyan-400 bg-transparent rounded-xl border border-cyan-500/40 shadow-[0_0_10px_rgba(34,211,238,0.15)] hover:shadow-[0_0_25px_rgba(34,211,238,0.4)] hover:bg-cyan-950/30 transition-all duration-300 flex items-center justify-center gap-2"
              >
                <span>Lanjut sebagai Tamu</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </form>
        
        {/* Helper Actions */}
        <div className="mt-8 flex justify-center">
          <button
            type="button"
            onClick={() => {
              setEmail('admin@enterprise.com');
              setPassword('ProSecure2026!');
              showNotification('Kredensial demo otomatis diisi.');
            }}
            className="flex items-center gap-1.5 text-[10px] font-medium text-slate-400 hover:text-cyan-400 transition-colors px-3 py-1.5 rounded-full border border-slate-700/50 hover:border-cyan-500/50 bg-slate-900/50 backdrop-blur-sm cursor-pointer"
          >
            <KeyRound className="w-3 h-3" />
            <span>Isi Akun Demo Admin</span>
          </button>
        </div>
      </div>
    </main>
  );
};

