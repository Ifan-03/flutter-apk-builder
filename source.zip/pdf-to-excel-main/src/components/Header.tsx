import React, { useState, useEffect } from 'react';
import { 
  FileSpreadsheet, 
  Sparkles, 
  FileText, 
  Phone, 
  Receipt, 
  CreditCard, 
  CheckCircle2,
  Sliders,
  Play,
  Activity,
  AlertCircle,
  Brain,
  Crown,
  Lock,
  Save,
  Check,
  RefreshCw,
  Trash2,
  Moon,
  Sun
} from 'lucide-react';
import { ExtractionStats, HealthCheckReport } from '../types';
import { formatAutoSaveTime } from '../utils/storage';

interface HeaderProps {
  stats: ExtractionStats;
  healthReport?: HealthCheckReport;
  user?: { status: 'free' | 'premium' | string; email?: string, role?: string };
  autoSaveStatus?: {
    lastSavedAt: number | null;
    isSaving: boolean;
  };
  currentView?: 'dashboard' | 'login';
  dashboardMode?: 'table' | 'analytics';
  onSwitchView?: (view: 'dashboard' | 'login') => void;
  onSwitchDashboardMode?: (mode: 'table' | 'analytics') => void;
  onManualSave?: () => void;
  onClearSavedData?: () => void;
  onCloudSync?: () => void;
  onToggleUserStatus?: () => void;
  onOpenUpgradeModal?: () => void;
  onOpenLoginModal?: () => void;
  onOpenCustomRegex: () => void;
  onLoadSample: (type: 'invoice' | 'contacts') => void;
  onOpenAiExtract: () => void;
  onOpenHealthCheck: () => void;
  onOpenMlCategorizer?: () => void;
  hasFiles: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  stats,
  healthReport,
  user,
  autoSaveStatus,
  currentView = 'dashboard',
  dashboardMode,
  onSwitchView,
  onSwitchDashboardMode,
  onManualSave,
  onClearSavedData,
  onCloudSync,
  onToggleUserStatus,
  onOpenUpgradeModal,
  onOpenLoginModal,
  onOpenCustomRegex,
  onLoadSample,
  onOpenAiExtract,
  onOpenHealthCheck,
  onOpenMlCategorizer,
  hasFiles,
}) => {
  const issueCount = healthReport?.issues.length ?? 0;
  const criticalCount = healthReport?.criticalCount ?? 0;
  const healthScore = healthReport?.healthScore ?? 100;
  const isPremium = user?.status === 'premium';
  const [showAutoSaveDropdown, setShowAutoSaveDropdown] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);

  useEffect(() => {
    const savedMode = localStorage.getItem('theme');
    if (savedMode === 'dark' || (!savedMode && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      setIsDarkMode(true);
      document.documentElement.classList.add('dark');
    }
  }, []);

  const toggleDarkMode = () => {
    if (isDarkMode) {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
      setIsDarkMode(false);
    } else {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
      setIsDarkMode(true);
    }
  };

  return (
    <header id="app-header" className="bg-white border-b border-slate-200 sticky top-0 z-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          
          {/* Brand & Title */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-indigo-600 rounded-lg flex items-center justify-center text-white shadow-xs">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-lg font-semibold text-slate-900 tracking-tight">
                  PDF Number Extractor Pro
                </h1>
                <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-100">
                  Excel & CSV
                </span>

                {/* Auto-Save Persistent Status Badge */}
                {autoSaveStatus && (
                  <div className="relative inline-block">
                    <button
                      type="button"
                      id="btn-autosave-status"
                      onClick={() => setShowAutoSaveDropdown(!showAutoSaveDropdown)}
                      className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[10.5px] font-medium bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-200 transition-colors cursor-pointer"
                      title="Status Auto-Save LocalStorage"
                    >
                      {autoSaveStatus.isSaving ? (
                        <>
                          <RefreshCw className="w-3 h-3 text-indigo-600 animate-spin" />
                          <span className="text-indigo-700">Menyimpan...</span>
                        </>
                      ) : autoSaveStatus.lastSavedAt ? (
                        <>
                          <Save className="w-3 h-3 text-emerald-600" />
                          <span className="text-slate-600">
                            Auto-Save:{' '}
                            <strong className="text-slate-800 font-mono">
                              {formatAutoSaveTime(autoSaveStatus.lastSavedAt)}
                            </strong>
                          </span>
                        </>
                      ) : (
                        <>
                          <Save className="w-3 h-3 text-slate-400" />
                          <span className="text-slate-400">Auto-Save Siap</span>
                        </>
                      )}
                    </button>

                    {showAutoSaveDropdown && (
                      <div className="absolute left-0 mt-1.5 w-64 bg-white border border-slate-200 rounded-xl shadow-xl p-3 z-50 animate-in fade-in zoom-in-95 duration-100">
                        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                          <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                            Penyimpanan Otomatis
                          </span>
                          <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                        </div>
                        <p className="text-[11px] text-slate-500 my-2 leading-relaxed">
                          Status file dan hasil ekstraksi disimpan berkala ke browser LocalStorage agar tidak hilang saat halaman di-refresh.
                        </p>
                        <div className="space-y-1.5 pt-1">
                          {onManualSave && (
                            <button
                              type="button"
                              onClick={() => {
                                onManualSave();
                                setShowAutoSaveDropdown(false);
                              }}
                              className="w-full inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors cursor-pointer"
                            >
                              <Save className="w-3.5 h-3.5" />
                              <span>Simpan Sekarang</span>
                            </button>
                          )}
                          {hasFiles && onClearSavedData && (
                            <button
                              type="button"
                              onClick={() => {
                                if (confirm('Apakah Anda yakin ingin menghapus data tersimpan dan memulai sesi baru?')) {
                                  onClearSavedData();
                                  setShowAutoSaveDropdown(false);
                                }
                              }}
                              className="w-full inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>Bersihkan Cache & Reset</span>
                            </button>
                          )}
                          {onCloudSync && (
                            <button
                              type="button"
                              onClick={() => {
                                onCloudSync();
                                setShowAutoSaveDropdown(false);
                              }}
                              className="w-full inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors cursor-pointer"
                            >
                              <RefreshCw className="w-3.5 h-3.5" />
                              <span>Sinkronisasi ke Cloud</span>
                            </button>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {user && (
                  <button
                    type="button"
                    onClick={onToggleUserStatus}
                    className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border transition-all cursor-pointer ${
                      isPremium
                        ? 'bg-amber-100 text-amber-800 border-amber-300 hover:bg-amber-200'
                        : 'bg-slate-100 text-slate-600 border-slate-300 hover:bg-slate-200'
                    }`}
                    title="Klik untuk mengubah status user (Free / Premium)"
                  >
                    {isPremium ? (
                      <>
                        <Crown className="w-3 h-3 text-amber-600 fill-amber-500" />
                        <span>Premium</span>
                      </>
                    ) : (
                      <>
                        <Lock className="w-3 h-3 text-slate-500" />
                        <span>Free Tier</span>
                      </>
                    )}
                  </button>
                )}

                {onSwitchView && (
                  <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200 text-xs">
                    <button
                      type="button"
                      onClick={() => onSwitchView('dashboard')}
                      className={`px-2.5 py-0.5 rounded-md text-[11px] font-semibold transition-all cursor-pointer ${
                        currentView === 'dashboard'
                          ? 'bg-white text-slate-900 shadow-2xs'
                          : 'text-slate-500 hover:text-slate-800'
                      }`}
                    >
                      Dashboard
                    </button>
                    <button
                      type="button"
                      onClick={() => onSwitchView('login')}
                      className={`px-2.5 py-0.5 rounded-md text-[11px] font-semibold transition-all cursor-pointer ${
                        currentView === 'login'
                          ? 'bg-white text-slate-900 shadow-2xs'
                          : 'text-slate-500 hover:text-slate-800'
                      }`}
                    >
                      Halaman Login
                    </button>
                  </div>
                )}

                {user?.role === 'admin' && onSwitchDashboardMode && currentView === 'dashboard' && (
                  <div className="flex items-center bg-indigo-50 p-0.5 rounded-lg border border-indigo-100 text-xs ml-2">
                    <button
                      type="button"
                      onClick={() => onSwitchDashboardMode('table')}
                      className={`px-2.5 py-0.5 rounded-md text-[11px] font-semibold transition-all cursor-pointer flex items-center gap-1 ${
                        dashboardMode === 'table'
                          ? 'bg-white text-indigo-700 shadow-2xs'
                          : 'text-indigo-400 hover:text-indigo-600'
                      }`}
                    >
                      <FileText className="w-3 h-3" /> Data Tabel
                    </button>
                    <button
                      type="button"
                      onClick={() => onSwitchDashboardMode('analytics')}
                      className={`px-2.5 py-0.5 rounded-md text-[11px] font-semibold transition-all cursor-pointer flex items-center gap-1 ${
                        dashboardMode === 'analytics'
                          ? 'bg-white text-indigo-700 shadow-2xs'
                          : 'text-indigo-400 hover:text-indigo-600'
                      }`}
                    >
                      <Activity className="w-3 h-3" /> Analitik
                    </button>
                  </div>
                )}

                {onOpenLoginModal && !onSwitchView && (
                  <button
                    type="button"
                    id="btn-header-login-modal"
                    onClick={onOpenLoginModal}
                    className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[10.5px] font-semibold text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-100 border border-slate-200 shadow-2xs transition-colors cursor-pointer"
                    title="Buka Halaman / Modal Login"
                  >
                    <span>Masuk</span>
                  </button>
                )}
              </div>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                Ekstrak otomatis nomor telepon, invoice, NIK, rekening & nominal dari PDF
              </p>
            </div>
          </div>

          {/* Quick Action Tools */}
          <div className="flex items-center flex-wrap gap-2">
            <button
              onClick={toggleDarkMode}
              className="inline-flex items-center justify-center p-1.5 text-slate-500 hover:text-slate-900 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg shadow-2xs transition-colors cursor-pointer"
              title={isDarkMode ? 'Beralih ke Light Mode' : 'Beralih ke Dark Mode'}
            >
              {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            
            {!hasFiles && (
              <div className="flex items-center gap-1.5 bg-slate-50 p-1 rounded-lg border border-slate-200">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 pl-2 pr-1 flex items-center gap-1">
                  <Play className="w-3 h-3 text-indigo-600" /> Contoh:
                </span>
                <button
                  id="btn-sample-invoice"
                  onClick={() => onLoadSample('invoice')}
                  className="px-2.5 py-1 text-xs font-medium bg-white hover:bg-slate-100 text-slate-700 rounded-md border border-slate-200 shadow-2xs transition-colors cursor-pointer"
                >
                  Invoice & Rekening
                </button>
                <button
                  id="btn-sample-contacts"
                  onClick={() => onLoadSample('contacts')}
                  className="px-2.5 py-1 text-xs font-medium bg-white hover:bg-slate-100 text-slate-700 rounded-md border border-slate-200 shadow-2xs transition-colors cursor-pointer"
                >
                  12 Kontak WA
                </button>
              </div>
            )}

            {/* Data Health Check Button in Toolbar */}
            {hasFiles && (
              <button
                id="btn-data-health-check"
                onClick={onOpenHealthCheck}
                className={`inline-flex items-center gap-2 px-3 py-1.5 text-xs font-semibold rounded-lg shadow-2xs transition-all border cursor-pointer ${
                  criticalCount > 0
                    ? 'bg-rose-50 hover:bg-rose-100 text-rose-700 border-rose-200'
                    : issueCount > 0
                    ? 'bg-amber-50 hover:bg-amber-100 text-amber-700 border-amber-200'
                    : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border-emerald-200'
                }`}
                title="Periksa kesehatan data, deteksi nomor telepon terpotong, nominal minus & duplikasi invoice"
              >
                <Activity className={`w-3.5 h-3.5 ${criticalCount > 0 ? 'animate-pulse text-rose-600' : ''}`} />
                <span>Health Check</span>
                <span
                  className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono font-bold ${
                    criticalCount > 0
                      ? 'bg-rose-600 text-white'
                      : issueCount > 0
                      ? 'bg-amber-600 text-white'
                      : 'bg-emerald-600 text-white'
                  }`}
                >
                  {issueCount > 0 ? `${issueCount} issue` : `${healthScore}%`}
                </span>
              </button>
            )}

            {/* ML Auto-Categorizer Button */}
            {hasFiles && onOpenMlCategorizer && (
              <button
                id="btn-header-ml-categorizer"
                onClick={onOpenMlCategorizer}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-lg shadow-2xs transition-all cursor-pointer"
                title="Klasifikasikan otomatis nomor tak dikenal menggunakan NLP Machine Learning"
              >
                <Brain className="w-3.5 h-3.5 text-indigo-600" />
                <span>Auto-Categorizer ML</span>
              </button>
            )}

            <button
              id="btn-custom-regex"
              onClick={onOpenCustomRegex}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-2xs transition-colors cursor-pointer"
            >
              <Sliders className="w-3.5 h-3.5 text-slate-500" />
              <span>Pola Regex Custom</span>
            </button>

            {hasFiles && (
              <button
                id="btn-ai-extract"
                onClick={onOpenAiExtract}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm shadow-indigo-100 transition-all cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>AI Smart Analysis</span>
              </button>
            )}
          </div>
        </div>

        {/* Live Counters Banner if files present */}
        {hasFiles && (
          <div className="mt-3 pt-3 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 text-xs">
            <div className="bg-slate-50 border border-slate-200/80 rounded-lg px-3 py-2 flex items-center justify-between">
              <span className="text-slate-500 flex items-center gap-1 text-xs">
                <FileText className="w-3.5 h-3.5 text-slate-400" /> Total Nomor:
              </span>
              <span className="font-semibold text-slate-900 font-mono text-sm">{stats.totalNumbers}</span>
            </div>

            <div className="bg-indigo-50/60 border border-indigo-100 rounded-lg px-3 py-2 flex items-center justify-between">
              <span className="text-indigo-800 flex items-center gap-1 text-xs font-medium">
                <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600" /> Nomor Unik:
              </span>
              <span className="font-bold text-indigo-700 font-mono text-sm">{stats.uniqueNumbers}</span>
            </div>

            <div className="bg-white border border-slate-200 rounded-lg px-3 py-2 flex items-center justify-between">
              <span className="text-slate-600 flex items-center gap-1 text-xs">
                <Phone className="w-3.5 h-3.5 text-indigo-500" /> Telepon/WA:
              </span>
              <span className="font-semibold text-slate-800 font-mono text-sm">{stats.phoneCount}</span>
            </div>

            <div className="bg-white border border-slate-200 rounded-lg px-3 py-2 flex items-center justify-between">
              <span className="text-slate-600 flex items-center gap-1 text-xs">
                <Receipt className="w-3.5 h-3.5 text-slate-400" /> Invoice/PO:
              </span>
              <span className="font-semibold text-slate-800 font-mono text-sm">{stats.invoiceCount}</span>
            </div>

            <div className="bg-white border border-slate-200 rounded-lg px-3 py-2 flex items-center justify-between">
              <span className="text-slate-600 flex items-center gap-1 text-xs">
                <CreditCard className="w-3.5 h-3.5 text-slate-400" /> Rekening:
              </span>
              <span className="font-semibold text-slate-800 font-mono text-sm">{stats.bankAccountCount}</span>
            </div>

            <div className="bg-white border border-slate-200 rounded-lg px-3 py-2 flex items-center justify-between">
              <span className="text-slate-600 flex items-center gap-1 text-xs">
                <FileSpreadsheet className="w-3.5 h-3.5 text-slate-400" /> NIK & Lainnya:
              </span>
              <span className="font-semibold text-slate-800 font-mono text-sm">{stats.idCardCount + stats.currencyCount + stats.serialCount}</span>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};
