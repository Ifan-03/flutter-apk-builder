import React, { useState, useMemo } from 'react';
import {
  Brain,
  X,
  Sparkles,
  Sliders,
  Check,
  CheckCircle2,
  FileText,
  CreditCard,
  Building2,
  HelpCircle,
  Play,
  Search,
  Zap,
  Info,
  Layers,
  ArrowRight,
  RotateCcw
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { ExtractedNumber, MlClassificationResult } from '../types';
import {
  classifyUnknownNumber,
  autoClassifyNumbers,
  getMlAutoCategorizeStats
} from '../utils/mlAutoCategorizer';

interface MlCategorizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: ExtractedNumber[];
  onApplyClassification: (updatedItems: ExtractedNumber[], count: number) => void;
}

export const MlCategorizerModal: React.FC<MlCategorizerModalProps> = ({
  isOpen,
  onClose,
  items,
  onApplyClassification,
}) => {
  const [threshold, setThreshold] = useState<number>(0.52);
  const [targetInvoice, setTargetInvoice] = useState(true);
  const [targetNik, setTargetNik] = useState(true);
  const [targetBank, setTargetBank] = useState(true);
  const [onlyUnclassified, setOnlyUnclassified] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCandidateIds, setSelectedCandidateIds] = useState<Set<string>>(new Set());
  const [hasInitializedSelection, setHasInitializedSelection] = useState(false);

  // Playground state for testing ML model interactively
  const [activeTab, setActiveTab] = useState<'batch' | 'playground'>('batch');
  const [testNumber, setTestNumber] = useState('01283918239');
  const [testContext, setTestContext] = useState('Mohon transfer pembayaran tagihan ke rekening Mandiri 01283918239 a/n CV Maju Bersama.');

  // Current dataset candidate evaluation
  const targetCategories = useMemo(() => {
    const list: ('invoice' | 'id_card' | 'bank_account')[] = [];
    if (targetInvoice) list.push('invoice');
    if (targetNik) list.push('id_card');
    if (targetBank) list.push('bank_account');
    return list;
  }, [targetInvoice, targetNik, targetBank]);

  const stats = useMemo(() => {
    return getMlAutoCategorizeStats(items);
  }, [items]);

  // Evaluate ML classifications across all items based on current options
  const evaluatedCandidates = useMemo(() => {
    const candidates: Array<{
      item: ExtractedNumber;
      result: MlClassificationResult;
      isCurrentlyTarget: boolean;
    }> = [];

    items.forEach((item) => {
      const isUnclassified = item.category === 'other' || item.category === 'custom' || !item.category;
      if (onlyUnclassified && !isUnclassified) return;

      const result = classifyUnknownNumber(item.context, item.rawNumber, item.category, {
        threshold,
        targetCategoriesOnly: targetCategories,
      });

      if (result.isClassified && result.predictedCategory) {
        candidates.push({
          item,
          result,
          isCurrentlyTarget: true,
        });
      }
    });

    return candidates;
  }, [items, threshold, targetCategories, onlyUnclassified]);

  // Initialize selected candidate ids when candidates change
  React.useEffect(() => {
    if (isOpen && !hasInitializedSelection) {
      const allIds = new Set(evaluatedCandidates.map((c) => c.item.id));
      setSelectedCandidateIds(allIds);
      setHasInitializedSelection(true);
    }
  }, [isOpen, evaluatedCandidates, hasInitializedSelection]);

  // Filtered candidate list based on search
  const filteredCandidates = useMemo(() => {
    if (!searchQuery.trim()) return evaluatedCandidates;
    const q = searchQuery.toLowerCase().trim();
    return evaluatedCandidates.filter(
      (c) =>
        c.item.rawNumber.toLowerCase().includes(q) ||
        c.item.context.toLowerCase().includes(q) ||
        c.item.fileName.toLowerCase().includes(q) ||
        c.result.suggestedLabel.toLowerCase().includes(q)
    );
  }, [evaluatedCandidates, searchQuery]);

  // Interactive Playground ML calculation
  const playgroundResult: MlClassificationResult = useMemo(() => {
    return classifyUnknownNumber(testContext, testNumber, 'other', {
      threshold,
      targetCategoriesOnly: targetCategories,
    });
  }, [testContext, testNumber, threshold, targetCategories]);

  if (!isOpen) return null;

  const handleToggleCandidate = (id: string) => {
    setSelectedCandidateIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleSelectAll = (select: boolean) => {
    if (select) {
      setSelectedCandidateIds(new Set(filteredCandidates.map((c) => c.item.id)));
    } else {
      setSelectedCandidateIds(new Set());
    }
  };

  const handleApply = () => {
    if (selectedCandidateIds.size === 0) {
      alert('Pilih setidaknya satu nomor untuk menerapkan auto-klasifikasi.');
      return;
    }

    // Build map of classifications
    const candidateMap = new Map<string, MlClassificationResult>();
    evaluatedCandidates.forEach((c) => {
      if (selectedCandidateIds.has(c.item.id)) {
        candidateMap.set(c.item.id, c.result);
      }
    });

    let appliedCount = 0;
    const updatedItems = items.map((item) => {
      const result = candidateMap.get(item.id);
      if (result && result.predictedCategory) {
        appliedCount++;
        return {
          ...item,
          category: result.predictedCategory,
          label: result.suggestedLabel,
          entityName: result.suggestedEntity || item.entityName,
          isMlCategorized: true,
          mlConfidence: result.confidence,
          mlExplanation: result.explanation,
          confidence: Math.max(item.confidence || 0.8, result.confidence),
        };
      }
      return item;
    });

    // Fire celebratory confetti
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 },
      });
    } catch {}

    onApplyClassification(updatedItems, appliedCount);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        id="ml-categorizer-modal"
        className="bg-white rounded-2xl border border-slate-200 max-w-4xl w-full overflow-hidden flex flex-col max-h-[92vh] shadow-2xl"
      >
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900">Machine Learning Auto-Categorizer</h3>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
                  NLP Naive Bayes
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Klasifikasikan nomor tak dikenal menjadi <strong>Invoice</strong>, <strong>NIK</strong>, atau <strong>Rekening Bank</strong> menggunakan model NLP konteks teks.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="px-6 py-2 bg-slate-50 border-b border-slate-200/80 flex items-center justify-between">
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => setActiveTab('batch')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'batch'
                  ? 'bg-white text-indigo-700 shadow-xs border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Klasifikasi Batch ({evaluatedCandidates.length} Terdeteksi)</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('playground')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'playground'
                  ? 'bg-white text-indigo-700 shadow-xs border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Interactive ML Tester / Sandbox</span>
            </button>
          </div>

          <div className="text-[11px] text-slate-500 font-medium hidden sm:block">
            {stats.unclassifiedCount} nomor 'Other' di dataset
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {activeTab === 'batch' && (
            <>
              {/* Configuration Controls Bar */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3.5">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  {/* Target Classes Selection */}
                  <div>
                    <label className="text-xs font-bold text-slate-800 block mb-1.5">
                      Target Kategori Klasifikasi:
                    </label>
                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setTargetInvoice(!targetInvoice)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-medium flex items-center gap-1.5 border transition-colors cursor-pointer ${
                          targetInvoice
                            ? 'bg-amber-50 text-amber-800 border-amber-300 font-semibold'
                            : 'bg-white text-slate-400 border-slate-200 line-through'
                        }`}
                      >
                        <FileText className="w-3 h-3 text-amber-600" />
                        <span>Invoice / Faktur</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setTargetNik(!targetNik)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-medium flex items-center gap-1.5 border transition-colors cursor-pointer ${
                          targetNik
                            ? 'bg-purple-50 text-purple-800 border-purple-300 font-semibold'
                            : 'bg-white text-slate-400 border-slate-200 line-through'
                        }`}
                      >
                        <CreditCard className="w-3 h-3 text-purple-600" />
                        <span>NIK / Identitas</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setTargetBank(!targetBank)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-medium flex items-center gap-1.5 border transition-colors cursor-pointer ${
                          targetBank
                            ? 'bg-teal-50 text-teal-800 border-teal-300 font-semibold'
                            : 'bg-white text-slate-400 border-slate-200 line-through'
                        }`}
                      >
                        <Building2 className="w-3 h-3 text-teal-600" />
                        <span>Rekening Bank</span>
                      </button>
                    </div>
                  </div>

                  {/* Confidence Threshold Slider */}
                  <div className="w-full sm:w-64 bg-white p-3 rounded-lg border border-slate-200">
                    <div className="flex items-center justify-between text-xs font-medium mb-1">
                      <span className="text-slate-600 flex items-center gap-1">
                        <Sliders className="w-3 h-3 text-indigo-600" />
                        Confidence Threshold:
                      </span>
                      <span className="font-mono font-bold text-indigo-700">{Math.round(threshold * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0.40"
                      max="0.85"
                      step="0.02"
                      value={threshold}
                      onChange={(e) => setThreshold(parseFloat(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                    />
                    <div className="flex justify-between text-[9px] text-slate-400 mt-0.5">
                      <span>Sensitif (40%)</span>
                      <span>Ketat (85%)</span>
                    </div>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-200/80 flex flex-wrap items-center justify-between gap-2 text-xs">
                  <label className="flex items-center gap-2 cursor-pointer text-slate-700">
                    <input
                      type="checkbox"
                      checked={onlyUnclassified}
                      onChange={(e) => setOnlyUnclassified(e.target.checked)}
                      className="w-3.5 h-3.5 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300 cursor-pointer"
                    />
                    <span>Hanya klasifikasikan nomor dengan kategori 'Other / Custom'</span>
                  </label>

                  <div className="text-[11px] text-slate-500">
                    Ditemukan <strong className="text-indigo-700">{evaluatedCandidates.length}</strong> kandidat memenuhi syarat
                  </div>
                </div>
              </div>

              {/* Candidate Table Toolbar */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                <div className="flex-1 relative">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Cari kandidat berdasarkan nomor, kata kunci konteks, atau file..."
                    className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg outline-hidden focus:border-indigo-600 focus:bg-white"
                  />
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => handleSelectAll(true)}
                    className="px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors cursor-pointer"
                  >
                    Pilih Semua ({filteredCandidates.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSelectAll(false)}
                    className="px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
                  >
                    Batal Pilih
                  </button>
                </div>
              </div>

              {/* Candidate Table List */}
              <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
                {filteredCandidates.length > 0 ? (
                  <div className="max-h-80 overflow-y-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead className="sticky top-0 bg-slate-100 text-slate-600 text-[11px] font-bold uppercase tracking-wider border-b border-slate-200 z-10">
                        <tr>
                          <th className="p-3 w-10 text-center">
                            <input
                              type="checkbox"
                              checked={
                                filteredCandidates.length > 0 &&
                                filteredCandidates.every((c) => selectedCandidateIds.has(c.item.id))
                              }
                              onChange={(e) => handleSelectAll(e.target.checked)}
                              className="w-3.5 h-3.5 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300 cursor-pointer"
                            />
                          </th>
                          <th className="p-3">Nomor Asli</th>
                          <th className="p-3">Kategori Sekarang</th>
                          <th className="p-3">Prediksi ML & Keyakinan</th>
                          <th className="p-3">Fitur Konteks Terdeteksi</th>
                          <th className="p-3">Konteks Teks</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 bg-white">
                        {filteredCandidates.map(({ item, result }) => {
                          const isSelected = selectedCandidateIds.has(item.id);
                          const predCat = result.predictedCategory;
                          return (
                            <tr
                              key={item.id}
                              className={`transition-colors ${
                                isSelected ? 'bg-indigo-50/40' : 'hover:bg-slate-50/70'
                              }`}
                            >
                              {/* Checkbox */}
                              <td className="p-3 text-center">
                                <input
                                  type="checkbox"
                                  checked={isSelected}
                                  onChange={() => handleToggleCandidate(item.id)}
                                  className="w-3.5 h-3.5 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300 cursor-pointer"
                                />
                              </td>

                              {/* Raw Number */}
                              <td className="p-3 font-mono font-bold text-slate-900">
                                {item.rawNumber}
                                <span className="block text-[10px] font-normal text-slate-400 font-sans">
                                  {item.fileName} • Hal. {item.pageNumber}
                                </span>
                              </td>

                              {/* Current Category */}
                              <td className="p-3">
                                <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-600 border border-slate-200">
                                  {item.category}
                                </span>
                              </td>

                              {/* Predicted ML Category */}
                              <td className="p-3">
                                <div className="space-y-1">
                                  <div className="flex items-center gap-1.5">
                                    <span
                                      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold border ${
                                        predCat === 'invoice'
                                          ? 'bg-amber-50 text-amber-800 border-amber-300'
                                          : predCat === 'id_card'
                                          ? 'bg-purple-50 text-purple-800 border-purple-300'
                                          : 'bg-teal-50 text-teal-800 border-teal-300'
                                      }`}
                                    >
                                      <Sparkles className="w-3 h-3" />
                                      {predCat === 'invoice'
                                        ? 'Invoice'
                                        : predCat === 'id_card'
                                        ? 'NIK / KTP'
                                        : 'Rekening Bank'}
                                    </span>
                                    <span className="font-mono text-[10.5px] font-bold text-indigo-700 bg-indigo-50 px-1.5 py-0.5 rounded border border-indigo-200">
                                      {Math.round(result.confidence * 100)}%
                                    </span>
                                  </div>
                                  <div className="text-[10px] text-slate-500">
                                    {result.suggestedLabel}
                                  </div>
                                </div>
                              </td>

                              {/* Matched Features */}
                              <td className="p-3">
                                <div className="flex flex-wrap gap-1 max-w-[180px]">
                                  {result.topFeatures.slice(0, 3).map((f, i) => (
                                    <span
                                      key={i}
                                      className="px-1.5 py-0.2 rounded text-[9.5px] font-mono bg-slate-100 text-slate-700 border border-slate-200"
                                      title={`Bobot: ${f.weight}`}
                                    >
                                      {f.feature}
                                    </span>
                                  ))}
                                </div>
                              </td>

                              {/* Context Snippet */}
                              <td className="p-3 text-[11px] text-slate-500 font-sans max-w-[220px]">
                                <p className="truncate" title={item.context}>
                                  "{item.context}"
                                </p>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="p-8 text-center bg-slate-50 space-y-2">
                    <div className="w-10 h-10 rounded-xl bg-slate-200/80 text-slate-500 mx-auto flex items-center justify-center">
                      <HelpCircle className="w-5 h-5" />
                    </div>
                    <h5 className="text-xs font-bold text-slate-700">Tidak Ada Kandidat yang Cocok</h5>
                    <p className="text-[11px] text-slate-500 max-w-sm mx-auto">
                      Semua nomor telah terklasifikasi, atau tidak ada nomor tak dikenal dengan nilai keyakinan di atas {Math.round(threshold * 100)}%. Cobalah turunkan ambang batas atau ubah filter.
                    </p>
                  </div>
                )}
              </div>
            </>
          )}

          {/* TAB 2: INTERACTIVE PLAYGROUND / TESTER */}
          {activeTab === 'playground' && (
            <div className="space-y-4">
              <div className="border border-indigo-200 bg-indigo-50/40 rounded-xl p-4">
                <h4 className="text-xs font-bold text-indigo-900 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-indigo-600" />
                  Live ML Classifier Sandbox
                </h4>
                <p className="text-[11px] text-indigo-700 mt-0.5">
                  Uji model machine learning secara langsung dengan memasukkan nomor dan kalimat konteks dokumen. Model akan mengevaluasi distribusi probabilitas dan kata kunci pendukung secara instan.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Left: Input Sandbox */}
                <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      Nomor / String Uji:
                    </label>
                    <input
                      type="text"
                      value={testNumber}
                      onChange={(e) => setTestNumber(e.target.value)}
                      placeholder="Contoh: 01283918239 atau 3201015502900003"
                      className="w-full px-3 py-1.5 text-xs font-mono bg-slate-50 border border-slate-200 rounded-lg outline-hidden focus:border-indigo-600 focus:bg-white"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      Teks Konteks di Sekitar Nomor:
                    </label>
                    <textarea
                      rows={3}
                      value={testContext}
                      onChange={(e) => setTestContext(e.target.value)}
                      placeholder="Ketik kalimat di sekitar nomor..."
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg outline-hidden focus:border-indigo-600 focus:bg-white"
                    />
                  </div>

                  {/* Preset Examples */}
                  <div className="pt-2 border-t border-slate-100 space-y-1.5">
                    <span className="text-[10.5px] font-bold text-slate-400 uppercase tracking-wider block">
                      Contoh Preset Uji:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          setTestNumber('INV-2024-08-992');
                          setTestContext('Tagihan Faktur Pajak INV-2024-08-992 jatuh tempo tanggal 30 Agustus.');
                        }}
                        className="px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10.5px] font-medium cursor-pointer"
                      >
                        Contoh Invoice
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setTestNumber('3201015502900003');
                          setTestContext('Nomor Induk Kependudukan (NIK/KTP): 3201015502900003 Pemegang WNI.');
                        }}
                        className="px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10.5px] font-medium cursor-pointer"
                      >
                        Contoh NIK
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setTestNumber('5210928391');
                          setTestContext('Silakan transfer ke Rekening Bank BCA 5210928391 a/n PT Global.');
                        }}
                        className="px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10.5px] font-medium cursor-pointer"
                      >
                        Contoh Rekening BCA
                      </button>
                    </div>
                  </div>
                </div>

                {/* Right: Real-time ML Output Analysis */}
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3.5">
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                      Hasil Prediksi Machine Learning:
                    </span>
                    <div className="flex items-center gap-2 mt-1">
                      {playgroundResult.isClassified && playgroundResult.predictedCategory ? (
                        <div className="flex items-center gap-2">
                          <span
                            className={`px-3 py-1 rounded-lg text-xs font-bold border flex items-center gap-1.5 ${
                              playgroundResult.predictedCategory === 'invoice'
                                ? 'bg-amber-100 text-amber-800 border-amber-300'
                                : playgroundResult.predictedCategory === 'id_card'
                                ? 'bg-purple-100 text-purple-800 border-purple-300'
                                : 'bg-teal-100 text-teal-800 border-teal-300'
                            }`}
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            {playgroundResult.predictedCategory === 'invoice'
                              ? 'INVOICE / DOKUMEN'
                              : playgroundResult.predictedCategory === 'id_card'
                              ? 'NIK / IDENTITAS'
                              : 'REKENING BANK'}
                          </span>
                          <span className="text-xs font-mono font-bold text-indigo-700 bg-white px-2 py-1 rounded-md border border-slate-200">
                            Keyakinan: {Math.round(playgroundResult.confidence * 100)}%
                          </span>
                        </div>
                      ) : (
                        <span className="px-3 py-1 rounded-lg text-xs font-medium bg-slate-200 text-slate-600">
                          Tidak Terklasifikasi (Di bawah Ambang Batas)
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1.5">{playgroundResult.explanation}</p>
                  </div>

                  {/* Softmax Probability Bars */}
                  <div className="space-y-2 pt-2 border-t border-slate-200">
                    <span className="text-[10.5px] font-bold text-slate-600 block">
                      Distribusi Probabilitas Softmax:
                    </span>

                    {/* Invoice Bar */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[11px] text-slate-600">
                        <span className="font-medium flex items-center gap-1">
                          <FileText className="w-3 h-3 text-amber-600" />
                          Invoice
                        </span>
                        <span className="font-mono font-bold">{Math.round(playgroundResult.probabilities.invoice * 100)}%</span>
                      </div>
                      <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-amber-500 transition-all duration-300"
                          style={{ width: `${playgroundResult.probabilities.invoice * 100}%` }}
                        />
                      </div>
                    </div>

                    {/* NIK Bar */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[11px] text-slate-600">
                        <span className="font-medium flex items-center gap-1">
                          <CreditCard className="w-3 h-3 text-purple-600" />
                          NIK / Identitas
                        </span>
                        <span className="font-mono font-bold">{Math.round(playgroundResult.probabilities.id_card * 100)}%</span>
                      </div>
                      <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-purple-500 transition-all duration-300"
                          style={{ width: `${playgroundResult.probabilities.id_card * 100}%` }}
                        />
                      </div>
                    </div>

                    {/* Bank Account Bar */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[11px] text-slate-600">
                        <span className="font-medium flex items-center gap-1">
                          <Building2 className="w-3 h-3 text-teal-600" />
                          Rekening Bank
                        </span>
                        <span className="font-mono font-bold">{Math.round(playgroundResult.probabilities.bank_account * 100)}%</span>
                      </div>
                      <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-teal-500 transition-all duration-300"
                          style={{ width: `${playgroundResult.probabilities.bank_account * 100}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Top Features */}
                  {playgroundResult.topFeatures.length > 0 && (
                    <div className="pt-2 border-t border-slate-200">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                        Fitur Teks & Bobot Terdeteksi:
                      </span>
                      <div className="flex flex-wrap gap-1">
                        {playgroundResult.topFeatures.map((f, i) => (
                          <span
                            key={i}
                            className="px-2 py-0.5 rounded text-[10px] font-mono bg-white border border-slate-200 text-slate-700"
                          >
                            {f.feature} (w: {f.weight})
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <div className="text-xs text-slate-500">
            {activeTab === 'batch' && (
              <span>
                <strong>{selectedCandidateIds.size}</strong> dari {evaluatedCandidates.length} kandidat dipilih
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-200 bg-slate-100 transition-colors cursor-pointer"
            >
              Tutup
            </button>

            {activeTab === 'batch' && (
              <button
                type="button"
                onClick={handleApply}
                disabled={selectedCandidateIds.size === 0}
                className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 shadow-xs hover:shadow-sm transition-all flex items-center gap-2 cursor-pointer disabled:opacity-40"
              >
                <Zap className="w-3.5 h-3.5" />
                <span>Terapkan Auto-Klasifikasi ({selectedCandidateIds.size})</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
