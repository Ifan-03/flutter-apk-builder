import React from 'react';
import { 
  Search, 
  Filter, 
  Phone, 
  Receipt, 
  CreditCard, 
  DollarSign, 
  SlidersHorizontal, 
  Check, 
  FileText, 
  CopyCheck,
  AlertTriangle,
  Activity
} from 'lucide-react';
import { ExtractionFilter, NumberCategory, PdfFileInfo } from '../types';

interface ExtractionSettingsProps {
  filter: ExtractionFilter;
  onChangeFilter: (newFilter: ExtractionFilter) => void;
  files: PdfFileInfo[];
  totalRawCount: number;
  filteredCount: number;
  healthIssueCount?: number;
  onOpenHealthModal?: () => void;
}

export const ExtractionSettings: React.FC<ExtractionSettingsProps> = ({
  filter,
  onChangeFilter,
  files,
  totalRawCount,
  filteredCount,
  healthIssueCount = 0,
  onOpenHealthModal,
}) => {
  const categories: Array<{ id: NumberCategory; label: string; icon: React.ReactNode }> = [
    { id: 'phone', label: 'Telepon / WhatsApp', icon: <Phone className="w-3.5 h-3.5" /> },
    { id: 'invoice', label: 'Invoice / PO / Resi', icon: <Receipt className="w-3.5 h-3.5" /> },
    { id: 'bank_account', label: 'Rekening Bank / VA', icon: <CreditCard className="w-3.5 h-3.5" /> },
    { id: 'id_card', label: 'NIK / NPWP', icon: <FileText className="w-3.5 h-3.5" /> },
    { id: 'currency', label: 'Nominal Uang', icon: <DollarSign className="w-3.5 h-3.5" /> },
    { id: 'serial_sku', label: 'Serial / SKU', icon: <SlidersHorizontal className="w-3.5 h-3.5" /> },
    { id: 'other', label: 'Nomor Lainnya', icon: <Filter className="w-3.5 h-3.5" /> },
  ];

  const handleCategoryToggle = (catId: NumberCategory) => {
    let nextCategories: NumberCategory[];
    if (filter.categories.includes(catId)) {
      nextCategories = filter.categories.filter((c) => c !== catId);
      if (nextCategories.length === 0) {
        nextCategories = categories.map((c) => c.id);
      }
    } else {
      nextCategories = [...filter.categories, catId];
    }
    onChangeFilter({ ...filter, categories: nextCategories });
  };

  const handleSelectAllCategories = () => {
    onChangeFilter({ ...filter, categories: categories.map((c) => c.id) });
  };

  return (
    <section id="extraction-settings" className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
      {/* Top Search & File Filter Bar */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Search Bar */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            id="input-search-numbers"
            type="text"
            placeholder="Cari nomor, nama entitas, label, atau konteks..."
            value={filter.searchQuery}
            onChange={(e) => onChangeFilter({ ...filter, searchQuery: e.target.value })}
            className="w-full pl-10 pr-4 py-2 text-xs md:text-sm bg-slate-50 hover:bg-slate-100/70 focus:bg-white border border-slate-200 focus:border-indigo-600 rounded-xl outline-hidden transition-all placeholder:text-slate-400"
          />
          {filter.searchQuery && (
            <button
              onClick={() => onChangeFilter({ ...filter, searchQuery: '' })}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-semibold text-slate-400 hover:text-slate-600 bg-slate-200 px-1.5 py-0.5 rounded-full cursor-pointer"
            >
              ✕
            </button>
          )}
        </div>

        {/* File Filter Dropdown */}
        {files.length > 1 && (
          <div className="w-full md:w-64 shrink-0">
            <select
              id="select-file-filter"
              value={filter.selectedFileId}
              onChange={(e) => onChangeFilter({ ...filter, selectedFileId: e.target.value })}
              className="w-full px-3 py-2 text-xs md:text-sm bg-slate-50 border border-slate-200 rounded-xl outline-hidden focus:border-indigo-600 text-slate-700 font-medium cursor-pointer"
            >
              <option value="all">Semua File PDF ({files.length} dokumen)</option>
              {files.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name} ({f.extractedCount})
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* Categories Multi-Select Filter Pills */}
      <div className="flex items-center justify-between flex-wrap gap-2 pt-2 border-t border-slate-100">
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mr-1 flex items-center gap-1">
            <Filter className="w-3 h-3 text-indigo-600" /> Kategori:
          </span>

          <button
            onClick={handleSelectAllCategories}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all border cursor-pointer ${
              filter.categories.length === categories.length
                ? 'bg-slate-900 text-white border-slate-900 shadow-2xs'
                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
            }`}
          >
            Semua
          </button>

          {categories.map((cat) => {
            const isSelected = filter.categories.includes(cat.id);
            return (
              <button
                key={cat.id}
                id={`cat-filter-${cat.id}`}
                onClick={() => handleCategoryToggle(cat.id)}
                className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium transition-all border cursor-pointer ${
                  isSelected
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                    : 'bg-white text-slate-600 border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                }`}
              >
                {cat.icon}
                <span>{cat.label}</span>
                {isSelected && <Check className="w-3 h-3 ml-0.5" />}
              </button>
            );
          })}
        </div>

        {/* Quick Health Issues Filter Pill */}
        {healthIssueCount > 0 && (
          <div className="flex items-center gap-2">
            <button
              onClick={() => onChangeFilter({ ...filter, onlyHealthIssues: !filter.onlyHealthIssues })}
              className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium border transition-all cursor-pointer ${
                filter.onlyHealthIssues
                  ? 'bg-rose-600 text-white border-rose-600 shadow-2xs'
                  : 'bg-rose-50 hover:bg-rose-100 text-rose-700 border-rose-200'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>{filter.onlyHealthIssues ? 'Tampilkan Semua Data' : `Hanya Bermasalah (${healthIssueCount})`}</span>
            </button>

            {onOpenHealthModal && (
              <button
                onClick={onOpenHealthModal}
                className="inline-flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-medium text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 transition-colors cursor-pointer"
                title="Buka ringkasan audit data"
              >
                <Activity className="w-3.5 h-3.5" />
                <span>Audit Detail</span>
              </button>
            )}
          </div>
        )}
      </div>

      {/* Formatting & Duplicate Options Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-3 border-t border-slate-100 text-xs">
        <div className="flex items-center flex-wrap gap-4">
          {/* Duplicate Toggle */}
          <label className="flex items-center gap-2 cursor-pointer select-none font-medium text-slate-700">
            <input
              id="checkbox-remove-duplicates"
              type="checkbox"
              checked={filter.removeDuplicates}
              onChange={(e) => onChangeFilter({ ...filter, removeDuplicates: e.target.checked })}
              className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300 cursor-pointer"
            />
            <span className="flex items-center gap-1">
              <CopyCheck className="w-3.5 h-3.5 text-indigo-600" /> Hapus Duplikat (Nomor Unik)
            </span>
          </label>

          {/* Phone Normalization Format */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400 font-medium">Format Telepon:</span>
            <select
              id="select-phone-format"
              value={filter.phoneFormat}
              onChange={(e) =>
                onChangeFilter({
                  ...filter,
                  phoneFormat: e.target.value as any,
                })
              }
              className="px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-700 outline-hidden focus:border-indigo-600 cursor-pointer"
            >
              <option value="e164_noplus">628xxx (WhatsApp Broadcast / API)</option>
              <option value="e164_plus">+628xxx (Internasional E.164)</option>
              <option value="local_08">08xxx (Format Lokal Indonesia)</option>
              <option value="clean_digits">Hanya Angka Murni</option>
              <option value="original">Format Asli di PDF</option>
            </select>
          </div>
        </div>

        {/* Count summary badge */}
        <div className="text-slate-400 font-medium text-right">
          Menampilkan <span className="font-semibold text-slate-900 font-mono">{filteredCount}</span> dari <span className="font-mono">{totalRawCount}</span> nomor
          {filter.onlyHealthIssues && (
            <span className="ml-1 text-rose-600 font-medium">(Filter masalah aktif)</span>
          )}
        </div>
      </div>
    </section>
  );
};
