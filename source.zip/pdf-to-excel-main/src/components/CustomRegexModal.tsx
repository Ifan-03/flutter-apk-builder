import React, { useState } from 'react';
import { 
  X, 
  Plus, 
  Trash2, 
  Sliders, 
  AlertCircle
} from 'lucide-react';
import { CustomRegexRule, NumberCategory } from '../types';

interface CustomRegexModalProps {
  isOpen: boolean;
  onClose: () => void;
  rules: CustomRegexRule[];
  onSaveRules: (updatedRules: CustomRegexRule[]) => void;
}

export const CustomRegexModal: React.FC<CustomRegexModalProps> = ({
  isOpen,
  onClose,
  rules,
  onSaveRules,
}) => {
  const [localRules, setLocalRules] = useState<CustomRegexRule[]>(rules);
  const [newRuleName, setNewRuleName] = useState('');
  const [newRulePattern, setNewRulePattern] = useState('');
  const [newRuleCategory, setNewRuleCategory] = useState<NumberCategory>('custom');
  const [testInput, setTestInput] = useState('Contoh dokumen dengan kode PO-2025-9988 dan resi JNE882910283');
  const [testResult, setTestResult] = useState<string[]>([]);
  const [testError, setTestError] = useState<string | null>(null);

  if (!isOpen) return null;

  // Run live test of current pattern against test input
  const handleTestRegex = (pattern: string) => {
    if (!pattern) {
      setTestResult([]);
      setTestError(null);
      return;
    }
    try {
      const regex = new RegExp(pattern, 'g');
      const matches: string[] = [];
      let m: RegExpExecArray | null;
      while ((m = regex.exec(testInput)) !== null) {
        matches.push(m[0]);
      }
      setTestResult(matches);
      setTestError(null);
    } catch (err: any) {
      setTestError(err.message || 'Pola Regex tidak valid');
      setTestResult([]);
    }
  };

  const handleAddRule = () => {
    if (!newRulePattern.trim()) {
      alert('Mohon masukkan pola Regular Expression');
      return;
    }

    try {
      new RegExp(newRulePattern.trim());
    } catch (e: any) {
      alert('Regex tidak valid: ' + e.message);
      return;
    }

    const newRule: CustomRegexRule = {
      id: `rule_${Date.now()}`,
      name: newRuleName.trim() || 'Custom Rule',
      pattern: newRulePattern.trim(),
      flags: 'g',
      category: newRuleCategory,
      label: newRuleName.trim() || 'Nomor Custom',
      enabled: true,
    };

    const updated = [...localRules, newRule];
    setLocalRules(updated);
    onSaveRules(updated);

    // Reset inputs
    setNewRuleName('');
    setNewRulePattern('');
    setTestResult([]);
  };

  const handleToggleRule = (id: string) => {
    const updated = localRules.map((r) => (r.id === id ? { ...r, enabled: !r.enabled } : r));
    setLocalRules(updated);
    onSaveRules(updated);
  };

  const handleDeleteRule = (id: string) => {
    const updated = localRules.filter((r) => r.id !== id);
    setLocalRules(updated);
    onSaveRules(updated);
  };

  const presets = [
    {
      name: 'No. Resi JNE / J&T / SiCepat',
      pattern: '\\b(?:JNE|JP|SPX|SOC)[A-Z0-9]{8,15}\\b',
      category: 'invoice' as NumberCategory,
    },
    {
      name: 'Format Faktur Pajak 16-Digit',
      pattern: '\\b\\d{3}\\.\\d{3}-\\d{2}\\.\\d{8}\\b',
      category: 'invoice' as NumberCategory,
    },
    {
      name: 'Plat Nomor Polisi Kendaraan',
      pattern: '\\b[A-Z]{1,2}\\s*\\d{1,4}\\s*[A-Z]{1,3}\\b',
      category: 'custom' as NumberCategory,
    },
    {
      name: 'Kode Voucher 12 Digit (XXXX-XXXX-XXXX)',
      pattern: '\\b[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}\\b',
      category: 'serial_sku' as NumberCategory,
    },
  ];

  const applyPreset = (p: typeof presets[0]) => {
    setNewRuleName(p.name);
    setNewRulePattern(p.pattern);
    setNewRuleCategory(p.category);
    handleTestRegex(p.pattern);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        id="custom-regex-modal" 
        className="bg-white rounded-2xl border border-slate-200 max-w-xl w-full overflow-hidden flex flex-col max-h-[90vh] shadow-xl"
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-white">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                Pattern Config
              </label>
              <h3 className="text-sm font-semibold text-slate-900">Aturan Pola Regex Custom</h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-5">
          {/* Presets */}
          <div>
            <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
              Template Pola Cepat
            </label>
            <div className="flex flex-wrap gap-1.5">
              {presets.map((p, idx) => (
                <button
                  key={idx}
                  onClick={() => applyPreset(p)}
                  className="px-2.5 py-1 rounded-lg text-xs font-medium bg-slate-50 hover:bg-indigo-50 hover:text-indigo-700 text-slate-600 border border-slate-200 transition-colors text-left"
                >
                  + {p.name}
                </button>
              ))}
            </div>
          </div>

          {/* New Rule Form */}
          <div className="bg-slate-50/70 border border-slate-200 rounded-xl p-4 space-y-3">
            <h4 className="text-xs font-semibold text-slate-800 flex items-center gap-1.5">
              <Plus className="w-3.5 h-3.5 text-indigo-600" /> Tambah Aturan Regex Baru
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-medium text-slate-600 mb-1">
                  Nama Label
                </label>
                <input
                  type="text"
                  placeholder="Misal: No. Resi SiCepat"
                  value={newRuleName}
                  onChange={(e) => setNewRuleName(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg outline-hidden focus:border-indigo-600"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-600 mb-1">
                  Kategori
                </label>
                <select
                  value={newRuleCategory}
                  onChange={(e) => setNewRuleCategory(e.target.value as any)}
                  className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg outline-hidden focus:border-indigo-600 font-medium"
                >
                  <option value="phone">Telepon / WhatsApp</option>
                  <option value="invoice">Invoice / PO / Resi</option>
                  <option value="id_card">NIK / NPWP / ID</option>
                  <option value="bank_account">Rekening Bank</option>
                  <option value="currency">Nominal Uang</option>
                  <option value="serial_sku">Serial / SKU</option>
                  <option value="custom">Custom / Lainnya</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-medium text-slate-600 mb-1">
                Pola Regex
              </label>
              <input
                type="text"
                placeholder="Contoh: \bPO-\d{4}-[A-Z]\b atau \b08\d{9,11}\b"
                value={newRulePattern}
                onChange={(e) => {
                  setNewRulePattern(e.target.value);
                  handleTestRegex(e.target.value);
                }}
                className="w-full font-mono text-xs px-3 py-2 bg-white border border-slate-200 rounded-lg outline-hidden focus:border-indigo-600"
              />
            </div>

            {/* Live Tester Box */}
            <div className="pt-2 border-t border-slate-200/70">
              <label className="block text-[11px] font-medium text-slate-400 mb-1">
                Uji Coba Langsung:
              </label>
              <input
                type="text"
                value={testInput}
                onChange={(e) => {
                  setTestInput(e.target.value);
                  handleTestRegex(newRulePattern);
                }}
                className="w-full text-xs px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-slate-700 mb-2 outline-hidden focus:border-indigo-600"
                placeholder="Ketik teks pengujian..."
              />

              {testError ? (
                <div className="flex items-center gap-1 text-xs text-rose-600 font-medium">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>{testError}</span>
                </div>
              ) : (
                <div className="text-xs text-slate-600 flex items-center gap-2 flex-wrap">
                  <span className="font-medium text-slate-400">Hasil Cocok ({testResult.length}):</span>
                  {testResult.length === 0 ? (
                    <span className="text-slate-400 italic">Belum ada</span>
                  ) : (
                    testResult.map((res, i) => (
                      <span key={i} className="font-mono bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded text-[11px] font-medium border border-indigo-100">
                        {res}
                      </span>
                    ))
                  )}
                </div>
              )}
            </div>

            <button
              onClick={handleAddRule}
              className="w-full py-2 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Simpan Aturan Ini</span>
            </button>
          </div>

          {/* Active Rules List */}
          <div>
            <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
              Daftar Aturan Aktif ({localRules.length})
            </label>

            {localRules.length === 0 ? (
              <p className="text-xs text-slate-400 italic p-3 bg-slate-50 rounded-xl text-center">
                Belum ada aturan custom. Pola bawaan sistem tetap aktif otomatis.
              </p>
            ) : (
              <div className="space-y-2">
                {localRules.map((rule) => (
                  <div
                    key={rule.id}
                    className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <div className="flex items-center gap-2.5">
                      <input
                        type="checkbox"
                        checked={rule.enabled}
                        onChange={() => handleToggleRule(rule.id)}
                        className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300 cursor-pointer"
                      />
                      <div>
                        <p className="text-xs font-medium text-slate-800">{rule.name}</p>
                        <p className="text-[11px] font-mono text-slate-400">{rule.pattern}</p>
                      </div>
                    </div>

                    <button
                      onClick={() => handleDeleteRule(rule.id)}
                      className="text-slate-400 hover:text-rose-600 p-1.5 rounded-lg hover:bg-rose-50 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <span className="text-xs text-slate-400">
            Diterapkan langsung ke ekstraksi PDF
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors"
          >
            Selesai
          </button>
        </div>
      </div>
    </div>
  );
};

