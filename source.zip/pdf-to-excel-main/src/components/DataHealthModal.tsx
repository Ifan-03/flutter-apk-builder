import React, { useState, useMemo } from 'react';
import { 
  X, 
  Activity, 
  AlertTriangle, 
  AlertCircle, 
  Info, 
  CheckCircle2, 
  Wrench, 
  Trash2, 
  Edit3, 
  Filter, 
  Sliders, 
  Search, 
  Plus, 
  ShieldCheck, 
  RotateCcw,
  ExternalLink,
  Layers,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { 
  DataHealthIssue, 
  ExtractedNumber, 
  HealthCheckReport, 
  HealthRuleConfig, 
  HealthSeverity, 
  NumberCategory 
} from '../types';
import { getCategoryBadgeStyle, getCategoryLabel } from '../utils/exportUtils';
import { DEFAULT_HEALTH_RULES, applyAutoFixToItem, applyBatchAutoFixes } from '../utils/dataHealthValidator';

interface DataHealthModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: ExtractedNumber[];
  report: HealthCheckReport;
  rules: HealthRuleConfig[];
  onUpdateRules: (newRules: HealthRuleConfig[]) => void;
  onUpdateItems: (newItems: ExtractedNumber[]) => void;
  onEditItem: (item: ExtractedNumber) => void;
  onFilterTableToIssues: () => void;
}

export const DataHealthModal: React.FC<DataHealthModalProps> = ({
  isOpen,
  onClose,
  items,
  report,
  rules,
  onUpdateRules,
  onUpdateItems,
  onEditItem,
  onFilterTableToIssues,
}) => {
  const [activeTab, setActiveTab] = useState<'issues' | 'rules'>('issues');
  const [severityFilter, setSeverityFilter] = useState<'all' | HealthSeverity>('all');
  const [categoryFilter, setCategoryFilter] = useState<'all' | NumberCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [dismissedIssueIds, setDismissedIssueIds] = useState<Set<string>>(new Set());

  // New Custom Rule Form State
  const [showAddRuleForm, setShowAddRuleForm] = useState(false);
  const [newRuleName, setNewRuleName] = useState('');
  const [newRuleRegex, setNewRuleRegex] = useState('');
  const [newRuleSeverity, setNewRuleSeverity] = useState<HealthSeverity>('warning');
  const [newRuleCategory, setNewRuleCategory] = useState<NumberCategory | 'all'>('all');
  const [newRuleDescription, setNewRuleDescription] = useState('');

  // Visible issues excluding dismissed ones
  const activeIssues = useMemo(() => {
    return report.issues.filter((iss) => !dismissedIssueIds.has(iss.id));
  }, [report.issues, dismissedIssueIds]);

  // Filtered issues based on user UI controls
  const filteredIssues = useMemo(() => {
    return activeIssues.filter((issue) => {
      // 1. Severity filter
      if (severityFilter !== 'all' && issue.severity !== severityFilter) {
        return false;
      }

      // Find item
      const item = items.find((i) => i.id === issue.itemId);
      if (!item) return false;

      // 2. Category filter
      if (categoryFilter !== 'all' && item.category !== categoryFilter) {
        return false;
      }

      // 3. Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesText = 
          issue.title.toLowerCase().includes(q) ||
          issue.description.toLowerCase().includes(q) ||
          item.rawNumber.toLowerCase().includes(q) ||
          item.normalizedNumber.toLowerCase().includes(q) ||
          item.fileName.toLowerCase().includes(q) ||
          item.context.toLowerCase().includes(q);

        if (!matchesText) return false;
      }

      return true;
    });
  }, [activeIssues, severityFilter, categoryFilter, searchQuery, items]);

  // Fixable issues count
  const fixableIssues = useMemo(() => {
    return activeIssues.filter((iss) => iss.canAutoFix);
  }, [activeIssues]);

  if (!isOpen) return null;

  const handleDismissIssue = (issueId: string) => {
    setDismissedIssueIds((prev) => new Set([...prev, issueId]));
  };

  const handleSingleAutoFix = (issue: DataHealthIssue) => {
    const { updatedItems, success } = applyAutoFixToItem(items, issue);
    if (success) {
      onUpdateItems(updatedItems);
      handleDismissIssue(issue.id);
      confetti({ particleCount: 35, spread: 45, origin: { y: 0.7 } });
    }
  };

  const handleBatchAutoFix = () => {
    if (fixableIssues.length === 0) return;
    const { updatedItems, fixedCount } = applyBatchAutoFixes(items, fixableIssues);
    onUpdateItems(updatedItems);
    
    // Dismiss all fixed issues
    const fixedIds = new Set(fixableIssues.map((i) => i.id));
    setDismissedIssueIds((prev) => new Set([...prev, ...fixedIds]));

    confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
    alert(`Berhasil memperbaiki ${fixedCount} data secara otomatis!`);
  };

  const handleDeleteItem = (itemId: string, issueId: string) => {
    if (window.confirm('Hapus baris data ini dari hasil ekstraksi?')) {
      onUpdateItems(items.filter((i) => i.id !== itemId));
      handleDismissIssue(issueId);
    }
  };

  const handleToggleRule = (ruleId: string) => {
    const updated = rules.map((r) => (r.id === ruleId ? { ...r, enabled: !r.enabled } : r));
    onUpdateRules(updated);
  };

  const handleResetDefaultRules = () => {
    if (window.confirm('Reset semua aturan validasi ke pengaturan standar?')) {
      onUpdateRules(DEFAULT_HEALTH_RULES);
    }
  };

  const handleAddCustomRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRuleName.trim() || !newRuleRegex.trim()) {
      alert('Nama aturan dan pola regex wajib diisi.');
      return;
    }

    try {
      new RegExp(newRuleRegex);
    } catch {
      alert('Pola Regex tidak valid. Periksa sintaks regex Anda.');
      return;
    }

    const newRule: HealthRuleConfig = {
      id: `custom_rule_${Date.now()}`,
      name: newRuleName.trim(),
      category: newRuleCategory,
      severity: newRuleSeverity,
      description: newRuleDescription.trim() || `Aturan kustom pola /${newRuleRegex}/`,
      enabled: true,
      isCustom: true,
      customRegex: newRuleRegex.trim(),
    };

    onUpdateRules([...rules, newRule]);
    setNewRuleName('');
    setNewRuleRegex('');
    setNewRuleDescription('');
    setShowAddRuleForm(false);
  };

  const handleDeleteCustomRule = (ruleId: string) => {
    onUpdateRules(rules.filter((r) => r.id !== ruleId));
  };

  // Health Score Color
  const getScoreBadge = (score: number) => {
    if (score >= 90) return { bg: 'bg-emerald-500', text: 'text-emerald-700', light: 'bg-emerald-50 border-emerald-200', label: 'Sangat Baik' };
    if (score >= 70) return { bg: 'bg-amber-500', text: 'text-amber-700', light: 'bg-amber-50 border-amber-200', label: 'Perlu Perhatian' };
    return { bg: 'bg-rose-500', text: 'text-rose-700', light: 'bg-rose-50 border-rose-200', label: 'Kritis' };
  };

  const scoreMeta = getScoreBadge(report.healthScore);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        id="data-health-modal"
        className="bg-white rounded-2xl border border-slate-200 max-w-4xl w-full overflow-hidden flex flex-col max-h-[92vh] shadow-2xl"
      >
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-white">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold shadow-2xs">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-semibold text-slate-900">Data Health Check</h3>
                <span className={`px-2 py-0.5 rounded text-[11px] font-semibold border ${scoreMeta.light} ${scoreMeta.text}`}>
                  Skor: {report.healthScore}% • {scoreMeta.label}
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Audit otomatis kesalahan format telepon, nominal negatif, duplikasi invoice, dan integritas digit NIK/NPWP
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Top Health Score & Metrics Strip */}
        <div className="px-6 py-3.5 bg-slate-50 border-b border-slate-200/80 grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center font-bold shrink-0">
              <AlertCircle className="w-5 h-5" />
            </div>
            <div>
              <div className="text-lg font-bold text-slate-900 leading-tight">{report.criticalCount}</div>
              <div className="text-[11px] font-medium text-slate-500">Masalah Kritis</div>
            </div>
          </div>

          <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center font-bold shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <div className="text-lg font-bold text-slate-900 leading-tight">{report.warningCount}</div>
              <div className="text-[11px] font-medium text-slate-500">Peringatan / Duplikat</div>
            </div>
          </div>

          <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold shrink-0">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <div className="text-lg font-bold text-slate-900 leading-tight">{report.healthyCount}</div>
              <div className="text-[11px] font-medium text-slate-500">Data Sehat & Valid</div>
            </div>
          </div>

          <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold shrink-0">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <div className="text-lg font-bold text-slate-900 leading-tight">{report.totalRecords}</div>
              <div className="text-[11px] font-medium text-slate-500">Total Nomor Diperiksa</div>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="px-6 pt-2.5 border-b border-slate-200 bg-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('issues')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-t-lg text-xs font-semibold border-b-2 transition-all cursor-pointer ${
                activeTab === 'issues'
                  ? 'border-indigo-600 text-indigo-600 bg-indigo-50/40'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <AlertCircle className="w-3.5 h-3.5" />
              <span>Daftar Masalah Terdeteksi ({activeIssues.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('rules')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-t-lg text-xs font-semibold border-b-2 transition-all cursor-pointer ${
                activeTab === 'rules'
                  ? 'border-indigo-600 text-indigo-600 bg-indigo-50/40'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>Aturan Validasi Kustom ({rules.length})</span>
            </button>
          </div>

          {/* Quick Actions in Header */}
          {activeTab === 'issues' && fixableIssues.length > 0 && (
            <button
              onClick={handleBatchAutoFix}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-2xs transition-all cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Perbaiki Otomatis Semua ({fixableIssues.length})</span>
            </button>
          )}
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1">
          
          {/* TAB 1: ISSUES LIST */}
          {activeTab === 'issues' && (
            <div className="space-y-4">
              {/* Controls Bar: Search & Filters */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
                {/* Search */}
                <div className="relative flex-1">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Cari masalah, nomor, atau nama dokumen..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl outline-hidden focus:border-indigo-600 focus:bg-white"
                  />
                </div>

                {/* Severity Pills */}
                <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg text-xs shrink-0">
                  <button
                    onClick={() => setSeverityFilter('all')}
                    className={`px-2.5 py-1 rounded font-medium transition-colors cursor-pointer ${
                      severityFilter === 'all' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500'
                    }`}
                  >
                    Semua ({activeIssues.length})
                  </button>
                  <button
                    onClick={() => setSeverityFilter('critical')}
                    className={`px-2.5 py-1 rounded font-medium transition-colors cursor-pointer ${
                      severityFilter === 'critical' ? 'bg-white text-rose-600 shadow-2xs font-semibold' : 'text-slate-500'
                    }`}
                  >
                    Kritis ({report.criticalCount})
                  </button>
                  <button
                    onClick={() => setSeverityFilter('warning')}
                    className={`px-2.5 py-1 rounded font-medium transition-colors cursor-pointer ${
                      severityFilter === 'warning' ? 'bg-white text-amber-600 shadow-2xs font-semibold' : 'text-slate-500'
                    }`}
                  >
                    Peringatan ({report.warningCount})
                  </button>
                </div>
              </div>

              {/* Category Filter Pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1 text-xs">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mr-1 flex items-center gap-1">
                  <Filter className="w-3 h-3 text-slate-400" /> Kategori:
                </span>
                {(['all', 'phone', 'invoice', 'currency', 'id_card', 'bank_account'] as const).map((cat) => {
                  const isActive = categoryFilter === cat;
                  const label = cat === 'all' ? 'Semua Kategori' : getCategoryLabel(cat as NumberCategory);
                  return (
                    <button
                      key={cat}
                      onClick={() => setCategoryFilter(cat)}
                      className={`px-2.5 py-1 rounded-lg border text-[11px] font-medium transition-colors cursor-pointer whitespace-nowrap ${
                        isActive
                          ? 'bg-slate-900 text-white border-slate-900'
                          : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {label}
                    </button>
                  );
                })}
              </div>

              {/* Issues List Feed */}
              {filteredIssues.length === 0 ? (
                <div className="p-12 text-center border border-dashed border-slate-200 rounded-2xl bg-slate-50/50">
                  <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto mb-3">
                    <ShieldCheck className="w-6 h-6" />
                  </div>
                  <h4 className="text-sm font-semibold text-slate-900">
                    {activeIssues.length === 0 ? 'Semua Data Bersih & Lolos Validasi!' : 'Tidak ada masalah yang cocok dengan filter'}
                  </h4>
                  <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
                    {activeIssues.length === 0
                      ? 'Tidak ditemukan kesalahan format telepon, nominal negatif, atau duplikasi nomor invoice pada dokumen Anda.'
                      : 'Coba ubah kata kunci pencarian atau sesuaikan filter tingkat keparahan.'}
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredIssues.map((issue) => {
                    const item = items.find((i) => i.id === issue.itemId);
                    if (!item) return null;

                    const isCritical = issue.severity === 'critical';
                    const isWarning = issue.severity === 'warning';
                    const badge = getCategoryBadgeStyle(item.category);

                    return (
                      <div
                        key={issue.id}
                        id={`issue-card-${issue.id}`}
                        className={`p-4 rounded-xl border transition-all ${
                          isCritical
                            ? 'bg-rose-50/30 border-rose-200 hover:border-rose-300'
                            : isWarning
                            ? 'bg-amber-50/20 border-amber-200 hover:border-amber-300'
                            : 'bg-slate-50 border-slate-200'
                        }`}
                      >
                        <div className="flex flex-col md:flex-row md:items-start justify-between gap-3">
                          {/* Issue Details */}
                          <div className="space-y-1.5 flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span
                                className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                                  isCritical
                                    ? 'bg-rose-100 text-rose-800'
                                    : isWarning
                                    ? 'bg-amber-100 text-amber-800'
                                    : 'bg-slate-200 text-slate-800'
                                }`}
                              >
                                {isCritical && <AlertCircle className="w-3 h-3" />}
                                {isWarning && <AlertTriangle className="w-3 h-3" />}
                                {!isCritical && !isWarning && <Info className="w-3 h-3" />}
                                <span>{issue.ruleName}</span>
                              </span>

                              <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10.5px] font-medium border ${badge.bg} ${badge.text} ${badge.border}`}>
                                {badge.label}
                              </span>

                              <span className="text-[11px] text-slate-400 font-mono">
                                {item.fileName} (Hal. {item.pageNumber})
                              </span>
                            </div>

                            {/* Value Display */}
                            <div className="flex items-baseline gap-2">
                              <span className="text-sm font-bold font-mono text-slate-900 bg-white px-2 py-0.5 rounded border border-slate-200/80">
                                {item.normalizedNumber}
                              </span>
                              {item.rawNumber !== item.normalizedNumber && (
                                <span className="text-xs text-slate-400 font-mono">
                                  (Asli: {item.rawNumber})
                                </span>
                              )}
                            </div>

                            {/* Explanation */}
                            <p className="text-xs text-slate-700 leading-relaxed font-medium">
                              {issue.description}
                            </p>

                            {/* Context snippet */}
                            <p className="text-[11px] text-slate-400 italic bg-white/70 p-2 rounded-lg border border-slate-200/60 line-clamp-2">
                              Konteks Dokumen: "{item.context}"
                            </p>

                            {/* Suggested Fix */}
                            {issue.suggestedFix && (
                              <div className="flex items-center gap-1.5 text-xs text-indigo-700 font-medium pt-0.5">
                                <ArrowRight className="w-3 h-3 shrink-0" />
                                <span>Saran: {issue.suggestedFix}</span>
                              </div>
                            )}
                          </div>

                          {/* Action Buttons */}
                          <div className="flex md:flex-col items-center justify-end gap-1.5 shrink-0 pt-2 md:pt-0">
                            {issue.canAutoFix && (
                              <button
                                onClick={() => handleSingleAutoFix(issue)}
                                className="w-full inline-flex items-center justify-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-2xs transition-colors cursor-pointer"
                              >
                                <Wrench className="w-3.5 h-3.5" />
                                <span>Perbaiki Otomatis</span>
                              </button>
                            )}

                            <button
                              onClick={() => {
                                onEditItem(item);
                                onClose();
                              }}
                              className="w-full inline-flex items-center justify-center gap-1 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors cursor-pointer"
                            >
                              <Edit3 className="w-3.5 h-3.5 text-slate-500" />
                              <span>Edit Nilai</span>
                            </button>

                            <button
                              onClick={() => handleDeleteItem(item.id, issue.id)}
                              className="w-full inline-flex items-center justify-center gap-1 px-3 py-1.5 text-xs font-medium text-rose-600 hover:bg-rose-50 border border-rose-200 rounded-lg transition-colors cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>Hapus Baris</span>
                            </button>

                            <button
                              onClick={() => handleDismissIssue(issue.id)}
                              className="w-full text-center text-[11px] text-slate-400 hover:text-slate-600 py-1 transition-colors cursor-pointer"
                            >
                              Abaikan Masalah
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: RULES CONFIGURATION */}
          {activeTab === 'rules' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-semibold text-slate-900">Konfigurasi Aturan Validasi Kesehatan Data</h4>
                  <p className="text-xs text-slate-500">Aktifkan atau nonaktifkan aturan otomatis sesuai kebutuhan dokumen Anda.</p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleResetDefaultRules}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors cursor-pointer"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Reset Default</span>
                  </button>

                  <button
                    onClick={() => setShowAddRuleForm(!showAddRuleForm)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-2xs transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Tambah Aturan Kustom</span>
                  </button>
                </div>
              </div>

              {/* Add Custom Rule Form Collapse */}
              {showAddRuleForm && (
                <form
                  onSubmit={handleAddCustomRule}
                  className="bg-indigo-50/40 border border-indigo-200 rounded-xl p-4 space-y-3 animate-in fade-in duration-150"
                >
                  <h5 className="text-xs font-bold text-indigo-900 uppercase tracking-wider">
                    Buat Aturan Validasi Regex Baru
                  </h5>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="block font-medium text-slate-700 mb-1">Nama Aturan:</label>
                      <input
                        type="text"
                        placeholder="Contoh: Format Serial Wajib Diawali SN-"
                        value={newRuleName}
                        onChange={(e) => setNewRuleName(e.target.value)}
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg outline-hidden focus:border-indigo-600"
                        required
                      />
                    </div>

                    <div>
                      <label className="block font-medium text-slate-700 mb-1">Pola Regex (Anomali yang Di-flag):</label>
                      <input
                        type="text"
                        placeholder="Contoh: ^(?!SN-).+"
                        value={newRuleRegex}
                        onChange={(e) => setNewRuleRegex(e.target.value)}
                        className="w-full px-2.5 py-1.5 font-mono bg-white border border-slate-200 rounded-lg outline-hidden focus:border-indigo-600"
                        required
                      />
                    </div>

                    <div>
                      <label className="block font-medium text-slate-700 mb-1">Tingkat Keparahan (Severity):</label>
                      <select
                        value={newRuleSeverity}
                        onChange={(e) => setNewRuleSeverity(e.target.value as HealthSeverity)}
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg outline-hidden focus:border-indigo-600"
                      >
                        <option value="critical">Kritis (Critical)</option>
                        <option value="warning">Peringatan (Warning)</option>
                        <option value="info">Informasi (Info)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block font-medium text-slate-700 mb-1">Target Kategori:</label>
                      <select
                        value={newRuleCategory}
                        onChange={(e) => setNewRuleCategory(e.target.value as any)}
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg outline-hidden focus:border-indigo-600"
                      >
                        <option value="all">Semua Kategori</option>
                        <option value="phone">Telepon / WhatsApp</option>
                        <option value="invoice">Invoice / PO</option>
                        <option value="currency">Nominal Uang</option>
                        <option value="id_card">NIK / NPWP</option>
                        <option value="bank_account">Rekening Bank</option>
                        <option value="serial_sku">Serial / SKU</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Deskripsi / Pesan Kesalahan:</label>
                    <input
                      type="text"
                      placeholder="Contoh: Nomor serial produk tidak memenuhi format standar perusahaan (wajib berawalan SN-)."
                      value={newRuleDescription}
                      onChange={(e) => setNewRuleDescription(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg outline-hidden focus:border-indigo-600"
                    />
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setShowAddRuleForm(false)}
                      className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
                    >
                      Batal
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-2xs"
                    >
                      Simpan Aturan Kustom
                    </button>
                  </div>
                </form>
              )}

              {/* Rules List Cards */}
              <div className="space-y-2">
                {rules.map((rule) => (
                  <div
                    key={rule.id}
                    className={`p-3.5 rounded-xl border flex items-center justify-between gap-3 transition-colors ${
                      rule.enabled ? 'bg-white border-slate-200' : 'bg-slate-50/70 border-slate-200/60 opacity-60'
                    }`}
                  >
                    <div className="space-y-1 flex-1">
                      <div className="flex items-center gap-2">
                        <span
                          className={`w-2 h-2 rounded-full ${
                            rule.severity === 'critical'
                              ? 'bg-rose-500'
                              : rule.severity === 'warning'
                              ? 'bg-amber-500'
                              : 'bg-indigo-500'
                          }`}
                        />
                        <h5 className="text-xs font-semibold text-slate-900">{rule.name}</h5>
                        {rule.isCustom && (
                          <span className="px-1.5 py-0.2 rounded text-[9.5px] font-bold bg-purple-50 text-purple-700 border border-purple-200">
                            Kustom
                          </span>
                        )}
                        <span className="text-[10.5px] text-slate-400 uppercase font-mono">
                          [{rule.category}]
                        </span>
                      </div>
                      <p className="text-xs text-slate-500">{rule.description}</p>
                      {rule.customRegex && (
                        <p className="text-[11px] font-mono text-purple-700 bg-purple-50/60 px-2 py-0.5 rounded inline-block">
                          /{rule.customRegex}/
                        </p>
                      )}
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {rule.isCustom && (
                        <button
                          onClick={() => handleDeleteCustomRule(rule.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 rounded hover:bg-rose-50 transition-colors"
                          title="Hapus aturan kustom"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => handleToggleRule(rule.id)}
                        className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden ${
                          rule.enabled ? 'bg-indigo-600' : 'bg-slate-200'
                        }`}
                      >
                        <span
                          className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out ${
                            rule.enabled ? 'translate-x-4' : 'translate-x-0'
                          }`}
                        />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-100 bg-slate-50 flex items-center justify-between text-xs">
          <button
            onClick={() => {
              onFilterTableToIssues();
              onClose();
            }}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-600 hover:text-indigo-700 cursor-pointer"
          >
            <Filter className="w-3.5 h-3.5" />
            <span>Tampilkan {activeIssues.length} Data Bermasalah di Tabel Utama</span>
          </button>

          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
