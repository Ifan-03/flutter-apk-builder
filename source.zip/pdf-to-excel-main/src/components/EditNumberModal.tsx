import React, { useState } from 'react';
import { X, Check, Edit3 } from 'lucide-react';
import { ExtractedNumber, NumberCategory } from '../types';

interface EditNumberModalProps {
  item: ExtractedNumber | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (updatedItem: ExtractedNumber) => void;
}

export const EditNumberModal: React.FC<EditNumberModalProps> = ({
  item,
  isOpen,
  onClose,
  onSave,
}) => {
  if (!isOpen || !item) return null;

  const [normalizedNumber, setNormalizedNumber] = useState(item.normalizedNumber);
  const [rawNumber, setRawNumber] = useState(item.rawNumber);
  const [label, setLabel] = useState(item.label);
  const [entityName, setEntityName] = useState(item.entityName || '');
  const [category, setCategory] = useState<NumberCategory>(item.category);

  const handleSave = () => {
    onSave({
      ...item,
      normalizedNumber: normalizedNumber.trim(),
      rawNumber: rawNumber.trim(),
      label: label.trim(),
      entityName: entityName.trim() || undefined,
      category,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        id="edit-number-modal" 
        className="bg-white rounded-2xl border border-slate-200 max-w-md w-full overflow-hidden flex flex-col shadow-xl"
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-white">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
              <Edit3 className="w-4 h-4" />
            </div>
            <div>
              <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                Edit Item
              </label>
              <h3 className="text-sm font-semibold text-slate-900">Edit Data Nomor</h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Nomor Bersih / Standar
            </label>
            <input
              type="text"
              value={normalizedNumber}
              onChange={(e) => setNormalizedNumber(e.target.value)}
              className="w-full px-3 py-2 text-sm font-mono bg-slate-50 border border-slate-200 rounded-xl font-semibold text-slate-900 outline-hidden focus:border-indigo-600 focus:bg-white"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Teks Asli Dokumen
            </label>
            <input
              type="text"
              value={rawNumber}
              onChange={(e) => setRawNumber(e.target.value)}
              className="w-full px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-200 rounded-xl text-slate-700 outline-hidden focus:border-indigo-600 focus:bg-white"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Kategori
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as NumberCategory)}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-800 outline-hidden focus:border-indigo-600 cursor-pointer"
            >
              <option value="phone">Telepon / WhatsApp</option>
              <option value="invoice">Invoice / PO / Resi</option>
              <option value="id_card">NIK / NPWP / Identitas</option>
              <option value="bank_account">No. Rekening Bank / VA</option>
              <option value="currency">Nominal Keuangan</option>
              <option value="serial_sku">Serial / SKU</option>
              <option value="other">Nomor Lainnya</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Label / Keterangan
            </label>
            <input
              type="text"
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-800 outline-hidden focus:border-indigo-600 focus:bg-white"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Nama Kontak / Entitas (Opsional)
            </label>
            <input
              type="text"
              placeholder="Contoh: Budi Santoso / PT Maju Jaya"
              value={entityName}
              onChange={(e) => setEntityName(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-800 outline-hidden focus:border-indigo-600 focus:bg-white"
            />
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-3.5 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 rounded-lg transition-colors"
          >
            Batal
          </button>
          <button
            onClick={handleSave}
            className="px-3.5 py-1.5 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Check className="w-3.5 h-3.5" />
            <span>Simpan Perubahan</span>
          </button>
        </div>
      </div>
    </div>
  );
};

