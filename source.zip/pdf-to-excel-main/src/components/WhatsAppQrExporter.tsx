import React, { useState, useMemo, useRef } from 'react';
import { 
  QrCode, 
  ExternalLink, 
  Copy, 
  Check, 
  Download, 
  MessageSquare, 
  ChevronLeft, 
  ChevronRight, 
  Printer, 
  Search, 
  Smartphone, 
  Share2,
  FileCode,
  LayoutGrid,
  Square,
  Sparkles,
  Link,
  MessageCircle
} from 'lucide-react';
import { QRCodeSVG, QRCodeCanvas } from 'qrcode.react';
import { ExtractedNumber } from '../types';
import { normalizePhoneNumber } from '../utils/numberExtractor';
import { 
  prepareWaContacts, 
  exportBatchWaHtmlFile, 
  generateBatchWaClickToChatHtml 
} from '../utils/waClickToChatExporter';

interface WhatsAppQrExporterProps {
  items: ExtractedNumber[];
  filename?: string;
}

export const WhatsAppQrExporter: React.FC<WhatsAppQrExporterProps> = ({
  items,
  filename = 'Kontak_WhatsApp_QR',
}) => {
  const [customMessage, setCustomMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [copiedBatchLink, setCopiedBatchLink] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [viewMode, setViewMode] = useState<'single' | 'grid'>('single');

  // Prepare normalized contacts list
  const waContacts = useMemo(() => {
    return prepareWaContacts(items, customMessage);
  }, [items, customMessage]);

  // Filtered phone list according to search
  const filteredContacts = useMemo(() => {
    if (!searchQuery.trim()) return waContacts;
    const q = searchQuery.toLowerCase().trim();
    return waContacts.filter(
      (c) =>
        c.phone.includes(q) ||
        c.formattedPhone.toLowerCase().includes(q) ||
        c.rawNumber.toLowerCase().includes(q) ||
        c.name.toLowerCase().includes(q) ||
        c.fileName.toLowerCase().includes(q) ||
        (c.context && c.context.toLowerCase().includes(q))
    );
  }, [waContacts, searchQuery]);

  // Ensure current index is valid
  const safeIndex = Math.min(Math.max(0, currentIndex), Math.max(0, filteredContacts.length - 1));
  const currentItem = filteredContacts[safeIndex];

  const handleCopySingle = (url: string, id: string) => {
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleOpenWhatsAppWeb = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  // Download individual QR Code as PNG image
  const handleDownloadSingleQrPng = () => {
    if (!currentItem) return;
    const canvas = document.getElementById(`qr-canvas-${currentItem.id}`) as HTMLCanvasElement;
    if (!canvas) {
      alert('Gagal mengambil gambar QR.');
      return;
    }

    const pngUrl = canvas.toDataURL('image/png');
    const downloadLink = document.createElement('a');
    const contactName = currentItem.name.replace(/[^a-zA-Z0-9_-]/g, '_');
    downloadLink.href = pngUrl;
    downloadLink.download = `QR_WA_${contactName}_${currentItem.phone}.png`;
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
  };

  // Preset messages
  const messagePresets = [
    {
      label: 'Konfirmasi Dokumen',
      text: 'Halo, saya ingin mengonfirmasi dokumen yang telah kami terima. Terima kasih.',
    },
    {
      label: 'Info Faktur/Invoice',
      text: 'Halo, kami ingin menanyakan informasi terkait invoice yang terlampir. Mohon bantuannya.',
    },
    {
      label: 'Salam Pembuka Singkat',
      text: 'Halo! Salam kenal, kami menghubungi Anda dari data kontak dokumen terkait.',
    },
  ];

  // Download standalone interactive HTML file containing all Click-to-Chat links
  const handleDownloadHtmlFile = () => {
    if (waContacts.length === 0) return;
    const { download } = exportBatchWaHtmlFile(items, filename, customMessage);
    download();
  };

  // Open standalone batch view directly in a new tab (Instant shareable viewer)
  const handleOpenBatchInNewTab = () => {
    if (waContacts.length === 0) return;
    const { shareUrl } = exportBatchWaHtmlFile(items, filename, customMessage);
    window.open(shareUrl, '_blank');
  };

  // Copy batch Click-to-Chat list as formatted text / markdown
  const handleCopyBatchLinksList = () => {
    if (waContacts.length === 0) return;
    const textList = waContacts
      .map((c, i) => `${i + 1}. ${c.name} (${c.formattedPhone}): ${c.waLink}`)
      .join('\n');
    navigator.clipboard.writeText(textList);
    setCopiedBatchLink(true);
    setTimeout(() => setCopiedBatchLink(false), 2000);
  };

  // Print QR Sheet or Open Standalone Printable HTML
  const handlePrintSheet = () => {
    if (filteredContacts.length === 0) return;

    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Popup blocker memblokir jendela cetak. Izinkan pop-up pada peramban.');
      return;
    }

    const cardsHtml = filteredContacts
      .map((item, idx) => {
        const qrApiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(
          item.waLink
        )}`;

        return `
          <div class="qr-card">
            <div class="header">
              <div class="badge">WA DIRECT</div>
              <h3 class="name">${item.name}</h3>
              <div class="phone">${item.formattedPhone}</div>
            </div>
            <div class="qr-img-wrapper">
              <img src="${qrApiUrl}" alt="QR Code ${item.formattedPhone}" width="160" height="160" />
            </div>
            <div class="footer">
              <span class="scan-label">Scan untuk Chat WhatsApp</span>
              <span class="file-source">${item.fileName} • Hal ${item.pageNumber}</span>
            </div>
          </div>
        `;
      })
      .join('');

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8" />
          <title>Lembar QR Code WhatsApp - ${filename}</title>
          <style>
            * { box-sizing: border-box; margin: 0; padding: 0; }
            body { font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #fff; color: #0f172a; padding: 24px; }
            .sheet-header { border-bottom: 2px solid #e2e8f0; padding-bottom: 14px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }
            .title { font-size: 20px; font-weight: 700; color: #1e293b; }
            .subtitle { font-size: 12px; color: #64748b; margin-top: 4px; }
            .grid-container { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 16px; page-break-inside: avoid; }
            .qr-card { border: 1.5px solid #cbd5e1; border-radius: 12px; padding: 14px; text-align: center; display: flex; flex-direction: column; align-items: center; justify-content: space-between; background: #fafafa; break-inside: avoid; }
            .badge { display: inline-block; background: #25d366; color: #fff; font-size: 9px; font-weight: 800; padding: 2px 6px; border-radius: 4px; letter-spacing: 0.5px; margin-bottom: 4px; }
            .name { font-size: 13px; font-weight: 700; color: #0f172a; max-width: 190px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
            .phone { font-size: 12px; font-weight: 600; font-family: monospace; color: #4338ca; margin-top: 2px; }
            .qr-img-wrapper { background: #fff; padding: 8px; border-radius: 8px; border: 1px solid #e2e8f0; margin: 10px 0; }
            .footer { font-size: 10px; color: #64748b; }
            .scan-label { font-weight: 600; color: #059669; display: block; }
            .file-source { font-size: 9px; color: #94a3b8; margin-top: 2px; }
            @media print {
              body { padding: 10px; }
              .no-print { display: none; }
              .grid-container { grid-template-columns: repeat(3, 1fr); gap: 12px; }
            }
          </style>
        </head>
        <body>
          <div class="sheet-header">
            <div>
              <h1 class="title">Lembar Scan QR Code WhatsApp</h1>
              <p class="subtitle">Total ${filteredContacts.length} kontak terdeteksi dari ekstraksi PDF • Siap discan kamera ponsel</p>
            </div>
            <button class="no-print" onclick="window.print()" style="padding: 8px 16px; background: #25d366; color: #fff; border: none; border-radius: 6px; font-weight: bold; cursor: pointer;">Cetak Lembar Ini</button>
          </div>
          <div class="grid-container">
            ${cardsHtml}
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  if (waContacts.length === 0) {
    return (
      <div className="bg-slate-50 border border-dashed border-slate-300 rounded-xl p-8 text-center space-y-3">
        <div className="w-12 h-12 rounded-xl bg-slate-100 text-slate-400 mx-auto flex items-center justify-center">
          <Smartphone className="w-6 h-6" />
        </div>
        <h4 className="text-sm font-semibold text-slate-700">Tidak Ada Nomor Telepon Terdeteksi</h4>
        <p className="text-xs text-slate-500 max-w-md mx-auto">
          Fitur WhatsApp Click-to-Chat & QR Code membutuhkan data nomor telepon/HP (+62 / 08xx). Dokumen yang Anda pilih saat ini belum mengandung nomor telepon yang valid.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Top Hero Banner with Direct Actions */}
      <div className="border border-emerald-200 bg-gradient-to-br from-emerald-500/10 via-teal-500/10 to-indigo-500/5 rounded-xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold shadow-xs shrink-0 mt-0.5">
            <MessageCircle className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="text-sm font-bold text-slate-900">WhatsApp Click-to-Chat & Batch Exporter</h4>
              <span className="px-2 py-0.5 rounded text-[10.5px] font-bold bg-emerald-600 text-white">
                {waContacts.length} Nomor Siap Chat
              </span>
            </div>
            <p className="text-xs text-slate-600 mt-0.5 max-w-xl">
              Buka chat WhatsApp Web secara instan, unduh katalog HTML interaktif mandiri, atau scan QR Code langsung tanpa simpan kontak.
            </p>
          </div>
        </div>

        {/* Primary Batch Action Buttons */}
        <div className="flex flex-wrap items-center gap-2 self-stretch md:self-auto shrink-0">
          <button
            type="button"
            onClick={handleDownloadHtmlFile}
            className="flex-1 md:flex-initial inline-flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 shadow-xs hover:shadow-sm transition-all cursor-pointer"
            title="Unduh satu file HTML mandiri yang berisi semua tombol WhatsApp Click-to-Chat"
          >
            <Download className="w-4 h-4" />
            <span>Unduh File HTML Batch</span>
          </button>
          
          <button
            type="button"
            onClick={handleOpenBatchInNewTab}
            className="inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-emerald-800 bg-emerald-100/80 hover:bg-emerald-200 border border-emerald-300 transition-colors cursor-pointer"
            title="Buka tampilan web batch langsung di tab baru"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Buka Halaman Share</span>
          </button>
        </div>
      </div>

      {/* Message Template, Search, and Secondary Actions */}
      <div className="bg-white border border-slate-200 rounded-xl p-3.5 space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
          <div className="flex-1 relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentIndex(0);
              }}
              placeholder="Cari nama kontak, nomor telepon, atau sumber file..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg outline-hidden focus:border-emerald-600 focus:bg-white transition-colors"
            />
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleCopyBatchLinksList}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors cursor-pointer"
              title="Salin seluruh daftar tautan wa.me"
            >
              {copiedBatchLink ? (
                <Check className="w-3.5 h-3.5 text-emerald-600" />
              ) : (
                <Copy className="w-3.5 h-3.5 text-slate-600" />
              )}
              <span>{copiedBatchLink ? 'Link Tersalin!' : 'Salin Semua Link'}</span>
            </button>

            <button
              type="button"
              onClick={handlePrintSheet}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors cursor-pointer"
              title="Cetak lembar QR Code untuk di meja kerja"
            >
              <Printer className="w-3.5 h-3.5 text-slate-600" />
              <span>Cetak QR</span>
            </button>

            {/* View Mode Toggle */}
            <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200 text-xs ml-1">
              <button
                type="button"
                onClick={() => setViewMode('single')}
                className={`px-2 py-1 rounded-md font-medium transition-all flex items-center gap-1 cursor-pointer ${
                  viewMode === 'single'
                    ? 'bg-white text-slate-900 shadow-2xs font-semibold'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
                title="Tampilan Fokus Tunggal"
              >
                <Square className="w-3 h-3" />
                <span className="hidden sm:inline">Fokus</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('grid')}
                className={`px-2 py-1 rounded-md font-medium transition-all flex items-center gap-1 cursor-pointer ${
                  viewMode === 'grid'
                    ? 'bg-white text-slate-900 shadow-2xs font-semibold'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
                title="Tampilan Grid Semua Kontak"
              >
                <LayoutGrid className="w-3 h-3" />
                <span className="hidden sm:inline">Grid ({filteredContacts.length})</span>
              </button>
            </div>
          </div>
        </div>

        {/* Optional Custom Initial Message */}
        <div className="space-y-1.5 pt-2 border-t border-slate-100">
          <div className="flex items-center justify-between">
            <label className="text-[11px] font-medium text-slate-600 flex items-center gap-1">
              <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
              <span>Teks Pesan Awal Otomatis (Akan diterapkan ke seluruh tautan Click-to-Chat & QR):</span>
            </label>
            {customMessage && (
              <button
                type="button"
                onClick={() => setCustomMessage('')}
                className="text-[10px] text-rose-500 hover:underline cursor-pointer"
              >
                Hapus Pesan
              </button>
            )}
          </div>
          <input
            type="text"
            value={customMessage}
            onChange={(e) => setCustomMessage(e.target.value)}
            placeholder="Ketik pesan awal yang otomatis terisi saat chat dibuka (contoh: Halo, kami ingin mengonfirmasi dokumen...)"
            className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg outline-hidden focus:border-emerald-600 focus:bg-white"
          />

          {/* Quick preset buttons */}
          <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
            <span className="text-[10px] text-slate-400 font-medium">Preset:</span>
            {messagePresets.map((p, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setCustomMessage(p.text)}
                className="px-2 py-0.5 text-[10.5px] rounded bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 text-slate-600 transition-colors cursor-pointer"
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* VIEW MODE 1: SINGLE FOCUS / SLIDER VIEW */}
      {viewMode === 'single' && (
        <div className="space-y-3">
          {currentItem ? (
            <div className="border border-slate-200 rounded-xl bg-white p-5 shadow-xs">
              <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
                {/* Left: QR Code Card */}
                <div className="md:col-span-5 flex flex-col items-center justify-center p-4 bg-slate-50 rounded-xl border border-slate-200/80">
                  <div className="relative p-3 bg-white rounded-xl shadow-xs border border-slate-200 flex flex-col items-center">
                    {/* SVG for live display */}
                    <QRCodeSVG
                      value={currentItem.waLink}
                      size={180}
                      level="H"
                      marginSize={1}
                      fgColor="#0f172a"
                      bgColor="#ffffff"
                    />

                    {/* Hidden canvas for PNG export */}
                    <div className="hidden">
                      <QRCodeCanvas
                        id={`qr-canvas-${currentItem.id}`}
                        value={currentItem.waLink}
                        size={320}
                        level="H"
                        marginSize={2}
                      />
                    </div>

                    <div className="absolute -top-2.5 bg-emerald-600 text-white text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full shadow-xs">
                      WhatsApp Web
                    </div>
                  </div>

                  <div className="mt-3 text-center">
                    <span className="text-[11px] text-slate-500 font-medium flex items-center justify-center gap-1">
                      <Smartphone className="w-3.5 h-3.5 text-emerald-600" />
                      Arahkan kamera HP ke kode QR
                    </span>
                  </div>
                </div>

                {/* Right: Contact Details & Quick Actions */}
                <div className="md:col-span-7 space-y-3.5">
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="text-[10.5px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100">
                        Kontak #{safeIndex + 1} dari {filteredContacts.length}
                      </span>
                      <span className="text-[11px] text-slate-400 font-medium">
                        Hal. {currentItem.pageNumber} • {currentItem.fileName}
                      </span>
                    </div>

                    <h3 className="text-base font-bold text-slate-900 mt-1.5">
                      {currentItem.name}
                    </h3>

                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-sm font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                        {currentItem.formattedPhone}
                      </span>
                      <span className="text-xs text-slate-400 font-mono">
                        (Raw: {currentItem.rawNumber})
                      </span>
                    </div>
                  </div>

                  {currentItem.context && (
                    <div className="text-[11px] text-slate-500 bg-slate-50 p-2.5 rounded-lg border border-slate-100 font-sans italic line-clamp-2">
                      "{currentItem.context}"
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="space-y-2 pt-1">
                    {/* Primary Button: Open in WhatsApp Web */}
                    <button
                      type="button"
                      onClick={() => handleOpenWhatsAppWeb(currentItem.waLink)}
                      className="w-full py-2.5 px-4 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <ExternalLink className="w-4 h-4" />
                      <span>Buka Chat di WhatsApp Web Sekarang</span>
                    </button>

                    <div className="grid grid-cols-2 gap-2">
                      {/* Copy Direct Link */}
                      <button
                        type="button"
                        onClick={() => handleCopySingle(currentItem.waLink, currentItem.id)}
                        className="py-2 px-3 rounded-lg text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        {copiedId === currentItem.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                        <span>{copiedId === currentItem.id ? 'Link Tersalin!' : 'Salin Link wa.me'}</span>
                      </button>

                      {/* Download Single PNG */}
                      <button
                        type="button"
                        onClick={handleDownloadSingleQrPng}
                        className="py-2 px-3 rounded-lg text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Unduh QR (PNG)</span>
                      </button>
                    </div>
                  </div>

                  {/* Navigation Slider Controls */}
                  {filteredContacts.length > 1 && (
                    <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs">
                      <button
                        type="button"
                        onClick={() => setCurrentIndex((prev) => Math.max(0, prev - 1))}
                        disabled={safeIndex === 0}
                        className="px-2.5 py-1 rounded bg-slate-100 text-slate-700 hover:bg-slate-200 disabled:opacity-30 flex items-center gap-1 cursor-pointer"
                      >
                        <ChevronLeft className="w-3.5 h-3.5" />
                        <span>Sebelumnya</span>
                      </button>

                      <span className="text-[11px] text-slate-400 font-mono">
                        {safeIndex + 1} / {filteredContacts.length}
                      </span>

                      <button
                        type="button"
                        onClick={() => setCurrentIndex((prev) => Math.min(filteredContacts.length - 1, prev + 1))}
                        disabled={safeIndex === filteredContacts.length - 1}
                        className="px-2.5 py-1 rounded bg-slate-100 text-slate-700 hover:bg-slate-200 disabled:opacity-30 flex items-center gap-1 cursor-pointer"
                      >
                        <span>Berikutnya</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="p-6 text-center text-xs text-slate-500 bg-slate-50 rounded-xl">
              Tidak ada kontak yang cocok dengan pencarian "{searchQuery}".
            </div>
          )}
        </div>
      )}

      {/* VIEW MODE 2: BATCH GRID OF ALL QR CODES & CLICK-TO-CHAT BUTTONS */}
      {viewMode === 'grid' && (
        <div className="space-y-3">
          <div className="max-h-96 overflow-y-auto pr-1">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {filteredContacts.map((item, idx) => (
                <div
                  key={item.id}
                  className="bg-white border border-slate-200 hover:border-emerald-400 rounded-xl p-3.5 flex flex-col items-center text-center justify-between gap-2.5 transition-all shadow-2xs"
                >
                  <div className="w-full flex items-center justify-between text-[10px] text-slate-400">
                    <span className="font-mono bg-slate-100 px-1.5 py-0.5 rounded font-semibold text-slate-600">
                      #{idx + 1}
                    </span>
                    <span className="truncate max-w-[120px]">Hal. {item.pageNumber}</span>
                  </div>

                  <div className="w-full">
                    <h5 className="text-xs font-bold text-slate-900 truncate" title={item.name}>
                      {item.name}
                    </h5>
                    <div className="text-[11px] font-mono font-semibold text-emerald-700 mt-0.5">
                      {item.formattedPhone}
                    </div>
                  </div>

                  <div className="p-2 bg-slate-50 rounded-lg border border-slate-100">
                    <QRCodeSVG
                      value={item.waLink}
                      size={110}
                      level="M"
                      marginSize={1}
                      fgColor="#0f172a"
                    />
                  </div>

                  <div className="w-full grid grid-cols-2 gap-1.5 pt-1">
                    <button
                      type="button"
                      onClick={() => handleOpenWhatsAppWeb(item.waLink)}
                      className="py-1.5 px-2 rounded-md bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold flex items-center justify-center gap-1 transition-colors cursor-pointer shadow-2xs"
                      title="Buka Chat WhatsApp Web"
                    >
                      <ExternalLink className="w-3 h-3" />
                      <span>Chat WA</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleCopySingle(item.waLink, item.id)}
                      className="py-1.5 px-2 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-medium flex items-center justify-center gap-1 transition-colors cursor-pointer"
                      title="Salin tautan wa.me"
                    >
                      {copiedId === item.id ? (
                        <Check className="w-3 h-3 text-emerald-600" />
                      ) : (
                        <Copy className="w-3 h-3" />
                      )}
                      <span>{copiedId === item.id ? 'Tersalin' : 'Salin'}</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
