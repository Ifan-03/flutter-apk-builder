import React, { useState, useEffect } from 'react';
import {
  X,
  QrCode,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  Clock,
  Smartphone,
  Wallet,
  Building2,
  Copy,
  Check,
  RefreshCw,
  Zap
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPaymentSuccess: () => void;
  featureName?: string;
  price?: string;
}

type PaymentMethodType = 'qris' | 'gopay' | 'shopeepay' | 'bca_va';

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  onPaymentSuccess,
  featureName = 'Akses Fitur Premium PDF Ekstraktor',
  price = 'Rp 49.000',
}) => {
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethodType>('qris');
  const [paymentStep, setPaymentStep] = useState<'select' | 'waiting' | 'success'>('select');
  const [countdown, setCountdown] = useState(900); // 15 mins
  const [copied, setCopied] = useState(false);
  const [isSimulating, setIsSimulating] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setPaymentStep('select');
      setCountdown(900);
      setIsSimulating(false);
    }
  }, [isOpen]);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (paymentStep === 'waiting' && countdown > 0) {
      timer = setInterval(() => setCountdown((c) => c - 1), 1000);
    }
    return () => clearInterval(timer);
  }, [paymentStep, countdown]);

  if (!isOpen) return null;

  const formatCountdown = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleCopyVa = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleConfirmPay = () => {
    setPaymentStep('waiting');
  };

  const handleSimulateWebhookSuccess = () => {
    setIsSimulating(true);
    setTimeout(() => {
      setIsSimulating(false);
      setPaymentStep('success');
      try {
        confetti({
          particleCount: 60,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch {}
      setTimeout(() => {
        onPaymentSuccess();
        onClose();
      }, 1800);
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        id="premium-payment-modal"
        className="bg-white rounded-2xl border border-slate-200 max-w-lg w-full overflow-hidden flex flex-col shadow-2xl animate-in zoom-in-95 duration-150"
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center shadow-xs">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Upgrade ke Premium</h3>
              <p className="text-[11px] text-slate-500">Checkout aman & aktivasi otomatis seketika</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {paymentStep === 'select' && (
            <>
              {/* Plan Card */}
              <div className="p-4 rounded-xl bg-gradient-to-br from-amber-50 to-amber-100/50 border border-amber-200 flex items-center justify-between">
                <div>
                  <span className="text-[10.5px] font-bold uppercase tracking-wider text-amber-700 bg-amber-200/60 px-2 py-0.5 rounded">
                    Paket Premium Bulanan
                  </span>
                  <h4 className="text-sm font-bold text-slate-900 mt-1">{featureName}</h4>
                  <p className="text-xs text-slate-600">Akses tanpa batas + Ekspor Excel + Auto ML</p>
                </div>
                <div className="text-right">
                  <div className="text-xl font-extrabold text-amber-900">{price}</div>
                  <div className="text-[10px] text-slate-500">/ 30 Hari Aktif</div>
                </div>
              </div>

              {/* Payment Methods */}
              <div>
                <label className="text-xs font-bold text-slate-800 block mb-2">
                  Pilih Metode Pembayaran:
                </label>
                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() => setSelectedMethod('qris')}
                    className={`p-3 rounded-xl border text-left flex items-center gap-3 transition-all cursor-pointer ${
                      selectedMethod === 'qris'
                        ? 'border-indigo-600 bg-indigo-50/50 shadow-2xs'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0">
                      <QrCode className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-800">QRIS Instant</div>
                      <div className="text-[10px] text-slate-500">GoPay, OVO, Dana, BCA</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedMethod('gopay')}
                    className={`p-3 rounded-xl border text-left flex items-center gap-3 transition-all cursor-pointer ${
                      selectedMethod === 'gopay'
                        ? 'border-emerald-600 bg-emerald-50/50 shadow-2xs'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                      <Smartphone className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-800">GoPay Wallet</div>
                      <div className="text-[10px] text-slate-500">Direct App Deeplink</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedMethod('shopeepay')}
                    className={`p-3 rounded-xl border text-left flex items-center gap-3 transition-all cursor-pointer ${
                      selectedMethod === 'shopeepay'
                        ? 'border-orange-600 bg-orange-50/50 shadow-2xs'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="w-8 h-8 rounded-lg bg-orange-100 text-orange-700 flex items-center justify-center shrink-0">
                      <Wallet className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-800">ShopeePay</div>
                      <div className="text-[10px] text-slate-500">Cashback & SPayLater</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedMethod('bca_va')}
                    className={`p-3 rounded-xl border text-left flex items-center gap-3 transition-all cursor-pointer ${
                      selectedMethod === 'bca_va'
                        ? 'border-blue-600 bg-blue-50/50 shadow-2xs'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center shrink-0">
                      <Building2 className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-800">Virtual Account</div>
                      <div className="text-[10px] text-slate-500">BCA, Mandiri, BRI</div>
                    </div>
                  </button>
                </div>
              </div>

              {/* Guarantees */}
              <div className="flex items-center gap-2 text-[11px] text-slate-500 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Enkripsi 256-bit & verifikasi webhook instan tanpa perlu konfirmasi manual admin.</span>
              </div>
            </>
          )}

          {paymentStep === 'waiting' && (
            <div className="space-y-4 text-center">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold">
                <Clock className="w-3.5 h-3.5" />
                <span>Batas Waktu Bayar: {formatCountdown(countdown)}</span>
              </div>

              {selectedMethod === 'qris' ? (
                <div className="flex flex-col items-center justify-center space-y-3">
                  <div className="p-3 bg-white border-2 border-slate-800 rounded-2xl shadow-md inline-block">
                    {/* Simulated QR Code SVG */}
                    <div className="w-44 h-44 bg-slate-900 rounded-lg p-2 flex flex-col items-center justify-center text-white relative">
                      <div className="absolute inset-2 bg-white rounded flex items-center justify-center">
                        <div className="grid grid-cols-6 gap-1 p-2">
                          {Array.from({ length: 36 }).map((_, i) => (
                            <div
                              key={i}
                              className={`w-4 h-4 rounded-xs ${
                                (i % 2 === 0 || i % 5 === 0) ? 'bg-slate-900' : 'bg-slate-200'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                      <div className="absolute z-10 bg-indigo-600 text-white px-2 py-0.5 rounded text-[9px] font-bold tracking-wider">
                        QRIS RESMI
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-slate-600 max-w-xs">
                    Buka aplikasi <strong>GoPay, BCA Mobile, OVO, Dana</strong> atau perbankan Anda dan scan kode QR di atas.
                  </p>
                </div>
              ) : selectedMethod === 'bca_va' ? (
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-left">
                  <div className="text-xs text-slate-500">Nomor Virtual Account BCA:</div>
                  <div className="flex items-center justify-between bg-white p-3 rounded-lg border border-slate-300">
                    <span className="font-mono text-base font-bold text-slate-900">8801 2948 1029 4819</span>
                    <button
                      type="button"
                      onClick={() => handleCopyVa('8801294810294819')}
                      className="px-2.5 py-1 text-xs font-semibold bg-indigo-50 text-indigo-700 rounded-md hover:bg-indigo-100 flex items-center gap-1 cursor-pointer"
                    >
                      {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copied ? 'Tersalin' : 'Salin'}</span>
                    </button>
                  </div>
                  <div className="text-[11px] text-slate-500">Total Tagihan: <strong>{price}</strong></div>
                </div>
              ) : (
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                  <div className="text-xs text-slate-700">
                    Mengarahkan ke aplikasi <strong>{selectedMethod === 'gopay' ? 'GoPay' : 'ShopeePay'}</strong>...
                  </div>
                  <div className="text-xs font-bold text-slate-900">Total: {price}</div>
                </div>
              )}

              {/* Simulation Helper Box */}
              <div className="p-3 bg-amber-50/80 border border-amber-200 rounded-xl text-left space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900">
                  <Zap className="w-3.5 h-3.5 text-amber-600" />
                  <span>Sandbox Testing Webhook:</span>
                </div>
                <p className="text-[11px] text-amber-800">
                  Klik tombol simulasi di bawah untuk menguji respon webhook otomatis yang seketika meng-upgrade user menjadi Premium:
                </p>
                <button
                  type="button"
                  onClick={handleSimulateWebhookSuccess}
                  disabled={isSimulating}
                  className="w-full py-2 px-3 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  {isSimulating ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Memproses Notifikasi Webhook Gateway...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Simulasi Pembayaran Berhasil (Trigger Webhook)</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {paymentStep === 'success' && (
            <div className="py-8 text-center space-y-3">
              <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-2xl mx-auto flex items-center justify-center shadow-inner animate-bounce">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h4 className="text-lg font-bold text-slate-900">Pembayaran Dikonfirmasi!</h4>
              <p className="text-xs text-slate-600 max-w-xs mx-auto">
                Status akun Anda telah otomatis diperbarui ke <strong>Premium</strong>. Semua fitur terkunci kini dapat digunakan.
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        {paymentStep === 'select' && (
          <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-200 transition-colors cursor-pointer"
            >
              Batal
            </button>
            <button
              type="button"
              onClick={handleConfirmPay}
              className="px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 shadow-xs hover:shadow-sm transition-all flex items-center gap-2 cursor-pointer"
            >
              <span>Lanjut Bayar ({price})</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
