import React, { useState, useMemo } from 'react';
import { 
  X, 
  FileSpreadsheet, 
  FileText, 
  Copy, 
  Check, 
  Download, 
  Users, 
  Code,
  Settings2,
  ChevronDown,
  ChevronUp,
  Database,
  Globe,
  FileCode2,
  Table,
  Printer,
  Sparkles,
  QrCode,
  ExternalLink,
  MessageCircle,
  Share2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { ExtractedNumber } from '../types';
import { WhatsAppQrExporter } from './WhatsAppQrExporter';
import { exportBatchWaHtmlFile } from '../utils/waClickToChatExporter';
import { 
  exportToCsv, 
  exportToExcel, 
  exportToVcf, 
  exportToTxt,
  exportToMarkdown,
  exportToHtml,
  exportToSql,
  exportToXml,
  getCleanNumberList,
  generateCsvString,
  generateMarkdownString,
  generateSqlString,
  generateXmlString,
  CsvDelimiter,
  CsvEncoding,
  CsvNumberStyle
} from '../utils/exportUtils';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: ExtractedNumber[];
  selectedCount: number;
}

type ExportCategoryTab = 'spreadsheet' | 'documents' | 'database' | 'contacts' | 'qrcode';

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  items,
  selectedCount,
}) => {
  const [activeTab, setActiveTab] = useState<ExportCategoryTab>('spreadsheet');
  const [filename, setFilename] = useState('Ekstraksi_Nomor_PDF');
  
  // CSV Configuration Options
  const [csvDelimiterType, setCsvDelimiterType] = useState<';' | ',' | '\t' | '|' | 'custom'>(';');
  const [customDelimiter, setCustomDelimiter] = useState('^');
  const [csvEncoding, setCsvEncoding] = useState<CsvEncoding>('utf-8-bom');
  const [csvNumberStyle, setCsvNumberStyle] = useState<CsvNumberStyle>('excel_formula');
  const [csvIncludeHeaders, setCsvIncludeHeaders] = useState<boolean>(true);
  const [showAdvancedCsv, setShowAdvancedCsv] = useState<boolean>(false);

  // TXT Configuration Options
  const [txtStyle, setTxtStyle] = useState<'detailed' | 'numbers_only' | 'comma_inline'>('detailed');

  // SQL Configuration Options
  const [sqlDialect, setSqlDialect] = useState<'postgres' | 'mysql' | 'sqlite'>('postgres');
  const [sqlTableName, setSqlTableName] = useState('pdf_extracted_numbers');

  const [isExporting, setIsExporting] = useState(false);
  const [copiedFormat, setCopiedFormat] = useState<string | null>(null);

  const effectiveDelimiter: CsvDelimiter = 
    csvDelimiterType === 'custom' ? (customDelimiter || ';') : csvDelimiterType;

  // Generate live CSV sample preview
  const csvPreviewSnippet = useMemo(() => {
    const sampleItems = items.slice(0, 3);
    if (sampleItems.length === 0) return '';
    return generateCsvString(sampleItems, {
      delimiter: effectiveDelimiter,
      encoding: csvEncoding,
      numberStyle: csvNumberStyle,
      includeHeaders: csvIncludeHeaders,
    });
  }, [items, effectiveDelimiter, csvEncoding, csvNumberStyle, csvIncludeHeaders]);

  // Generate live SQL sample preview
  const sqlPreviewSnippet = useMemo(() => {
    const sampleItems = items.slice(0, 2);
    return generateSqlString(sampleItems, sqlDialect, sqlTableName);
  }, [items, sqlDialect, sqlTableName]);

  // Generate live Markdown sample preview
  const mdPreviewSnippet = useMemo(() => {
    const sampleItems = items.slice(0, 3);
    return generateMarkdownString(sampleItems);
  }, [items]);

  if (!isOpen) return null;

  const launchConfetti = () => {
    confetti({
      particleCount: 70,
      spread: 60,
      origin: { y: 0.6 },
    });
  };

  const handleExportExcel = async () => {
    try {
      setIsExporting(true);
      await exportToExcel(items, `${filename}.xlsx`);
      launchConfetti();
      onClose();
    } catch (err: any) {
      alert('Gagal mengekspor ke Excel: ' + err.message);
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportCsv = () => {
    try {
      exportToCsv(items, `${filename}.csv`, {
        delimiter: effectiveDelimiter,
        encoding: csvEncoding,
        numberStyle: csvNumberStyle,
        includeHeaders: csvIncludeHeaders,
      });
      launchConfetti();
      onClose();
    } catch (err: any) {
      alert('Gagal mengekspor ke CSV: ' + err.message);
    }
  };

  const handleExportTxt = () => {
    try {
      exportToTxt(items, `${filename}.txt`, txtStyle);
      launchConfetti();
      onClose();
    } catch (err: any) {
      alert('Gagal mengekspor ke TXT: ' + err.message);
    }
  };

  const handleExportMarkdown = () => {
    try {
      exportToMarkdown(items, `${filename}.md`);
      launchConfetti();
      onClose();
    } catch (err: any) {
      alert('Gagal mengekspor ke Markdown: ' + err.message);
    }
  };

  const handleExportHtml = () => {
    try {
      exportToHtml(items, `${filename}.html`, filename);
      launchConfetti();
      onClose();
    } catch (err: any) {
      alert('Gagal mengekspor ke HTML: ' + err.message);
    }
  };

  const handleExportSql = () => {
    try {
      exportToSql(items, `${filename}.sql`, sqlDialect, sqlTableName);
      launchConfetti();
      onClose();
    } catch (err: any) {
      alert('Gagal mengekspor ke SQL: ' + err.message);
    }
  };

  const handleExportXml = () => {
    try {
      exportToXml(items, `${filename}.xml`);
      launchConfetti();
      onClose();
    } catch (err: any) {
      alert('Gagal mengekspor ke XML: ' + err.message);
    }
  };

  const handleExportJsonFile = () => {
    const jsonStr = JSON.stringify(items, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${filename}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    launchConfetti();
    onClose();
  };

  const handleExportVcf = () => {
    try {
      exportToVcf(items, `${filename}.vcf`);
      launchConfetti();
      onClose();
    } catch (err: any) {
      alert('Gagal mengekspor ke VCF: ' + err.message);
    }
  };

  const handleCopyWaList = () => {
    const list = getCleanNumberList(items.filter((i) => i.category === 'phone'));
    navigator.clipboard.writeText(list);
    setCopiedFormat('wa');
    setTimeout(() => setCopiedFormat(null), 2000);
  };

  const handleCopyJson = () => {
    navigator.clipboard.writeText(JSON.stringify(items, null, 2));
    setCopiedFormat('json');
    setTimeout(() => setCopiedFormat(null), 2000);
  };

  const handleCopyMarkdown = () => {
    navigator.clipboard.writeText(generateMarkdownString(items));
    setCopiedFormat('md');
    setTimeout(() => setCopiedFormat(null), 2000);
  };

  const handleCopySql = () => {
    navigator.clipboard.writeText(generateSqlString(items, sqlDialect, sqlTableName));
    setCopiedFormat('sql');
    setTimeout(() => setCopiedFormat(null), 2000);
  };

  const applyPreset = (preset: 'id_excel' | 'us_excel' | 'google_sheets' | 'tsv') => {
    if (preset === 'id_excel') {
      setCsvDelimiterType(';');
      setCsvEncoding('utf-8-bom');
      setCsvNumberStyle('excel_formula');
      setCsvIncludeHeaders(true);
    } else if (preset === 'us_excel') {
      setCsvDelimiterType(',');
      setCsvEncoding('utf-8-bom');
      setCsvNumberStyle('excel_formula');
      setCsvIncludeHeaders(true);
    } else if (preset === 'google_sheets') {
      setCsvDelimiterType(',');
      setCsvEncoding('utf-8');
      setCsvNumberStyle('quoted_text');
      setCsvIncludeHeaders(true);
    } else if (preset === 'tsv') {
      setCsvDelimiterType('\t');
      setCsvEncoding('utf-8-bom');
      setCsvNumberStyle('quoted_text');
      setCsvIncludeHeaders(true);
    }
  };

  const phoneCount = items.filter((i) => i.category === 'phone').length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        id="export-modal" 
        className="bg-white rounded-2xl border border-slate-200 max-w-3xl w-full overflow-hidden flex flex-col max-h-[92vh] shadow-xl"
      >
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-white">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
              <Download className="w-4 h-4" />
            </div>
            <div>
              <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                Export Manager
              </label>
              <h3 className="text-sm font-semibold text-slate-900">Ekspor Data & QR WhatsApp</h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Category Tabs */}
        <div className="px-6 pt-3 border-b border-slate-100 bg-slate-50/50">
          <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
            {[
              { id: 'spreadsheet', label: 'Excel & CSV', icon: FileSpreadsheet },
              { id: 'contacts', label: 'Kontak & WA', icon: Users },
              { id: 'qrcode', label: 'QR Code WA', icon: QrCode, badge: 'Direct' },
              { id: 'documents', label: 'Teks & Dokumen', icon: FileText },
              { id: 'database', label: 'Database & Dev', icon: Database },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as ExportCategoryTab)}
                  className={`flex items-center gap-1.5 px-3.5 py-2 rounded-t-lg text-xs font-medium border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                    isActive
                      ? 'border-indigo-600 text-indigo-600 bg-white font-semibold shadow-xs'
                      : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-100/60'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                  {tab.badge && (
                    <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded-full ${
                      isActive ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-200/70 text-slate-600'
                    }`}>
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-5">
          {/* Filename input */}
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5">
              Nama File Output
            </label>
            <input
              id="input-export-filename"
              type="text"
              value={filename}
              onChange={(e) => setFilename(e.target.value)}
              className="w-full px-3 py-2 text-xs md:text-sm bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-800 outline-hidden focus:border-indigo-600 focus:bg-white transition-colors"
              placeholder="Contoh: Ekstraksi_Nomor_PDF"
            />
          </div>

          {/* TAB 1: SPREADSHEET (EXCEL & CSV) */}
          {activeTab === 'spreadsheet' && (
            <div className="space-y-4">
              {/* Excel (.xlsx) Card */}
              <div className="border border-indigo-100 bg-indigo-50/20 hover:bg-indigo-50/40 rounded-xl p-4 transition-all flex flex-col justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg bg-indigo-600 text-white flex items-center justify-center shrink-0">
                    <FileSpreadsheet className="w-4 h-4" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h5 className="text-sm font-semibold text-slate-900">Microsoft Excel (.xlsx)</h5>
                      <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-indigo-50 text-indigo-700 border border-indigo-100">
                        Rekomendasi
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                      Format angka terlindungi (0 tidak hilang), tautan WhatsApp aktif, dan sheet ringkasan statistik otomatis.
                    </p>
                  </div>
                </div>

                <button
                  id="btn-download-excel"
                  onClick={handleExportExcel}
                  disabled={isExporting}
                  className="w-full py-2 px-4 rounded-lg text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Unduh File Excel (.xlsx)</span>
                </button>
              </div>

              {/* CSV (.csv) Card with Configurable Delimiters & Encoding */}
              <div className="border border-slate-200 hover:border-slate-300 bg-white rounded-xl p-4 transition-all flex flex-col justify-between gap-3.5">
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg bg-slate-900 text-white flex items-center justify-center shrink-0">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h5 className="text-sm font-semibold text-slate-900">File CSV Kustom (.csv)</h5>
                      <button
                        type="button"
                        onClick={() => setShowAdvancedCsv(!showAdvancedCsv)}
                        className="inline-flex items-center gap-1 text-[11px] font-medium text-indigo-600 hover:text-indigo-700 cursor-pointer"
                      >
                        <Settings2 className="w-3.5 h-3.5" />
                        <span>{showAdvancedCsv ? 'Tutup Pengaturan' : 'Konfigurasi CSV'}</span>
                        {showAdvancedCsv ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                      </button>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Dapat disesuaikan untuk Excel versi Indonesia/Eropa (titik koma), Excel Internasional (koma), atau TSV.
                    </p>
                  </div>
                </div>

                {/* Quick Delimiter Switcher */}
                <div className="space-y-2 pt-1 border-t border-slate-100">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] text-slate-500 font-medium">Karakter Pemisah (Delimiter):</span>
                    <span className="text-[11px] text-slate-400 font-mono">
                      {csvDelimiterType === ';' && 'Semicolon (Excel ID / EU)'}
                      {csvDelimiterType === ',' && 'Comma (Excel US / INT)'}
                      {csvDelimiterType === '\t' && 'Tab (TSV)'}
                      {csvDelimiterType === '|' && 'Pipe (|)'}
                      {csvDelimiterType === 'custom' && `Custom (${customDelimiter})`}
                    </span>
                  </div>

                  <div className="grid grid-cols-5 gap-1 p-1 bg-slate-100/70 rounded-lg text-xs">
                    <button
                      type="button"
                      onClick={() => setCsvDelimiterType(';')}
                      className={`py-1.5 px-2 rounded-md font-medium text-center transition-all cursor-pointer ${
                        csvDelimiterType === ';'
                          ? 'bg-white text-indigo-600 shadow-2xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      ; Titik Koma
                    </button>
                    <button
                      type="button"
                      onClick={() => setCsvDelimiterType(',')}
                      className={`py-1.5 px-2 rounded-md font-medium text-center transition-all cursor-pointer ${
                        csvDelimiterType === ','
                          ? 'bg-white text-indigo-600 shadow-2xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      , Koma
                    </button>
                    <button
                      type="button"
                      onClick={() => setCsvDelimiterType('\t')}
                      className={`py-1.5 px-2 rounded-md font-medium text-center transition-all cursor-pointer ${
                        csvDelimiterType === '\t'
                          ? 'bg-white text-indigo-600 shadow-2xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      \t Tab
                    </button>
                    <button
                      type="button"
                      onClick={() => setCsvDelimiterType('|')}
                      className={`py-1.5 px-2 rounded-md font-medium text-center transition-all cursor-pointer ${
                        csvDelimiterType === '|'
                          ? 'bg-white text-indigo-600 shadow-2xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      | Pipe
                    </button>
                    <button
                      type="button"
                      onClick={() => setCsvDelimiterType('custom')}
                      className={`py-1.5 px-2 rounded-md font-medium text-center transition-all cursor-pointer ${
                        csvDelimiterType === 'custom'
                          ? 'bg-white text-indigo-600 shadow-2xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Lainnya
                    </button>
                  </div>

                  {csvDelimiterType === 'custom' && (
                    <div className="flex items-center gap-2 pt-1">
                      <label className="text-[11px] text-slate-500 font-medium">Karakter Pemisah Kustom:</label>
                      <input
                        type="text"
                        maxLength={3}
                        value={customDelimiter}
                        onChange={(e) => setCustomDelimiter(e.target.value)}
                        placeholder="^"
                        className="w-16 px-2 py-1 text-xs text-center font-mono bg-slate-50 border border-slate-200 rounded-lg outline-hidden focus:border-indigo-600 focus:bg-white"
                      />
                    </div>
                  )}
                </div>

                {/* Advanced CSV Settings Collapse */}
                {showAdvancedCsv && (
                  <div className="bg-slate-50/70 border border-slate-200 rounded-xl p-3.5 space-y-3 text-xs animate-in fade-in duration-150">
                    <div>
                      <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider block mb-1.5">
                        Preset Kompatibilitas Cepat
                      </span>
                      <div className="flex flex-wrap items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => applyPreset('id_excel')}
                          className="px-2 py-1 rounded bg-white hover:bg-indigo-50 hover:text-indigo-700 text-slate-700 border border-slate-200 font-medium text-[11px] transition-colors cursor-pointer"
                        >
                          Excel Indonesia / Eropa
                        </button>
                        <button
                          type="button"
                          onClick={() => applyPreset('us_excel')}
                          className="px-2 py-1 rounded bg-white hover:bg-indigo-50 hover:text-indigo-700 text-slate-700 border border-slate-200 font-medium text-[11px] transition-colors cursor-pointer"
                        >
                          Excel US / Global
                        </button>
                        <button
                          type="button"
                          onClick={() => applyPreset('google_sheets')}
                          className="px-2 py-1 rounded bg-white hover:bg-indigo-50 hover:text-indigo-700 text-slate-700 border border-slate-200 font-medium text-[11px] transition-colors cursor-pointer"
                        >
                          Google Sheets / DB
                        </button>
                        <button
                          type="button"
                          onClick={() => applyPreset('tsv')}
                          className="px-2 py-1 rounded bg-white hover:bg-indigo-50 hover:text-indigo-700 text-slate-700 border border-slate-200 font-medium text-[11px] transition-colors cursor-pointer"
                        >
                          TSV Tab Format
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="text-[11px] font-medium text-slate-600 block mb-1">
                        Encoding Karakter (Character Encoding)
                      </label>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                        {[
                          { id: 'utf-8-bom', label: 'UTF-8 with BOM', desc: 'Sangat disarankan untuk Excel Windows & Mac' },
                          { id: 'utf-8', label: 'UTF-8 Standar (No BOM)', desc: 'Cocok untuk Python, Database & Linux' },
                          { id: 'windows-1252', label: 'Windows-1252 (ANSI / Latin-1)', desc: 'Excel versi lama / Legacy Windows' },
                          { id: 'ascii', label: 'ASCII (Plain Text)', desc: 'Hanya karakter standar (tanpa aksen)' },
                        ].map((enc) => (
                          <button
                            key={enc.id}
                            type="button"
                            onClick={() => setCsvEncoding(enc.id as CsvEncoding)}
                            className={`p-2 rounded-lg text-left border transition-all cursor-pointer ${
                              csvEncoding === enc.id
                                ? 'bg-indigo-50/80 border-indigo-200 text-indigo-900'
                                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                            }`}
                          >
                            <div className="font-semibold text-xs">{enc.label}</div>
                            <div className="text-[10px] text-slate-400 mt-0.5">{enc.desc}</div>
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="text-[11px] font-medium text-slate-600 block mb-1">
                        Format Penyimpanan Angka
                      </label>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                        <button
                          type="button"
                          onClick={() => setCsvNumberStyle('excel_formula')}
                          className={`p-2 rounded-lg text-left border transition-all cursor-pointer ${
                            csvNumberStyle === 'excel_formula'
                              ? 'bg-indigo-50/80 border-indigo-200 text-indigo-900'
                              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                          }`}
                        >
                          <div className="font-semibold text-xs">Formula Teks Excel (="0812...")</div>
                          <div className="text-[10px] text-slate-400 mt-0.5">
                            Menjamin angka 0 di depan & angka panjang tidak berubah menjadi notasi ilmiah.
                          </div>
                        </button>

                        <button
                          type="button"
                          onClick={() => setCsvNumberStyle('quoted_text')}
                          className={`p-2 rounded-lg text-left border transition-all cursor-pointer ${
                            csvNumberStyle === 'quoted_text'
                              ? 'bg-indigo-50/80 border-indigo-200 text-indigo-900'
                              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                          }`}
                        >
                          <div className="font-semibold text-xs">Teks Berkutip Standar ("0812...")</div>
                          <div className="text-[10px] text-slate-400 mt-0.5">
                            Standar RFC 4180 untuk database import atau Google Sheets.
                          </div>
                        </button>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pt-1">
                      <input
                        id="chk-csv-headers"
                        type="checkbox"
                        checked={csvIncludeHeaders}
                        onChange={(e) => setCsvIncludeHeaders(e.target.checked)}
                        className="w-3.5 h-3.5 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300 cursor-pointer"
                      />
                      <label htmlFor="chk-csv-headers" className="text-xs text-slate-600 cursor-pointer font-medium">
                        Sertakan Baris Judul Kolom (Header Row)
                      </label>
                    </div>

                    <div>
                      <label className="text-[11px] font-medium text-slate-400 uppercase tracking-wider block mb-1">
                        Pratinjau Format Output CSV:
                      </label>
                      <div className="p-2.5 bg-slate-900 text-slate-200 font-mono text-[11px] rounded-lg overflow-x-auto max-h-24 leading-relaxed whitespace-pre">
                        {csvPreviewSnippet}
                      </div>
                    </div>
                  </div>
                )}

                <button
                  id="btn-download-csv"
                  onClick={handleExportCsv}
                  className="w-full py-2 px-4 rounded-lg text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Unduh File CSV (.csv)</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: DOCUMENTS & TEXT (TXT, MARKDOWN, HTML) */}
          {activeTab === 'documents' && (
            <div className="space-y-4">
              {/* Plain Text (.txt) */}
              <div className="border border-slate-200 rounded-xl p-4 bg-white space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center">
                      <FileText className="w-4 h-4" />
                    </div>
                    <div>
                      <h5 className="text-sm font-semibold text-slate-900">Dokumen Teks Polos (.txt)</h5>
                      <p className="text-xs text-slate-500">File teks ringan untuk catatan, arsip, atau pesan broadcast.</p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-100/70 rounded-lg text-xs">
                  <button
                    type="button"
                    onClick={() => setTxtStyle('detailed')}
                    className={`py-1.5 px-2 rounded-md font-medium text-center transition-all cursor-pointer ${
                      txtStyle === 'detailed' ? 'bg-white text-indigo-600 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Format Rinci
                  </button>
                  <button
                    type="button"
                    onClick={() => setTxtStyle('numbers_only')}
                    className={`py-1.5 px-2 rounded-md font-medium text-center transition-all cursor-pointer ${
                      txtStyle === 'numbers_only' ? 'bg-white text-indigo-600 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Nomor Saja (Per Baris)
                  </button>
                  <button
                    type="button"
                    onClick={() => setTxtStyle('comma_inline')}
                    className={`py-1.5 px-2 rounded-md font-medium text-center transition-all cursor-pointer ${
                      txtStyle === 'comma_inline' ? 'bg-white text-indigo-600 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Inline (Pemisah Koma)
                  </button>
                </div>

                <button
                  onClick={handleExportTxt}
                  className="w-full py-2 px-4 rounded-lg text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Unduh File Teks (.txt)</span>
                </button>
              </div>

              {/* Markdown (.md) */}
              <div className="border border-slate-200 rounded-xl p-4 bg-white space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-sky-50 text-sky-600 flex items-center justify-center">
                      <FileCode2 className="w-4 h-4" />
                    </div>
                    <div>
                      <h5 className="text-sm font-semibold text-slate-900">Tabel Markdown (.md)</h5>
                      <p className="text-xs text-slate-500">Format tabel siap pakai untuk Notion, Obsidian, GitHub, atau README.</p>
                    </div>
                  </div>
                  <button
                    onClick={handleCopyMarkdown}
                    className="inline-flex items-center gap-1 text-xs text-indigo-600 hover:text-indigo-700 font-medium cursor-pointer"
                  >
                    {copiedFormat === 'md' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedFormat === 'md' ? 'Tersalin' : 'Salin MD'}</span>
                  </button>
                </div>

                <div className="p-2.5 bg-slate-900 text-slate-200 font-mono text-[10.5px] rounded-lg overflow-x-auto max-h-20 whitespace-pre">
                  {mdPreviewSnippet}
                </div>

                <button
                  onClick={handleExportMarkdown}
                  className="w-full py-2 px-4 rounded-lg text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Unduh File Markdown (.md)</span>
                </button>
              </div>

              {/* HTML Table Report (.html) */}
              <div className="border border-slate-200 rounded-xl p-4 bg-white space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
                      <Globe className="w-4 h-4" />
                    </div>
                    <div>
                      <h5 className="text-sm font-semibold text-slate-900">Laporan Tabel Web Mandiri (.html)</h5>
                      <p className="text-xs text-slate-500">Halaman web mandiri berdesain modern dengan tombol cetak/save PDF otomatis.</p>
                    </div>
                  </div>
                </div>

                <button
                  onClick={handleExportHtml}
                  className="w-full py-2 px-4 rounded-lg text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Unduh File Laporan Web (.html)</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: DATABASE & DEVELOPER (SQL, XML, JSON) */}
          {activeTab === 'database' && (
            <div className="space-y-4">
              {/* SQL Script (.sql) */}
              <div className="border border-slate-200 rounded-xl p-4 bg-white space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
                      <Database className="w-4 h-4" />
                    </div>
                    <div>
                      <h5 className="text-sm font-semibold text-slate-900">SQL Script Query (.sql)</h5>
                      <p className="text-xs text-slate-500">Skrip DDL (CREATE TABLE) dan DML (INSERT INTO) siap dieksekusi.</p>
                    </div>
                  </div>

                  <button
                    onClick={handleCopySql}
                    className="inline-flex items-center gap-1 text-xs text-indigo-600 hover:text-indigo-700 font-medium cursor-pointer"
                  >
                    {copiedFormat === 'sql' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedFormat === 'sql' ? 'Tersalin' : 'Salin SQL'}</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="block text-[11px] font-medium text-slate-500 mb-1">Dialek Database:</label>
                    <div className="grid grid-cols-3 gap-1 p-1 bg-slate-100/70 rounded-lg">
                      {(['postgres', 'mysql', 'sqlite'] as const).map((d) => (
                        <button
                          key={d}
                          type="button"
                          onClick={() => setSqlDialect(d)}
                          className={`py-1 text-center font-medium rounded capitalize cursor-pointer ${
                            sqlDialect === d ? 'bg-white text-indigo-600 shadow-2xs' : 'text-slate-600'
                          }`}
                        >
                          {d === 'postgres' ? 'Postgres' : d}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-medium text-slate-500 mb-1">Nama Tabel:</label>
                    <input
                      type="text"
                      value={sqlTableName}
                      onChange={(e) => setSqlTableName(e.target.value)}
                      className="w-full px-2.5 py-1.5 font-mono text-xs bg-slate-50 border border-slate-200 rounded-lg outline-hidden focus:border-indigo-600 focus:bg-white"
                    />
                  </div>
                </div>

                <div className="p-2.5 bg-slate-900 text-slate-200 font-mono text-[10.5px] rounded-lg overflow-x-auto max-h-20 whitespace-pre">
                  {sqlPreviewSnippet}
                </div>

                <button
                  onClick={handleExportSql}
                  className="w-full py-2 px-4 rounded-lg text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Unduh File SQL (.sql)</span>
                </button>
              </div>

              {/* XML Dataset (.xml) */}
              <div className="border border-slate-200 rounded-xl p-4 bg-white space-y-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center">
                    <Code className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="text-sm font-semibold text-slate-900">XML Dataset (.xml)</h5>
                    <p className="text-xs text-slate-500">Struktur XML hierarkis standar untuk integrasi ERP dan Web Service.</p>
                  </div>
                </div>

                <button
                  onClick={handleExportXml}
                  className="w-full py-2 px-4 rounded-lg text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Unduh File XML (.xml)</span>
                </button>
              </div>

              {/* JSON Data (.json) */}
              <div className="border border-slate-200 rounded-xl p-4 bg-white space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center">
                      <Code className="w-4 h-4" />
                    </div>
                    <div>
                      <h5 className="text-sm font-semibold text-slate-900">JSON Data (.json)</h5>
                      <p className="text-xs text-slate-500">Format data JSON objek terstruktur untuk developer API.</p>
                    </div>
                  </div>

                  <button
                    onClick={handleCopyJson}
                    className="inline-flex items-center gap-1 text-xs text-indigo-600 hover:text-indigo-700 font-medium cursor-pointer"
                  >
                    {copiedFormat === 'json' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedFormat === 'json' ? 'Tersalin' : 'Salin JSON'}</span>
                  </button>
                </div>

                <button
                  onClick={handleExportJsonFile}
                  className="w-full py-2 px-4 rounded-lg text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Unduh File JSON (.json)</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 4: CONTACTS & WHATSAPP (VCF, WA COPY) */}
          {activeTab === 'contacts' && (
            <div className="space-y-4">
              {/* QR Code Feature Banner */}
              <div className="border border-emerald-200 bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-indigo-500/10 rounded-xl p-4 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold shrink-0">
                    <QrCode className="w-5 h-5" />
                  </div>
                  <div>
                    <h5 className="text-sm font-semibold text-slate-900">QR Code WhatsApp Web Instant</h5>
                    <p className="text-xs text-slate-500">Scan QR Code dengan kamera smartphone untuk langsung membuka chat WhatsApp tanpa simpan nomor.</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveTab('qrcode')}
                  className="px-3.5 py-1.5 rounded-lg text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 shadow-xs transition-colors shrink-0 cursor-pointer flex items-center gap-1.5"
                >
                  <span>Buka Generator QR</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* WhatsApp Broadcast list */}
              <div className="border border-emerald-100 bg-emerald-50/30 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold">
                      WA
                    </div>
                    <div>
                      <h5 className="text-sm font-semibold text-slate-900">Daftar Kontak WhatsApp</h5>
                      <p className="text-xs text-slate-500">Salin daftar nomor telepon bersih tanpa spasi/simbol untuk broadcast.</p>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[11px] font-mono font-semibold bg-emerald-100 text-emerald-800">
                    {phoneCount} Nomor HP
                  </span>
                </div>

                <div className="p-3 bg-white border border-emerald-200 rounded-lg text-xs text-slate-700 font-mono max-h-24 overflow-y-auto">
                  {getCleanNumberList(items.filter((i) => i.category === 'phone')) || '(Tidak ada nomor HP terdeteksi)'}
                </div>

                <button
                  onClick={handleCopyWaList}
                  disabled={phoneCount === 0}
                  className="w-full py-2 px-4 rounded-lg text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-700 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-40"
                >
                  {copiedFormat === 'wa' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedFormat === 'wa' ? 'Nomor Berhasil Disalin!' : 'Salin Semua Nomor WhatsApp'}</span>
                </button>
              </div>

              {/* Batch WhatsApp Click-to-Chat HTML & Shareable Link */}
              <div className="border border-emerald-200 bg-white rounded-xl p-4 space-y-3 shadow-2xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold">
                      <MessageCircle className="w-4 h-4" />
                    </div>
                    <div>
                      <h5 className="text-sm font-semibold text-slate-900">Batch WhatsApp Click-to-Chat (HTML & Link)</h5>
                      <p className="text-xs text-slate-500">Buat satu halaman web mandiri berisi daftar link Click-to-Chat seluruh nomor.</p>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[11px] font-mono font-semibold bg-emerald-100 text-emerald-800">
                    {phoneCount} Kontak
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      try {
                        const { download } = exportBatchWaHtmlFile(items, filename);
                        download();
                        launchConfetti();
                      } catch (err: any) {
                        alert('Gagal mengunduh file HTML: ' + err.message);
                      }
                    }}
                    disabled={phoneCount === 0}
                    className="w-full py-2 px-3 rounded-lg text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-40"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Unduh File HTML Batch</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      try {
                        const { shareUrl } = exportBatchWaHtmlFile(items, filename);
                        window.open(shareUrl, '_blank');
                      } catch (err: any) {
                        alert('Gagal membuka halaman: ' + err.message);
                      }
                    }}
                    disabled={phoneCount === 0}
                    className="w-full py-2 px-3 rounded-lg text-xs font-medium text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-40"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Buka / Share Halaman Web</span>
                  </button>
                </div>
              </div>

              {/* VCF Phonebook Contacts */}
              <div className="border border-slate-200 rounded-xl p-4 bg-white space-y-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
                    <Users className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="text-sm font-semibold text-slate-900">Buku Kontak Ponsel (.vcf / vCard)</h5>
                    <p className="text-xs text-slate-500">Import otomatis langsung ke kontak smartphone Android / iOS / Google Contacts.</p>
                  </div>
                </div>

                <button
                  onClick={handleExportVcf}
                  disabled={phoneCount === 0}
                  className="w-full py-2 px-4 rounded-lg text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-40"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Unduh File Kontak (.vcf)</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 5: QR CODE WHATSAPP GENERATOR */}
          {activeTab === 'qrcode' && (
            <WhatsAppQrExporter items={items} filename={filename} />
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-100 bg-slate-50 flex items-center justify-between text-xs text-slate-400">
          <span>{items.length} data terpilih untuk diekspor</span>
          <button
            onClick={onClose}
            className="px-3.5 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 rounded-lg transition-colors cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
