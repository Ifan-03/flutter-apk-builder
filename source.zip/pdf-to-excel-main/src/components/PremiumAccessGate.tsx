import React, { useState } from 'react';
import {
  Lock,
  Sparkles,
  CheckCircle2,
  ArrowRight,
  Star,
  Check,
  Eye,
  EyeOff,
  Zap,
  ShieldCheck
} from 'lucide-react';
import { PaymentModal } from './PaymentModal';

export interface UserStatusObject {
  id?: string;
  name?: string;
  email?: string;
  status: 'free' | 'premium' | string;
  subscription_status?: 'free' | 'premium' | string;
  subscription_expires_at?: string | null;
}

export interface PremiumAccessGateProps {
  /** Objek user yang memiliki properti status atau subscription_status */
  user?: UserStatusObject | null;
  /** Status langganan langsung ('free' | 'premium') */
  status?: 'free' | 'premium';
  /** Boolean penanda apakah user memiliki akses premium */
  isPremium?: boolean;
  /** Judul fitur yang diproteksi */
  featureTitle?: string;
  /** Deskripsi singkat mengenai nilai tambah membuka fitur */
  featureDescription?: string;
  /** Daftar fasilitas / perks unggulan */
  perks?: string[];
  /** Label badge di bagian atas */
  badgeText?: string;
  /** Harga paket yang ditampilkan */
  price?: string;
  /** Callback opsional jika tombol upgrade diklik */
  onUpgradeClick?: () => void;
  /** Callback saat pembayaran berhasil dan status user perlu di-upgrade */
  onPaymentSuccess?: () => void;
  /** Konten React yang ingin diproteksi */
  children: React.ReactNode;
  /** Apakah menampilkan switch pengujian Free vs Premium */
  showTestingToggle?: boolean;
  /** Callback ketika tombol pengujian Free/Premium ditekan */
  onToggleTestingTier?: (nextState: boolean) => void;
}

export const PremiumAccessGate: React.FC<PremiumAccessGateProps> = ({
  user,
  status,
  isPremium,
  featureTitle = 'Fitur Analisis Premium Eksklusif',
  featureDescription = 'Buka akses tanpa batas untuk ekspor data massal, klasifikasi Machine Learning pintar, integrasi WhatsApp, dan validasi data kesehatan dokumen.',
  perks = [
    'Ekspor Excel (.xlsx) & CSV Tanpa Batas',
    'Machine Learning NLP Auto-Categorizer',
    'Integrasi Generator WhatsApp Otomatis',
    'Prioritas Kecepatan Ekstraksi PDF'
  ],
  badgeText = 'Khusus Member Premium',
  price = 'Rp 49.000',
  onUpgradeClick,
  onPaymentSuccess,
  children,
  showTestingToggle = false,
  onToggleTestingTier,
}) => {
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);

  // Evaluasi status user: cek apakah user berstatus 'free'
  const userStatusValue = user?.status || user?.subscription_status || status;
  const isFreeUser = userStatusValue === 'free' || (isPremium !== undefined && !isPremium);
  const isPremiumUnlocked = !isFreeUser;

  const handleOpenPayment = () => {
    if (onUpgradeClick) {
      onUpgradeClick();
    } else {
      setIsPaymentModalOpen(true);
    }
  };

  const handleSuccess = () => {
    if (onPaymentSuccess) {
      onPaymentSuccess();
    }
  };

  return (
    <div id="premium-access-gate-container" className="relative w-full">
      {/* Testing Toggle Bar (Opsional untuk pengujian interaktif Free vs Premium) */}
      {showTestingToggle && (
        <div className="mb-3 flex items-center justify-between p-2.5 rounded-xl bg-slate-100/90 border border-slate-200 text-xs">
          <div className="flex items-center gap-2 text-slate-700">
            <span className="font-bold">Status Akun Pengguna:</span>
            <span
              className={`px-2.5 py-0.5 rounded-full font-bold text-[10.5px] uppercase tracking-wider ${
                isPremiumUnlocked
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                  : 'bg-amber-100 text-amber-800 border border-amber-300'
              }`}
            >
              {isPremiumUnlocked ? '★ Premium Member (Unlocked)' : 'Free Tier (Terkunci)'}
            </span>
          </div>

          {onToggleTestingTier && (
            <button
              type="button"
              id="btn-toggle-tier-test"
              onClick={() => onToggleTestingTier(!isPremiumUnlocked)}
              className="inline-flex items-center gap-1.5 px-3 py-1 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg text-slate-700 font-semibold shadow-2xs transition-all cursor-pointer text-[11px]"
              title="Klik untuk mensimulasikan tampilan user Free vs Premium"
            >
              {isPremiumUnlocked ? (
                <EyeOff className="w-3.5 h-3.5 text-amber-600" />
              ) : (
                <Eye className="w-3.5 h-3.5 text-emerald-600" />
              )}
              <span>Ubah ke mode {isPremiumUnlocked ? 'Free (Terkunci)' : 'Premium (Terbuka)'}</span>
            </button>
          )}
        </div>
      )}

      {/* 1. JIKA STATUS USER PREMIUM: Render Konten Secara Penuh */}
      {isPremiumUnlocked ? (
        <div className="relative animate-in fade-in duration-200">
          {children}
        </div>
      ) : (
        /* 2. JIKA STATUS USER FREE: Blur Konten & Tampilkan Banner Ajakan Upgrade ke Premium */
        <div 
          id="premium-locked-wrapper"
          className="relative overflow-hidden rounded-2xl border border-amber-200/90 bg-white p-2 sm:p-4 shadow-sm"
        >
          {/* Konten Asli (Di-blur, tidak dapat dipilih atau diklik) */}
          <div
            className="filter blur-md select-none pointer-events-none opacity-30 transition-all duration-300 transform scale-[0.99]"
            aria-hidden="true"
          >
            {children}
          </div>

          {/* Overlay Banner & Tombol Upgrade */}
          <div 
            id="premium-lock-overlay"
            className="absolute inset-0 z-20 flex flex-col items-center justify-center p-6 text-center bg-white/80 backdrop-blur-[2px]"
          >
            {/* Glowing Lock Badge */}
            <div className="relative mb-3">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-400 text-white flex items-center justify-center shadow-lg shadow-amber-500/25 ring-4 ring-amber-100 animate-pulse">
                <Lock className="w-7 h-7" />
              </div>
              <div className="absolute -top-1 -right-1 w-5 h-5 bg-indigo-600 text-white rounded-full flex items-center justify-center shadow-xs">
                <Sparkles className="w-3 h-3" />
              </div>
            </div>

            {/* Badge */}
            <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-[11px] font-bold uppercase tracking-wider mb-2">
              <Star className="w-3.5 h-3.5 text-amber-600 fill-amber-500" />
              <span>{badgeText}</span>
            </div>

            {/* Title & Description */}
            <h3 className="text-base sm:text-lg font-bold text-slate-900 max-w-md leading-snug">
              {featureTitle}
            </h3>
            <p className="text-xs text-slate-600 max-w-lg mt-1.5 mb-4 leading-relaxed">
              {featureDescription}
            </p>

            {/* Feature Perks Checklist */}
            {perks && perks.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-left text-xs text-slate-700 mb-5 max-w-md w-full bg-slate-50/95 p-3 rounded-xl border border-slate-200">
                {perks.map((perk, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </div>
                    <span className="text-[11.5px] font-medium text-slate-700 truncate">{perk}</span>
                  </div>
                ))}
              </div>
            )}

            {/* CTA Button Triggering Payment */}
            <div className="flex flex-col sm:flex-row items-center gap-3">
              <button
                type="button"
                id="btn-upgrade-premium-gate"
                onClick={handleOpenPayment}
                className="inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl font-bold text-xs text-white bg-gradient-to-r from-amber-500 via-amber-600 to-amber-700 hover:from-amber-600 hover:to-amber-800 shadow-md shadow-amber-500/25 hover:shadow-lg transition-all transform hover:-translate-y-0.5 cursor-pointer"
              >
                <Zap className="w-4 h-4 text-amber-200 fill-amber-200" />
                <span>Upgrade ke Premium ({price})</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center gap-1.5 text-[11px] text-slate-500 font-medium">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>QRIS, GoPay, ShopeePay & VA</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Built-in Interactive Payment Modal with QRIS / E-Wallet / Webhook simulation */}
      <PaymentModal
        isOpen={isPaymentModalOpen}
        onClose={() => setIsPaymentModalOpen(false)}
        onPaymentSuccess={handleSuccess}
        featureName={featureTitle}
        price={price}
      />
    </div>
  );
};
