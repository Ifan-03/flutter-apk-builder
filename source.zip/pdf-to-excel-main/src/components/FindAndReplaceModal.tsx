import React, { useState, useMemo } from 'react';
import {
  Search,
  Replace,
  X,
  Check,
  Sparkles,
  ArrowRight,
  Filter,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Layers,
  Settings2,
  Tag,
  FolderTree,
  Building,
  Hash
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { ExtractedNumber, NumberCategory } from '../types';

export type ReplaceTargetColumn = 'label' | 'category' | 'entityName' | 'rawNumber';
export type ReplaceMode = 'contains' | 'exact' | 'regex' | 'set_all';

interface FindAndReplaceModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: ExtractedNumber[];
  onApplyReplace: (updatedItems: ExtractedNumber[], updatedCount: number) => void;
}

const CATEGORY_OPTIONS: { value: NumberCategory; label: string }[] = [
  { value: 'phone', label: 'Nomor Telepon / WhatsApp' },
  { value: 'invoice', label: 'Invoice / Faktur Pajak' },
  { value: 'id_card', label: 'NIK / Identitas (KTP)' },
  { value: 'bank_account', label: 'Rekening Bank / VA' },
  { value: 'currency', label: 'Nominal Uang / Rupiah' },
  { value: 'serial_sku', label: 'Nomor Seri / SKU' },
  { value: 'date_time', label: 'Tanggal / Waktu' },
  { value: 'custom', label: 'Kustom' },
  { value: 'other', label: 'Lainnya (Other)' },
];

export const FindAndReplaceModal: React.FC<FindAndReplaceModalProps> = ({
  isOpen,
  onClose,
  items,
  onApplyReplace,
}) => {
  const [targetColumn, setTargetColumn] = useState<ReplaceTargetColumn>('label');
  const [findText, setFindText] = useState('');
  const [replaceText, setReplaceText] = useState('');
  const [targetCategoryValue, setTargetCategoryValue] = useState<NumberCategory>('invoice');
  const [replaceMode, setReplaceMode] = useState<ReplaceMode>('contains');
  const [matchCase, setMatchCase] = useState(false);
  const [applyToSelectedOnly, setApplyToSelectedOnly] = useState(false);

  const selectedRowsCount = useMemo(() => items.filter((i) => i.selected).length, [items]);

  // Set default scope to selected only if user had selected rows when opening
  React.useEffect(() => {
    if (isOpen) {
      if (selectedRowsCount > 0) {
        setApplyToSelectedOnly(true);
      } else {
        setApplyToSelectedOnly(false);
      }
    }
  }, [isOpen, selectedRowsCount]);

  // Eligible pool of items based on scope
  const targetPool = useMemo(() => {
    if (applyToSelectedOnly && selectedRowsCount > 0) {
      return items.filter((i) => i.selected);
    }
    return items;
  }, [items, applyToSelectedOnly, selectedRowsCount]);

  // Calculate replacements and preview
  const previewResults = useMemo(() => {
    if (targetColumn === 'category') {
      if (replaceMode === 'set_all') {
        const matches = targetPool.filter((item) => item.category !== targetCategoryValue);
        return {
          matchedCount: matches.length,
          previewItems: matches.slice(0, 10).map((item) => ({
            id: item.id,
            rawNumber: item.rawNumber,
            before: item.category,
            after: targetCategoryValue,
            context: item.context,
          })),
          allReplacementsMap: new Map(matches.map((item) => [item.id, { ...item, category: targetCategoryValue }])),
          error: null,
        };
      } else {
        const query = findText.trim().toLowerCase();
        if (!query) {
          return { matchedCount: 0, previewItems: [], allReplacementsMap: new Map(), error: null };
        }
        const matches = targetPool.filter((item) => {
          const catStr = item.category.toLowerCase();
          return catStr.includes(query) && item.category !== targetCategoryValue;
        });
        return {
          matchedCount: matches.length,
          previewItems: matches.slice(0, 10).map((item) => ({
            id: item.id,
            rawNumber: item.rawNumber,
            before: item.category,
            after: targetCategoryValue,
            context: item.context,
          })),
          allReplacementsMap: new Map(matches.map((item) => [item.id, { ...item, category: targetCategoryValue }])),
          error: null,
        };
      }
    }

    // Text replacement for label, entityName, rawNumber
    if (replaceMode === 'set_all') {
      if (!replaceText.trim() && targetColumn !== 'entityName') {
        return { matchedCount: 0, previewItems: [], allReplacementsMap: new Map(), error: null };
      }
      const matches = targetPool.filter((item) => {
        const currentVal = item[targetColumn] || '';
        return currentVal !== replaceText;
      });
      return {
        matchedCount: matches.length,
        previewItems: matches.slice(0, 10).map((item) => ({
          id: item.id,
          rawNumber: item.rawNumber,
          before: item[targetColumn] || '(Kosong)',
          after: replaceText || '(Dikosongkan)',
          context: item.context,
        })),
        allReplacementsMap: new Map(
          matches.map((item) => [
            item.id,
            {
              ...item,
              [targetColumn]: replaceText,
              // If replacing rawNumber, also update normalized number if appropriate
              ...(targetColumn === 'rawNumber' ? { normalizedNumber: replaceText } : {}),
            },
          ])
        ),
        error: null,
      };
    }

    if (!findText) {
      return { matchedCount: 0, previewItems: [], allReplacementsMap: new Map(), error: null };
    }

    let regex: RegExp | null = null;
    try {
      if (replaceMode === 'regex') {
        regex = new RegExp(findText, matchCase ? 'g' : 'gi');
      }
    } catch (e: any) {
      return {
        matchedCount: 0,
        previewItems: [],
        allReplacementsMap: new Map(),
        error: `Regex tidak valid: ${e.message || 'Syntax Error'}`,
      };
    }

    const matches: Array<{ item: ExtractedNumber; newVal: string; oldVal: string }> = [];

    targetPool.forEach((item) => {
      const originalVal = item[targetColumn] || '';
      let newVal = originalVal;

      if (replaceMode === 'exact') {
        const isMatch = matchCase
          ? originalVal === findText
          : originalVal.toLowerCase() === findText.toLowerCase();
        if (isMatch) {
          newVal = replaceText;
        }
      } else if (replaceMode === 'regex' && regex) {
        if (regex.test(originalVal)) {
          newVal = originalVal.replace(regex, replaceText);
        }
      } else {
        // Contains (substring)
        if (matchCase) {
          if (originalVal.includes(findText)) {
            newVal = originalVal.replaceAll(findText, replaceText);
          }
        } else {
          const lowerVal = originalVal.toLowerCase();
          const lowerFind = findText.toLowerCase();
          if (lowerVal.includes(lowerFind)) {
            // Case-insensitive replace all preserving rest
            const escaped = findText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            newVal = originalVal.replace(new RegExp(escaped, 'gi'), replaceText);
          }
        }
      }

      if (newVal !== originalVal) {
        matches.push({ item, newVal, oldVal: originalVal });
      }
    });

    return {
      matchedCount: matches.length,
      previewItems: matches.slice(0, 10).map((m) => ({
        id: m.item.id,
        rawNumber: m.item.rawNumber,
        before: m.oldVal || '(Kosong)',
        after: m.newVal || '(Dikosongkan)',
        context: m.item.context,
      })),
      allReplacementsMap: new Map(
        matches.map((m) => [
          m.item.id,
          {
            ...m.item,
            [targetColumn]: m.newVal,
            ...(targetColumn === 'rawNumber' ? { normalizedNumber: m.newVal } : {}),
          },
        ])
      ),
      error: null,
    };
  }, [
    items,
    targetPool,
    targetColumn,
    findText,
    replaceText,
    targetCategoryValue,
    replaceMode,
    matchCase,
  ]);

  if (!isOpen) return null;

  const handleApply = () => {
    if (previewResults.matchedCount === 0) return;

    const replacementMap = previewResults.allReplacementsMap;
    const updated = items.map((item) => {
      if (replacementMap.has(item.id)) {
        return replacementMap.get(item.id)!;
      }
      return item;
    });

    try {
      confetti({
        particleCount: 40,
        spread: 50,
        origin: { y: 0.7 },
      });
    } catch {}

    onApplyReplace(updated, previewResults.matchedCount);
    onClose();
  };

  const getTargetIcon = () => {
    switch (targetColumn) {
      case 'label':
        return <Tag className="w-4 h-4 text-indigo-600" />;
      case 'category':
        return <FolderTree className="w-4 h-4 text-indigo-600" />;
      case 'entityName':
        return <Building className="w-4 h-4 text-indigo-600" />;
      case 'rawNumber':
        return <Hash className="w-4 h-4 text-indigo-600" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        id="bulk-find-replace-modal"
        className="bg-white rounded-2xl border border-slate-200 max-w-2xl w-full overflow-hidden flex flex-col max-h-[92vh] shadow-2xl"
      >
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
              <Replace className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900">Bulk Find and Replace</h3>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
                  Operasi Massal
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Cari dan ganti teks atau ubah kategori secara massal pada baris terpilih atau seluruh tabel.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {/* 1. Target Column & Scope */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold text-slate-800 block mb-1.5 flex items-center gap-1.5">
                {getTargetIcon()}
                <span>Target Kolom:</span>
              </label>
              <select
                id="select-target-column"
                value={targetColumn}
                onChange={(e) => {
                  setTargetColumn(e.target.value as ReplaceTargetColumn);
                  if (e.target.value === 'category') {
                    setReplaceMode('set_all');
                  } else if (replaceMode === 'set_all') {
                    setReplaceMode('contains');
                  }
                }}
                className="w-full px-3 py-2 text-xs font-semibold bg-slate-50 border border-slate-200 rounded-lg outline-hidden focus:border-indigo-600 focus:bg-white cursor-pointer"
              >
                <option value="label">Label / Deskripsi Nomor</option>
                <option value="category">Kategori Dokumen</option>
                <option value="entityName">Nama Entitas / Bank / Lembaga</option>
                <option value="rawNumber">Nilai Nomor (Raw Number)</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-800 block mb-1.5 flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-indigo-600" />
                <span>Cakupan Baris (Scope):</span>
              </label>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setApplyToSelectedOnly(false)}
                  className={`flex-1 py-2 px-2.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                    !applyToSelectedOnly
                      ? 'bg-indigo-50 text-indigo-700 border-indigo-300 shadow-2xs'
                      : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  Semua Baris ({items.length})
                </button>
                <button
                  type="button"
                  onClick={() => setApplyToSelectedOnly(true)}
                  disabled={selectedRowsCount === 0}
                  className={`flex-1 py-2 px-2.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${
                    applyToSelectedOnly
                      ? 'bg-indigo-50 text-indigo-700 border-indigo-300 shadow-2xs'
                      : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  Baris Terpilih ({selectedRowsCount})
                </button>
              </div>
            </div>
          </div>

          {/* 2. Replacement Configuration Form */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Settings2 className="w-3.5 h-3.5 text-indigo-600" />
                <span>Mode Penggantian:</span>
              </span>

              {targetColumn !== 'category' && (
                <div className="flex items-center gap-1 bg-white p-0.5 rounded-lg border border-slate-200">
                  <button
                    type="button"
                    onClick={() => setReplaceMode('contains')}
                    className={`px-2 py-1 rounded text-[11px] font-semibold transition-all cursor-pointer ${
                      replaceMode === 'contains'
                        ? 'bg-indigo-600 text-white'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Teks Sebagian
                  </button>
                  <button
                    type="button"
                    onClick={() => setReplaceMode('exact')}
                    className={`px-2 py-1 rounded text-[11px] font-semibold transition-all cursor-pointer ${
                      replaceMode === 'exact'
                        ? 'bg-indigo-600 text-white'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Teks Tepat (Exact)
                  </button>
                  <button
                    type="button"
                    onClick={() => setReplaceMode('regex')}
                    className={`px-2 py-1 rounded text-[11px] font-semibold transition-all cursor-pointer ${
                      replaceMode === 'regex'
                        ? 'bg-indigo-600 text-white'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Regex
                  </button>
                  <button
                    type="button"
                    onClick={() => setReplaceMode('set_all')}
                    className={`px-2 py-1 rounded text-[11px] font-semibold transition-all cursor-pointer ${
                      replaceMode === 'set_all'
                        ? 'bg-indigo-600 text-white'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Setel Ulang Semua
                  </button>
                </div>
              )}
            </div>

            {/* Inputs based on Column Type */}
            {targetColumn === 'category' ? (
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                      Kategori Baru yang Diterapkan:
                    </label>
                    <select
                      id="select-new-category"
                      value={targetCategoryValue}
                      onChange={(e) => setTargetCategoryValue(e.target.value as NumberCategory)}
                      className="w-full px-3 py-2 text-xs font-semibold bg-white border border-slate-200 rounded-lg outline-hidden focus:border-indigo-600 cursor-pointer"
                    >
                      {CATEGORY_OPTIONS.map((cat) => (
                        <option key={cat.value} value={cat.value}>
                          {cat.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                      Filter Kategori Asal (Opsional):
                    </label>
                    <input
                      type="text"
                      value={findText}
                      onChange={(e) => {
                        setFindText(e.target.value);
                        setReplaceMode(e.target.value.trim() ? 'contains' : 'set_all');
                      }}
                      placeholder="Semua (atau ketik 'other', 'custom')..."
                      className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg outline-hidden focus:border-indigo-600"
                    />
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                {replaceMode !== 'set_all' && (
                  <div>
                    <label className="text-[11px] font-semibold text-slate-600 block mb-1 flex items-center justify-between">
                      <span className="flex items-center gap-1">
                        <Search className="w-3 h-3 text-slate-500" />
                        <span>Cari Teks / Pola {replaceMode === 'regex' ? 'Regex' : ''}:</span>
                      </span>
                      {replaceMode !== 'regex' && (
                        <label className="inline-flex items-center gap-1.5 text-[10.5px] text-slate-500 font-normal cursor-pointer">
                          <input
                            type="checkbox"
                            checked={matchCase}
                            onChange={(e) => setMatchCase(e.target.checked)}
                            className="w-3 h-3 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300 cursor-pointer"
                          />
                          <span>Cocokkan Huruf Besar/Kecil (Match Case)</span>
                        </label>
                      )}
                    </label>
                    <input
                      id="input-find-text"
                      type="text"
                      value={findText}
                      onChange={(e) => setFindText(e.target.value)}
                      placeholder={
                        replaceMode === 'regex'
                          ? 'Contoh: ^No\\.\\s*(\\d+) atau (INV-\\d+)'
                          : 'Ketik kata atau karakter yang ingin diganti...'
                      }
                      className="w-full px-3 py-2 text-xs font-mono bg-white border border-slate-200 rounded-lg outline-hidden focus:border-indigo-600"
                    />
                  </div>
                )}

                <div>
                  <label className="text-[11px] font-semibold text-slate-600 block mb-1 flex items-center gap-1">
                    <Replace className="w-3 h-3 text-slate-500" />
                    <span>Ganti Menjadi:</span>
                  </label>
                  <input
                    id="input-replace-text"
                    type="text"
                    value={replaceText}
                    onChange={(e) => setReplaceText(e.target.value)}
                    placeholder={
                      replaceMode === 'set_all'
                        ? 'Ketik nilai baru untuk semua baris...'
                        : 'Ketik teks pengganti (kosongkan untuk menghapus teks yang cocok)...'
                    }
                    className="w-full px-3 py-2 text-xs font-mono bg-white border border-slate-200 rounded-lg outline-hidden focus:border-indigo-600"
                  />
                </div>

                {/* Preset Suggestions */}
                {targetColumn === 'label' && (
                  <div className="flex flex-wrap items-center gap-1.5 pt-1 text-[10.5px]">
                    <span className="text-slate-400 font-medium">Preset Cepat:</span>
                    <button
                      type="button"
                      onClick={() => {
                        setReplaceMode('set_all');
                        setReplaceText('Kontak Pelanggan (WhatsApp)');
                      }}
                      className="px-2 py-0.5 rounded bg-white hover:bg-slate-100 text-slate-600 border border-slate-200 cursor-pointer"
                    >
                      "Kontak Pelanggan"
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setReplaceMode('contains');
                        setFindText('Nomor');
                        setReplaceText('No.');
                      }}
                      className="px-2 py-0.5 rounded bg-white hover:bg-slate-100 text-slate-600 border border-slate-200 cursor-pointer"
                    >
                      "Nomor" ➔ "No."
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setReplaceMode('set_all');
                        setReplaceText('Invoice / Tagihan Resmi');
                      }}
                      className="px-2 py-0.5 rounded bg-white hover:bg-slate-100 text-slate-600 border border-slate-200 cursor-pointer"
                    >
                      "Invoice Resmi"
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Regex Error Alert */}
            {previewResults.error && (
              <div className="p-2.5 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-700 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{previewResults.error}</span>
              </div>
            )}
          </div>

          {/* 3. Real-time Live Preview Table */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                <span>Pratinjau Hasil Perubahan (Live Preview):</span>
              </span>
              <span className="text-[11px] font-medium text-slate-500">
                <strong className="text-indigo-700 font-bold">{previewResults.matchedCount}</strong> baris akan diperbarui
              </span>
            </div>

            <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
              {previewResults.previewItems.length > 0 ? (
                <div className="max-h-52 overflow-y-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead className="sticky top-0 bg-slate-100 text-slate-600 text-[10.5px] font-bold uppercase tracking-wider border-b border-slate-200">
                      <tr>
                        <th className="p-2.5">Nomor Asli</th>
                        <th className="p-2.5">Nilai Sebelum (Before)</th>
                        <th className="p-2.5 w-6 text-center"></th>
                        <th className="p-2.5">Nilai Sesudah (After)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 bg-white">
                      {previewResults.previewItems.map((p) => (
                        <tr key={p.id} className="hover:bg-slate-50/80">
                          <td className="p-2.5 font-mono font-bold text-slate-800">
                            {p.rawNumber}
                          </td>
                          <td className="p-2.5 text-slate-500 font-mono line-through decoration-rose-400 max-w-[180px] truncate">
                            {p.before}
                          </td>
                          <td className="p-2.5 text-center text-slate-400">
                            <ArrowRight className="w-3.5 h-3.5 inline text-indigo-500" />
                          </td>
                          <td className="p-2.5 font-mono font-bold text-indigo-700 bg-indigo-50/40 max-w-[200px] truncate">
                            {p.after}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="p-6 text-center bg-slate-50 text-slate-400 text-xs">
                  {findText || replaceMode === 'set_all' ? (
                    <span>Tidak ada baris yang cocok dengan kriteria pencarian di atas.</span>
                  ) : (
                    <span>Ketik teks atau pilih nilai di atas untuk melihat pratinjau perubahan secara langsung.</span>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <div className="text-xs text-slate-500">
            Cakupan: <strong>{applyToSelectedOnly ? 'Baris Terpilih' : 'Seluruh Baris'}</strong>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-200 bg-slate-100 transition-colors cursor-pointer"
            >
              Batal
            </button>

            <button
              type="button"
              onClick={handleApply}
              disabled={previewResults.matchedCount === 0}
              className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 shadow-xs hover:shadow-sm transition-all flex items-center gap-2 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Terapkan Perubahan ({previewResults.matchedCount})</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
