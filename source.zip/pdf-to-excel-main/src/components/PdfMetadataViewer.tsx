import React, { useState } from 'react';
import {
  User,
  Calendar,
  Layers,
  Cpu,
  FileText,
  Tag,
  Clock,
  ShieldCheck,
  Copy,
  Check,
  Info,
  Hash,
  Sparkles,
  ChevronDown,
  ChevronUp,
  FileCode,
  HardDrive
} from 'lucide-react';
import { PdfDocumentMetadata, PdfFileInfo } from '../types';

export interface PdfMetadataViewerProps {
  /** The file info object containing metadata */
  file: PdfFileInfo;
  /** Optional class name */
  className?: string;
  /** Whether to show the raw properties inspector */
  showRawInspector?: boolean;
}

export const PdfMetadataViewer: React.FC<PdfMetadataViewerProps> = ({
  file,
  className = '',
  showRawInspector = true,
}) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [copiedAll, setCopiedAll] = useState(false);
  const [isRawExpanded, setIsRawExpanded] = useState(false);

  const meta: PdfDocumentMetadata = file.metadata || {
    title: undefined,
    author: undefined,
    creator: undefined,
    producer: undefined,
    creationDate: undefined,
    modificationDate: undefined,
    subject: undefined,
    keywords: undefined,
    pdfFormatVersion: undefined,
    pageCount: file.totalPages,
    fileSizeFormatted: undefined,
  };

  const handleCopyValue = (key: string, value: string) => {
    if (!value) return;
    navigator.clipboard.writeText(value);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 1800);
  };

  const handleCopyAll = () => {
    const summary = {
      fileName: file.name,
      fileSize: meta.fileSizeFormatted || `${(file.size / 1024).toFixed(1)} KB`,
      totalPages: file.totalPages,
      title: meta.title || 'N/A',
      author: meta.author || 'N/A',
      producer: meta.producer || 'N/A',
      creator: meta.creator || 'N/A',
      creationDate: meta.creationDate || 'N/A',
      modificationDate: meta.modificationDate || 'N/A',
      subject: meta.subject || 'N/A',
      keywords: meta.keywords || 'N/A',
      pdfFormatVersion: meta.pdfFormatVersion || 'N/A',
    };
    navigator.clipboard.writeText(JSON.stringify(summary, null, 2));
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 2000);
  };

  const hasAnyMetadata = Boolean(
    meta.author ||
      meta.producer ||
      meta.creator ||
      meta.creationDate ||
      meta.title ||
      meta.subject ||
      meta.keywords
  );

  const keywordsList = meta.keywords
    ? meta.keywords
        .split(/[,;]/)
        .map((k) => k.trim())
        .filter(Boolean)
    : [];

  return (
    <div
      id="pdf-metadata-viewer"
      className={`space-y-4 text-xs ${className}`}
    >
      {/* Header Info & Copy All Banner */}
      <div className="flex items-center justify-between p-3.5 bg-slate-50 border border-slate-200/80 rounded-xl">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0 shadow-2xs">
            <Info className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="text-xs font-bold text-slate-800">
                Metadata Dokumen PDF
              </h4>
              <span
                className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                  hasAnyMetadata
                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                    : 'bg-slate-100 text-slate-500 border border-slate-200'
                }`}
              >
                {hasAnyMetadata ? 'Metadata Terdeteksi' : 'Metadata Dasar'}
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Informasi pembuat, tanggal penerbitan, dan software penyusun dokumen
            </p>
          </div>
        </div>

        <button
          type="button"
          id="btn-copy-all-metadata"
          onClick={handleCopyAll}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-semibold shadow-2xs transition-all cursor-pointer text-xs shrink-0"
          title="Salin semua metadata ke clipboard dalam format JSON"
        >
          {copiedAll ? (
            <Check className="w-3.5 h-3.5 text-emerald-600" />
          ) : (
            <Copy className="w-3.5 h-3.5 text-slate-400" />
          )}
          <span>{copiedAll ? 'Tersalin' : 'Salin JSON'}</span>
        </button>
      </div>

      {/* Primary Metadata Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        
        {/* 1. Author (Penulis) */}
        <div className="p-3 bg-white border border-slate-200 rounded-xl flex flex-col justify-between hover:border-slate-300 transition-colors shadow-2xs">
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-2 text-slate-500 text-[11px] font-semibold">
              <User className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
              <span>Penulis / Author</span>
            </div>
            {meta.author && (
              <button
                type="button"
                onClick={() => handleCopyValue('author', meta.author!)}
                className="text-slate-400 hover:text-slate-700 p-0.5 rounded cursor-pointer"
                title="Salin Nama Penulis"
              >
                {copiedKey === 'author' ? (
                  <Check className="w-3 h-3 text-emerald-600" />
                ) : (
                  <Copy className="w-3 h-3" />
                )}
              </button>
            )}
          </div>
          <div className="mt-2 font-medium text-slate-900 break-words">
            {meta.author ? (
              <span className="font-semibold text-slate-900 bg-indigo-50/50 px-1.5 py-0.5 rounded text-xs border border-indigo-100/50">
                {meta.author}
              </span>
            ) : (
              <span className="text-slate-400 italic text-[11px]">
                Tidak dicantumkan dalam dokumen
              </span>
            )}
          </div>
        </div>

        {/* 2. Creation Date (Tanggal Dibuat) */}
        <div className="p-3 bg-white border border-slate-200 rounded-xl flex flex-col justify-between hover:border-slate-300 transition-colors shadow-2xs">
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-2 text-slate-500 text-[11px] font-semibold">
              <Calendar className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>Tanggal Dibuat / Creation Date</span>
            </div>
            {meta.creationDate && (
              <button
                type="button"
                onClick={() => handleCopyValue('creationDate', meta.creationDate!)}
                className="text-slate-400 hover:text-slate-700 p-0.5 rounded cursor-pointer"
                title="Salin Tanggal Dibuat"
              >
                {copiedKey === 'creationDate' ? (
                  <Check className="w-3 h-3 text-emerald-600" />
                ) : (
                  <Copy className="w-3 h-3" />
                )}
              </button>
            )}
          </div>
          <div className="mt-2 font-medium text-slate-900">
            {meta.creationDate ? (
              <span className="font-mono text-xs font-semibold text-emerald-800 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                {meta.creationDate}
              </span>
            ) : (
              <span className="text-slate-400 italic text-[11px]">
                Tidak ada stempel waktu pembuatan
              </span>
            )}
          </div>
        </div>

        {/* 3. Producer (Software Penghasil PDF) */}
        <div className="p-3 bg-white border border-slate-200 rounded-xl flex flex-col justify-between hover:border-slate-300 transition-colors shadow-2xs">
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-2 text-slate-500 text-[11px] font-semibold">
              <Cpu className="w-3.5 h-3.5 text-amber-600 shrink-0" />
              <span>Aplikasi Producer / Engine</span>
            </div>
            {meta.producer && (
              <button
                type="button"
                onClick={() => handleCopyValue('producer', meta.producer!)}
                className="text-slate-400 hover:text-slate-700 p-0.5 rounded cursor-pointer"
                title="Salin Producer"
              >
                {copiedKey === 'producer' ? (
                  <Check className="w-3 h-3 text-emerald-600" />
                ) : (
                  <Copy className="w-3 h-3" />
                )}
              </button>
            )}
          </div>
          <div className="mt-2 font-medium text-slate-900 break-words">
            {meta.producer ? (
              <span className="font-mono text-xs font-medium text-amber-900 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">
                {meta.producer}
              </span>
            ) : (
              <span className="text-slate-400 italic text-[11px]">
                Standar Generic PDF Generator
              </span>
            )}
          </div>
        </div>

        {/* 4. Creator (Aplikasi Sumber) */}
        <div className="p-3 bg-white border border-slate-200 rounded-xl flex flex-col justify-between hover:border-slate-300 transition-colors shadow-2xs">
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-2 text-slate-500 text-[11px] font-semibold">
              <Layers className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span>Software Pembuat / Creator</span>
            </div>
            {meta.creator && (
              <button
                type="button"
                onClick={() => handleCopyValue('creator', meta.creator!)}
                className="text-slate-400 hover:text-slate-700 p-0.5 rounded cursor-pointer"
                title="Salin Creator"
              >
                {copiedKey === 'creator' ? (
                  <Check className="w-3 h-3 text-emerald-600" />
                ) : (
                  <Copy className="w-3 h-3" />
                )}
              </button>
            )}
          </div>
          <div className="mt-2 font-medium text-slate-900 break-words">
            {meta.creator ? (
              <span className="font-medium text-xs text-blue-900 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200">
                {meta.creator}
              </span>
            ) : (
              <span className="text-slate-400 italic text-[11px]">
                Tidak dicantumkan
              </span>
            )}
          </div>
        </div>

        {/* 5. Title & Subject */}
        <div className="p-3 bg-white border border-slate-200 rounded-xl flex flex-col justify-between hover:border-slate-300 transition-colors shadow-2xs sm:col-span-2">
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-2 text-slate-500 text-[11px] font-semibold">
              <FileText className="w-3.5 h-3.5 text-slate-600 shrink-0" />
              <span>Judul & Subjek Dokumen</span>
            </div>
            {(meta.title || meta.subject) && (
              <button
                type="button"
                onClick={() => handleCopyValue('title', `${meta.title || ''} - ${meta.subject || ''}`)}
                className="text-slate-400 hover:text-slate-700 p-0.5 rounded cursor-pointer"
                title="Salin Judul"
              >
                {copiedKey === 'title' ? (
                  <Check className="w-3 h-3 text-emerald-600" />
                ) : (
                  <Copy className="w-3 h-3" />
                )}
              </button>
            )}
          </div>
          <div className="mt-2 space-y-1">
            <div className="font-semibold text-slate-900 text-xs">
              {meta.title || file.name}
            </div>
            {meta.subject && (
              <div className="text-[11px] text-slate-600 font-normal">
                {meta.subject}
              </div>
            )}
          </div>
        </div>

        {/* 6. Modification Date & Format Specs */}
        <div className="p-3 bg-slate-50/70 border border-slate-200 rounded-xl space-y-2 sm:col-span-2">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">
                Jumlah Halaman
              </span>
              <span className="font-mono font-bold text-slate-800">
                {file.totalPages} Halaman
              </span>
            </div>

            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">
                Ukuran File
              </span>
              <span className="font-mono font-bold text-slate-800">
                {meta.fileSizeFormatted || `${(file.size / 1024).toFixed(1)} KB`}
              </span>
            </div>

            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">
                Versi Format PDF
              </span>
              <span className="font-mono font-semibold text-slate-700">
                {meta.pdfFormatVersion ? `v${meta.pdfFormatVersion}` : 'PDF 1.4 - 1.7'}
              </span>
            </div>

            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">
                Tanggal Modifikasi
              </span>
              <span className="font-mono text-slate-700 truncate block">
                {meta.modificationDate || meta.creationDate || 'Sama dengan dibuat'}
              </span>
            </div>
          </div>

          {/* Keywords / Tags if present */}
          {keywordsList.length > 0 && (
            <div className="pt-2 border-t border-slate-200/70 flex items-center gap-1.5 flex-wrap">
              <span className="text-[10.5px] font-bold text-slate-500 flex items-center gap-1">
                <Tag className="w-3 h-3 text-indigo-500" /> Kata Kunci:
              </span>
              {keywordsList.map((tag, idx) => (
                <span
                  key={idx}
                  className="px-2 py-0.5 rounded-md bg-white border border-slate-200 text-slate-700 text-[10.5px] font-medium"
                >
                  #{tag}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Optional Raw Info Inspector */}
      {showRawInspector && meta.rawInfo && Object.keys(meta.rawInfo).length > 0 && (
        <div className="border border-slate-200 rounded-xl overflow-hidden bg-white">
          <button
            type="button"
            onClick={() => setIsRawExpanded(!isRawExpanded)}
            className="w-full px-4 py-2.5 bg-slate-50/80 hover:bg-slate-100/80 flex items-center justify-between text-xs font-semibold text-slate-700 transition-colors cursor-pointer"
          >
            <span className="flex items-center gap-2">
              <FileCode className="w-3.5 h-3.5 text-slate-500" />
              <span>Inspektur Kamus PDF Asli (Raw Dictionary Keys)</span>
            </span>
            {isRawExpanded ? (
              <ChevronUp className="w-4 h-4 text-slate-500" />
            ) : (
              <ChevronDown className="w-4 h-4 text-slate-500" />
            )}
          </button>

          {isRawExpanded && (
            <div className="p-3 bg-slate-900 text-slate-200 font-mono text-[11px] overflow-x-auto max-h-48">
              <pre className="whitespace-pre-wrap">
                {JSON.stringify(meta.rawInfo, null, 2)}
              </pre>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
