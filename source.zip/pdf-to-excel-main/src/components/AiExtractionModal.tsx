import React, { useState } from 'react';
import { 
  X, 
  Sparkles, 
  Loader2, 
  CheckCircle2, 
  AlertCircle, 
  Plus
} from 'lucide-react';
import { ExtractedNumber, NumberCategory, PdfFileInfo } from '../types';

interface AiExtractionModalProps {
  isOpen: boolean;
  onClose: () => void;
  files: PdfFileInfo[];
  onAddAiExtractedNumbers: (items: ExtractedNumber[]) => void;
}

export const AiExtractionModal: React.FC<AiExtractionModalProps> = ({
  isOpen,
  onClose,
  files,
  onAddAiExtractedNumbers,
}) => {
  const [selectedFileId, setSelectedFileId] = useState<string>(files[0]?.id || '');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [aiSummary, setAiSummary] = useState<string | null>(null);
  const [extractedItems, setExtractedItems] = useState<ExtractedNumber[]>([]);

  if (!isOpen) return null;

  const currentFile = files.find((f) => f.id === (selectedFileId || files[0]?.id));

  const handleRunAiExtract = async () => {
    if (!currentFile) {
      setError('Pilih file PDF terlebih dahulu');
      return;
    }

    setIsLoading(true);
    setError(null);
    setAiSummary(null);
    setExtractedItems([]);

    try {
      const response = await fetch('/api/ai-extract', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: currentFile.rawTextFull,
          filename: currentFile.name,
        }),
      });

      const resJson = await response.json();

      if (!response.ok || !resJson.success) {
        throw new Error(resJson.error || 'Gagal memproses dengan AI');
      }

      const data = resJson.data;
      setAiSummary(data.summary || 'Analisis AI selesai.');

      const convertedItems: ExtractedNumber[] = (data.items || []).map((item: any) => ({
        id: `ai_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
        rawNumber: item.rawNumber,
        normalizedNumber: item.normalizedNumber || item.rawNumber,
        category: (item.category as NumberCategory) || 'other',
        label: item.label || 'Ekstraksi AI',
        entityName: item.entityName,
        fileName: currentFile.name,
        fileId: currentFile.id,
        pageNumber: 1,
        context: item.context || `Ditemukan oleh AI pada ${currentFile.name}`,
        confidence: item.confidence || 0.98,
        isAiExtracted: true,
        selected: true,
      }));

      setExtractedItems(convertedItems);
    } catch (err: any) {
      setError(err.message || 'Terjadi kesalahan saat memanggil Gemini AI');
    } finally {
      setIsLoading(false);
    }
  };

  const handleApplyToMainTable = () => {
    if (extractedItems.length > 0) {
      onAddAiExtractedNumbers(extractedItems);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        id="ai-extraction-modal" 
        className="bg-white rounded-2xl border border-slate-200 max-w-xl w-full overflow-hidden flex flex-col max-h-[90vh] shadow-xl"
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-white">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                Gemini AI Engine
              </label>
              <h3 className="text-sm font-semibold text-slate-900">AI Document Parser</h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-4">
          {/* File selector */}
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5">
              Pilih Dokumen PDF:
            </label>
            <select
              value={selectedFileId}
              onChange={(e) => setSelectedFileId(e.target.value)}
              className="w-full px-3 py-2 text-xs md:text-sm bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-800 outline-hidden focus:border-indigo-600 focus:bg-white transition-colors"
            >
              {files.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name} ({f.totalPages} Halaman)
                </option>
              ))}
            </select>
          </div>

          {/* Action Trigger */}
          <button
            id="btn-run-ai-extract"
            onClick={handleRunAiExtract}
            disabled={isLoading || !currentFile}
            className="w-full py-2.5 px-4 rounded-xl text-xs md:text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Menganalisis Dokumen dengan Gemini AI...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Mulai Analisis AI Sekarang</span>
              </>
            )}
          </button>

          {/* Error Message */}
          {error && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 flex items-start gap-2.5 text-xs text-rose-700">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
              <div>
                <p className="font-semibold">Gagal melakukan analisis AI:</p>
                <p className="mt-0.5 text-rose-600">{error}</p>
              </div>
            </div>
          )}

          {/* AI Result View */}
          {aiSummary && (
            <div className="space-y-3 pt-2">
              <div className="p-3 bg-indigo-50/40 border border-indigo-100 rounded-xl">
                <p className="text-xs font-semibold text-indigo-950 flex items-center gap-1.5 mb-1">
                  <CheckCircle2 className="w-4 h-4 text-indigo-600" /> Ringkasan Analisis AI:
                </p>
                <p className="text-xs text-slate-600 leading-relaxed">{aiSummary}</p>
              </div>

              <div>
                <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
                  Nomor Terdeteksi ({extractedItems.length})
                </label>

                <div className="max-h-52 overflow-y-auto space-y-1.5 border border-slate-200 rounded-xl p-2 bg-slate-50/50">
                  {extractedItems.map((item, idx) => (
                    <div
                      key={idx}
                      className="p-2 bg-white rounded-lg border border-slate-200/80 text-xs flex items-center justify-between gap-2"
                    >
                      <div>
                        <span className="font-semibold font-mono text-slate-900 mr-2">
                          {item.normalizedNumber}
                        </span>
                        <span className="text-[11px] text-slate-500">
                          {item.label} {item.entityName ? `(${item.entityName})` : ''}
                        </span>
                      </div>
                      <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-700 border border-slate-200">
                        {item.category}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-3.5 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 rounded-lg transition-colors"
          >
            Batal
          </button>

          {extractedItems.length > 0 && (
            <button
              onClick={handleApplyToMainTable}
              className="px-3.5 py-1.5 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-colors flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Gabungkan {extractedItems.length} Nomor ke Tabel</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

