import React, { useState, useEffect, useMemo } from 'react';
import { 
  X, 
  Check, 
  RotateCcw, 
  PenLine, 
  ArrowRight, 
  Sparkles, 
  FileText,
  Sliders,
  Hash,
  Search,
  Type
} from 'lucide-react';
import { PdfFileInfo } from '../types';

interface BatchRenameModalProps {
  isOpen: boolean;
  onClose: () => void;
  files: PdfFileInfo[];
  onApplyRename: (renamedMap: Record<string, string>) => void;
}

type RenameMode = 'prefix_suffix' | 'find_replace' | 'sequential' | 'casing' | 'manual';

export const BatchRenameModal: React.FC<BatchRenameModalProps> = ({
  isOpen,
  onClose,
  files,
  onApplyRename,
}) => {
  const [activeMode, setActiveMode] = useState<RenameMode>('prefix_suffix');

  // Mode 1: Prefix & Suffix
  const [prefix, setPrefix] = useState('');
  const [suffix, setSuffix] = useState('');

  // Mode 2: Find & Replace
  const [findText, setFindText] = useState('');
  const [replaceText, setReplaceText] = useState('');
  const [matchCase, setMatchCase] = useState(false);

  // Mode 3: Sequential & Template
  const [templatePattern, setTemplatePattern] = useState('Dokumen_{0n}');
  const [startNumber, setStartNumber] = useState(1);

  // Mode 4: Casing & Formatting
  const [casingType, setCasingType] = useState<
    'none' | 'uppercase' | 'lowercase' | 'titlecase' | 'spaces_to_underscores' | 'spaces_to_dashes' | 'clean_special'
  >('none');

  // Selected files for batch action
  const [selectedFileIds, setSelectedFileIds] = useState<Set<string>>(new Set());

  // Manual overrides per file ID
  const [manualNames, setManualNames] = useState<Record<string, string>>({});

  // Initialize selected files and manual names
  useEffect(() => {
    if (isOpen && files.length > 0) {
      setSelectedFileIds(new Set(files.map((f) => f.id)));
      const initialMap: Record<string, string> = {};
      files.forEach((f) => {
        initialMap[f.id] = f.name;
      });
      setManualNames(initialMap);
    }
  }, [isOpen, files]);

  // Clean filename extension utility
  const cleanExtension = (name: string): { base: string; ext: string } => {
    if (name.toLowerCase().endsWith('.pdf')) {
      return {
        base: name.slice(0, -4),
        ext: '.pdf',
      };
    }
    return {
      base: name,
      ext: '.pdf',
    };
  };

  // Helper to apply title case
  const toTitleCase = (str: string): string => {
    return str
      .toLowerCase()
      .split(' ')
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  };

  // Compute preview of new names based on current mode & settings
  const previewList = useMemo(() => {
    const today = new Date();
    const YYYY = today.getFullYear().toString();
    const MM = String(today.getMonth() + 1).padStart(2, '0');
    const DD = String(today.getDate()).padStart(2, '0');

    let counter = startNumber;

    return files.map((file) => {
      const isSelected = selectedFileIds.has(file.id);
      const original = file.name;
      const { base: originalBase } = cleanExtension(original);

      if (!isSelected) {
        return {
          id: file.id,
          originalName: original,
          newName: manualNames[file.id] || original,
          hasChanged: (manualNames[file.id] || original) !== original,
          isSelected: false,
        };
      }

      let newBase = originalBase;

      if (activeMode === 'prefix_suffix') {
        newBase = `${prefix}${newBase}${suffix}`;
      } else if (activeMode === 'find_replace' && findText) {
        if (matchCase) {
          newBase = newBase.split(findText).join(replaceText);
        } else {
          const regex = new RegExp(findText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
          newBase = newBase.replace(regex, replaceText);
        }
      } else if (activeMode === 'sequential') {
        const numStr = String(counter);
        const num0Str = String(counter).padStart(2, '0');
        const num00Str = String(counter).padStart(3, '0');

        newBase = templatePattern
          .replace(/\{00n\}/g, num00Str)
          .replace(/\{0n\}/g, num0Str)
          .replace(/\{n\}/g, numStr)
          .replace(/\{original\}/g, originalBase)
          .replace(/\{YYYY\}/g, YYYY)
          .replace(/\{MM\}/g, MM)
          .replace(/\{DD\}/g, DD);

        counter += 1;
      } else if (activeMode === 'casing') {
        if (casingType === 'uppercase') {
          newBase = newBase.toUpperCase();
        } else if (casingType === 'lowercase') {
          newBase = newBase.toLowerCase();
        } else if (casingType === 'titlecase') {
          newBase = toTitleCase(newBase);
        } else if (casingType === 'spaces_to_underscores') {
          newBase = newBase.replace(/\s+/g, '_');
        } else if (casingType === 'spaces_to_dashes') {
          newBase = newBase.replace(/\s+/g, '-');
        } else if (casingType === 'clean_special') {
          newBase = newBase.replace(/[^a-zA-Z0-9_-]/g, '_').replace(/_+/g, '_');
        }
      } else if (activeMode === 'manual') {
        const manual = manualNames[file.id];
        if (manual) {
          const { base: mBase } = cleanExtension(manual);
          newBase = mBase;
        }
      }

      // Ensure valid, non-empty base name
      const trimmed = newBase.trim() || originalBase;
      const finalName = `${trimmed}.pdf`;

      return {
        id: file.id,
        originalName: original,
        newName: finalName,
        hasChanged: finalName !== original,
        isSelected: true,
      };
    });
  }, [
    files,
    selectedFileIds,
    activeMode,
    prefix,
    suffix,
    findText,
    replaceText,
    matchCase,
    templatePattern,
    startNumber,
    casingType,
    manualNames,
  ]);

  const changedCount = previewList.filter((item) => item.hasChanged).length;

  const handleToggleSelectFile = (fileId: string) => {
    setSelectedFileIds((prev) => {
      const next = new Set(prev);
      if (next.has(fileId)) {
        next.delete(fileId);
      } else {
        next.add(fileId);
      }
      return next;
    });
  };

  const handleSelectAllFiles = (selectAll: boolean) => {
    if (selectAll) {
      setSelectedFileIds(new Set(files.map((f) => f.id)));
    } else {
      setSelectedFileIds(new Set());
    }
  };

  const handleManualNameChange = (fileId: string, value: string) => {
    setManualNames((prev) => ({
      ...prev,
      [fileId]: value,
    }));
  };

  const handleResetAll = () => {
    setPrefix('');
    setSuffix('');
    setFindText('');
    setReplaceText('');
    setTemplatePattern('Dokumen_{0n}');
    setStartNumber(1);
    setCasingType('none');
    const initialMap: Record<string, string> = {};
    files.forEach((f) => {
      initialMap[f.id] = f.name;
    });
    setManualNames(initialMap);
  };

  const handleApply = () => {
    const renameMap: Record<string, string> = {};
    previewList.forEach((item) => {
      if (item.hasChanged) {
        renameMap[item.id] = item.newName;
      }
    });

    onApplyRename(renameMap);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        id="batch-rename-modal"
        className="bg-white rounded-2xl border border-slate-200 max-w-3xl w-full overflow-hidden flex flex-col max-h-[92vh] shadow-xl"
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-white">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
              <PenLine className="w-4 h-4" />
            </div>
            <div>
              <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                File Manager
              </label>
              <h3 className="text-sm font-semibold text-slate-900">
                Ganti Nama File PDF Sekaligus (Batch Rename)
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-5">
          {/* Mode Selector Tabs */}
          <div>
            <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
              Metode Ganti Nama
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5 p-1 bg-slate-100/70 rounded-xl">
              <button
                type="button"
                onClick={() => setActiveMode('prefix_suffix')}
                className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-medium transition-all ${
                  activeMode === 'prefix_suffix'
                    ? 'bg-white text-indigo-600 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>Prefix / Suffix</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveMode('find_replace')}
                className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-medium transition-all ${
                  activeMode === 'find_replace'
                    ? 'bg-white text-indigo-600 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Search className="w-3.5 h-3.5" />
                <span>Cari & Ganti</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveMode('sequential')}
                className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-medium transition-all ${
                  activeMode === 'sequential'
                    ? 'bg-white text-indigo-600 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Hash className="w-3.5 h-3.5" />
                <span>Penomoran</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveMode('casing')}
                className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-medium transition-all ${
                  activeMode === 'casing'
                    ? 'bg-white text-indigo-600 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Type className="w-3.5 h-3.5" />
                <span>Format Teks</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveMode('manual')}
                className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-medium transition-all ${
                  activeMode === 'manual'
                    ? 'bg-white text-indigo-600 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <PenLine className="w-3.5 h-3.5" />
                <span>Edit Manual</span>
              </button>
            </div>
          </div>

          {/* Mode Configuration Form */}
          <div className="bg-slate-50/70 border border-slate-200 rounded-xl p-4 space-y-3">
            {activeMode === 'prefix_suffix' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-medium text-slate-600 mb-1">
                    Tambah Awalan (Prefix)
                  </label>
                  <input
                    type="text"
                    value={prefix}
                    onChange={(e) => setPrefix(e.target.value)}
                    placeholder="Contoh: INV-2026- atau LAP_"
                    className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg outline-hidden focus:border-indigo-600"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-600 mb-1">
                    Tambah Akhiran (Suffix)
                  </label>
                  <input
                    type="text"
                    value={suffix}
                    onChange={(e) => setSuffix(e.target.value)}
                    placeholder="Contoh: _VERIFIED atau _v2"
                    className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg outline-hidden focus:border-indigo-600"
                  />
                </div>
              </div>
            )}

            {activeMode === 'find_replace' && (
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 mb-1">
                      Cari Kata / Karakter
                    </label>
                    <input
                      type="text"
                      value={findText}
                      onChange={(e) => setFindText(e.target.value)}
                      placeholder="Contoh: scan_ atau Untitled"
                      className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg outline-hidden focus:border-indigo-600"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 mb-1">
                      Ganti Menjadi
                    </label>
                    <input
                      type="text"
                      value={replaceText}
                      onChange={(e) => setReplaceText(e.target.value)}
                      placeholder="Contoh: Faktur_Pajak_"
                      className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg outline-hidden focus:border-indigo-600"
                    />
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    id="chk-match-case"
                    type="checkbox"
                    checked={matchCase}
                    onChange={(e) => setMatchCase(e.target.checked)}
                    className="w-3.5 h-3.5 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300 cursor-pointer"
                  />
                  <label htmlFor="chk-match-case" className="text-xs text-slate-600 cursor-pointer">
                    Sensitif Huruf Besar / Kecil (Match Case)
                  </label>
                </div>
              </div>
            )}

            {activeMode === 'sequential' && (
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-2">
                    <label className="block text-[11px] font-medium text-slate-600 mb-1">
                      Pola Format Template
                    </label>
                    <input
                      type="text"
                      value={templatePattern}
                      onChange={(e) => setTemplatePattern(e.target.value)}
                      placeholder="Dokumen_{0n} atau {original}_{n}"
                      className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg outline-hidden focus:border-indigo-600 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 mb-1">
                      Nomor Awal
                    </label>
                    <input
                      type="number"
                      min={1}
                      value={startNumber}
                      onChange={(e) => setStartNumber(Math.max(1, parseInt(e.target.value) || 1))}
                      className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg outline-hidden focus:border-indigo-600"
                    />
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  <span className="text-[11px] text-slate-400 font-medium mr-1">Preset Cepat:</span>
                  {[
                    'Dokumen_{0n}',
                    'Invoice_{YYYY}_{0n}',
                    '{original}_{n}',
                    'File_PDF_{00n}',
                    'Faktur_{DD}{MM}_{0n}',
                  ].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setTemplatePattern(preset)}
                      className="px-2 py-0.5 rounded text-[11px] font-mono bg-white hover:bg-indigo-50 hover:text-indigo-700 text-slate-600 border border-slate-200 transition-colors"
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {activeMode === 'casing' && (
              <div>
                <label className="block text-[11px] font-medium text-slate-600 mb-1.5">
                  Pilih Transformasi Huruf & Karakter
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    { id: 'uppercase', label: 'SEMUA KAPITAL (UPPER)' },
                    { id: 'lowercase', label: 'semua kecil (lower)' },
                    { id: 'titlecase', label: 'Kapital Tiap Kata (Title)' },
                    { id: 'spaces_to_underscores', label: 'Spasi -> Underscore (_)' },
                    { id: 'spaces_to_dashes', label: 'Spasi -> Strip (-)' },
                    { id: 'clean_special', label: 'Bersihkan Simbol Khusus' },
                  ].map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setCasingType(opt.id as any)}
                      className={`p-2 rounded-lg text-left text-xs font-medium border transition-colors ${
                        casingType === opt.id
                          ? 'bg-indigo-50 text-indigo-700 border-indigo-200'
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {activeMode === 'manual' && (
              <p className="text-xs text-slate-500">
                Ketik langsung nama baru yang Anda inginkan pada kolom "Nama File Baru" di tabel pratinjau di bawah ini.
              </p>
            )}
          </div>

          {/* Live Preview Table */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={selectedFileIds.size === files.length && files.length > 0}
                  onChange={(e) => handleSelectAllFiles(e.target.checked)}
                  className="w-3.5 h-3.5 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300 cursor-pointer"
                />
                <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                  Pratinjau Perubahan Nama ({changedCount} dari {files.length} file akan berubah)
                </label>
              </div>

              <button
                type="button"
                onClick={handleResetAll}
                className="inline-flex items-center gap-1 text-xs text-slate-500 hover:text-slate-800 transition-colors"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset Pola</span>
              </button>
            </div>

            <div className="border border-slate-200 rounded-xl overflow-hidden max-h-64 overflow-y-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-50 text-slate-400 border-b border-slate-100 text-[11px] font-bold uppercase tracking-wider sticky top-0">
                  <tr>
                    <th className="p-2.5 w-8 text-center"></th>
                    <th className="p-2.5 w-10 text-center font-semibold">#</th>
                    <th className="p-2.5">Nama Asli</th>
                    <th className="p-2.5 w-6 text-center"></th>
                    <th className="p-2.5">Nama File Baru (Bisa Diedit)</th>
                    <th className="p-2.5 w-24 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {previewList.map((item, idx) => (
                    <tr 
                      key={item.id}
                      className={`hover:bg-slate-50/70 transition-colors ${
                        item.hasChanged ? 'bg-indigo-50/20' : ''
                      }`}
                    >
                      <td className="p-2.5 text-center">
                        <input
                          type="checkbox"
                          checked={selectedFileIds.has(item.id)}
                          onChange={() => handleToggleSelectFile(item.id)}
                          className="w-3.5 h-3.5 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300 cursor-pointer"
                        />
                      </td>
                      <td className="p-2.5 text-center font-mono text-slate-400 text-[11px]">
                        {idx + 1}
                      </td>
                      <td className="p-2.5 font-medium text-slate-700 max-w-[200px] truncate" title={item.originalName}>
                        {item.originalName}
                      </td>
                      <td className="p-2.5 text-center text-slate-400">
                        <ArrowRight className="w-3 h-3 inline" />
                      </td>
                      <td className="p-2">
                        <input
                          type="text"
                          value={item.newName}
                          onChange={(e) => handleManualNameChange(item.id, e.target.value)}
                          className="w-full px-2.5 py-1 text-xs font-medium text-slate-900 bg-white border border-slate-200 rounded-lg outline-hidden focus:border-indigo-600"
                        />
                      </td>
                      <td className="p-2.5 text-center">
                        {item.hasChanged ? (
                          <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded text-[10px] font-medium bg-indigo-50 text-indigo-700 border border-indigo-100">
                            <Check className="w-2.5 h-2.5" /> Berubah
                          </span>
                        ) : (
                          <span className="text-[10px] text-slate-400">
                            Sama
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-3.5 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 rounded-lg transition-colors"
          >
            Batal
          </button>
          
          <button
            id="btn-apply-batch-rename"
            onClick={handleApply}
            disabled={changedCount === 0}
            className="px-4 py-1.5 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Check className="w-3.5 h-3.5" />
            <span>Terapkan Nama Baru ({changedCount} File)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
