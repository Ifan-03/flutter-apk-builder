export type NumberCategory =
  | 'phone'
  | 'invoice'
  | 'id_card'
  | 'bank_account'
  | 'currency'
  | 'serial_sku'
  | 'date_time'
  | 'custom'
  | 'other';

export type HealthSeverity = 'critical' | 'warning' | 'info';

export interface DataHealthIssue {
  id: string;
  itemId: string;
  ruleId: string;
  ruleName: string;
  severity: HealthSeverity;
  title: string;
  description: string;
  suggestedFix?: string;
  canAutoFix?: boolean;
  autoFixType?: 'remove_duplicate' | 'trim_whitespace' | 'format_phone_prefix' | 'strip_negative' | 'custom';
  autoFixValue?: string;
}

export interface ExtractedNumber {
  id: string;
  rawNumber: string;
  normalizedNumber: string;
  category: NumberCategory;
  label: string;
  entityName?: string;
  fileName: string;
  fileId: string;
  pageNumber: number;
  context: string;
  occurrences?: number;
  confidence?: number;
  isAiExtracted?: boolean;
  isMlCategorized?: boolean;
  mlConfidence?: number;
  mlExplanation?: string;
  selected?: boolean;
  healthIssues?: DataHealthIssue[];
}

export interface MlClassificationResult {
  predictedCategory: 'invoice' | 'id_card' | 'bank_account' | null;
  confidence: number;
  probabilities: {
    invoice: number;
    id_card: number;
    bank_account: number;
  };
  topFeatures: Array<{ feature: string; weight: number; targetCategory: string }>;
  explanation: string;
  suggestedLabel: string;
  suggestedEntity?: string;
  isClassified: boolean;
}

export interface MlClassifierOptions {
  threshold?: number; // default 0.55
  targetCategoriesOnly?: ('invoice' | 'id_card' | 'bank_account')[];
  prioritizeUnclassifiedOnly?: boolean; // only classify 'other', 'custom', or unknown
}

export interface PdfDocumentMetadata {
  title?: string;
  author?: string;
  creator?: string;
  producer?: string;
  creationDate?: string;
  modificationDate?: string;
  subject?: string;
  keywords?: string;
  pdfFormatVersion?: string;
  pageCount?: number;
  encrypted?: boolean;
  fileSizeFormatted?: string;
  rawInfo?: Record<string, any>;
}

export interface PdfPageContent {
  pageNumber: number;
  text: string;
  rawItems?: string[];
}

export interface PdfFileInfo {
  id: string;
  name: string;
  size: number;
  totalPages: number;
  extractedCount: number;
  status: 'idle' | 'parsing' | 'extracting' | 'completed' | 'error';
  error?: string;
  pages: PdfPageContent[];
  rawTextFull: string;
  metadata?: PdfDocumentMetadata;
}

export interface ExtractionFilter {
  categories: NumberCategory[];
  searchQuery: string;
  selectedFileId: string; // 'all' or specific file id
  removeDuplicates: boolean;
  phoneFormat: 'original' | 'e164_plus' | 'e164_noplus' | 'local_08' | 'clean_digits';
  minDigits: number;
  maxDigits: number;
  onlyHealthIssues?: boolean;
  healthSeverityFilter?: 'all' | 'critical' | 'warning' | 'info';
}

export interface CustomRegexRule {
  id: string;
  name: string;
  pattern: string;
  flags: string;
  category: NumberCategory;
  label: string;
  enabled: boolean;
}

export interface HealthRuleConfig {
  id: string;
  name: string;
  category?: NumberCategory | 'all';
  severity: HealthSeverity;
  description: string;
  enabled: boolean;
  isCustom?: boolean;
  customRegex?: string;
  params?: {
    minPhoneDigits?: number;
    maxPhoneDigits?: number;
    allowNegativeCurrency?: boolean;
    checkDuplicateInvoices?: boolean;
    requireExactNikDigits?: number; // 16
    requireNpwpDigits?: number[]; // [15, 16]
    minBankAccountDigits?: number; // 8
    disallowedPrefixes?: string[];
  };
}

export interface HealthCheckReport {
  timestamp: number;
  totalRecords: number;
  healthyCount: number;
  flaggedCount: number;
  healthScore: number; // 0 to 100
  criticalCount: number;
  warningCount: number;
  infoCount: number;
  issues: DataHealthIssue[];
  issuesByItem: Record<string, DataHealthIssue[]>;
  categoryStats: Record<string, { total: number; issues: number }>;
}

export interface ExtractionStats {
  totalNumbers: number;
  uniqueNumbers: number;
  phoneCount: number;
  invoiceCount: number;
  idCardCount: number;
  bankAccountCount: number;
  currencyCount: number;
  serialCount: number;
  otherCount: number;
  totalFiles: number;
  totalPages: number;
  healthScore?: number;
  issueCount?: number;
}

export interface ExportColumnConfig {
  key: keyof ExtractedNumber | 'index' | 'whatsappLink';
  label: string;
  selected: boolean;
}

export type SubscriptionTier = 'free' | 'premium' | 'enterprise';

export interface UserSubscription {
  tier: SubscriptionTier;
  isPremium: boolean;
  expiresAt?: string | null;
  featuresUnlocked?: string[];
}
