import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { 
  FileSpreadsheet, 
  Check, 
  ShieldCheck, 
  Zap,
  Activity
} from 'lucide-react';
import { 
  CustomRegexRule, 
  ExtractedNumber, 
  ExtractionFilter, 
  ExtractionStats, 
  HealthCheckReport, 
  HealthRuleConfig, 
  PdfFileInfo,
  NumberCategory
} from './types';
import { extractTextFromPdf } from './utils/pdfParser';
import { extractNumbersFromText, normalizePhoneNumber } from './utils/numberExtractor';
import { generateSampleContactDirectoryPdf, generateSampleInvoicePdf } from './utils/samplePdfs';
import { DEFAULT_HEALTH_RULES, runDataHealthCheck } from './utils/dataHealthValidator';
import { 
  saveAppStateToStorage, 
  loadAppStateFromStorage, 
  clearAppStateFromStorage 
} from './utils/storage';
import { Header } from './components/Header';
import { FileUploader } from './components/FileUploader';
import { ExtractionSettings } from './components/ExtractionSettings';
import { NumberTable } from './components/NumberTable';
import { ExportModal } from './components/ExportModal';
import { CustomRegexModal } from './components/CustomRegexModal';
import { AiExtractionModal } from './components/AiExtractionModal';
import { PdfViewerModal } from './components/PdfViewerModal';
import { EditNumberModal } from './components/EditNumberModal';
import { BatchRenameModal } from './components/BatchRenameModal';
import { DataHealthModal } from './components/DataHealthModal';
import { MlCategorizerModal } from './components/MlCategorizerModal';
import { FindAndReplaceModal } from './components/FindAndReplaceModal';
import { PremiumAccessGate } from './components/PremiumAccessGate';
import { PaymentModal } from './components/PaymentModal';
import { LoginPageModal } from './components/LoginPageModal';
import { LoginPage } from './components/LoginPage';
import { getMlAutoCategorizeStats } from './utils/mlAutoCategorizer';
import { DashboardOverview } from './components/DashboardOverview';
import { extractPdfPagesFromNumbers } from './utils/pdfExtractorUtils';
import { auth, onAuthStateChanged } from './firebase';
import { syncToCloud, loadFromCloud } from './utils/firebaseStorage';

const DEFAULT_FILTER: ExtractionFilter = {
  categories: ['phone', 'invoice', 'id_card', 'bank_account', 'currency', 'serial_sku', 'other'],
  searchQuery: '',
  selectedFileId: 'all',
  removeDuplicates: false,
  phoneFormat: 'e164_noplus',
  minDigits: 3,
  maxDigits: 30,
  onlyHealthIssues: false,
};

export default function App() {
  const [currentView, setCurrentView] = useState<'dashboard' | 'login'>('login');
  const [dashboardMode, setDashboardMode] = useState<'table' | 'analytics'>('table');
  const [files, setFiles] = useState<PdfFileInfo[]>([]);
  const [rawExtractedNumbers, setRawExtractedNumbers] = useState<ExtractedNumber[]>([]);
  const [filter, setFilter] = useState<ExtractionFilter>(DEFAULT_FILTER);
  const [customRules, setCustomRules] = useState<CustomRegexRule[]>([]);
  const [healthRules, setHealthRules] = useState<HealthRuleConfig[]>(DEFAULT_HEALTH_RULES);
  const [isProcessing, setIsProcessing] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Auto-Save states
  const [lastSavedAt, setLastSavedAt] = useState<number | null>(null);
  const [isAutoSaving, setIsAutoSaving] = useState(false);
  const [isHydrated, setIsHydrated] = useState(false);

  // Modals state
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isCustomRegexModalOpen, setIsCustomRegexModalOpen] = useState(false);
  const [isAiExtractModalOpen, setIsAiExtractModalOpen] = useState(false);
  const [isBatchRenameModalOpen, setIsBatchRenameModalOpen] = useState(false);
  const [isHealthModalOpen, setIsHealthModalOpen] = useState(false);
  const [isMlModalOpen, setIsMlModalOpen] = useState(false);
  const [isFindReplaceModalOpen, setIsFindReplaceModalOpen] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [viewingPdfFile, setViewingPdfFile] = useState<PdfFileInfo | null>(null);
  const [viewingInitialPage, setViewingInitialPage] = useState<number>(1);
  const [viewingHighlightText, setViewingHighlightText] = useState<string | undefined>(undefined);
  const [viewingHighlightItem, setViewingHighlightItem] = useState<ExtractedNumber | null>(null);
  const [editingItem, setEditingItem] = useState<ExtractedNumber | null>(null);

  // User subscription status state: 'free' by default so user can test the PremiumAccessGate
  const [user, setUser] = useState<{
    id: string;
    name: string;
    email: string;
    status: 'free' | 'premium';
    role: 'admin' | 'user';
  }>({
    id: 'usr-001',
    name: 'Pengguna',
    email: '',
    status: 'free',
    role: 'user'
  });

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // 1. Initial State Restoration from LocalStorage on mount
  useEffect(() => {
    const saved = loadAppStateFromStorage();
    if (saved.files.length > 0 || saved.rawExtractedNumbers.length > 0) {
      setFiles(saved.files);
      setRawExtractedNumbers(saved.rawExtractedNumbers);
      if (saved.customRules && saved.customRules.length > 0) {
        setCustomRules(saved.customRules);
      }
      setLastSavedAt(saved.lastSavedAt);
      showToast(`Data sesi sebelumnya dipulihkan (${saved.rawExtractedNumbers.length} nomor dari ${saved.files.length} file).`);
    }
    setIsHydrated(true);
  }, []);

  // 2. Debounced and Periodic Auto-Save Effect
  useEffect(() => {
    if (!isHydrated) return;

    setIsAutoSaving(true);
    const saveTimer = setTimeout(() => {
      const result = saveAppStateToStorage({
        files,
        rawExtractedNumbers,
        customRules,
      });

      if (result.success) {
        setLastSavedAt(result.timestamp);
      }
      setIsAutoSaving(false);
    }, 1200);

    return () => clearTimeout(saveTimer);
  }, [files, rawExtractedNumbers, customRules, isHydrated]);

  // Firebase Auth listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        setUser((prev) => ({
          ...prev,
          id: firebaseUser.uid,
          email: firebaseUser.email || prev.email,
          name: firebaseUser.displayName || (firebaseUser.email?.split('@')[0] || prev.name),
          role: firebaseUser.email?.toLowerCase().includes('admin') ? 'admin' : 'user'
        }));
        setCurrentView('dashboard');
        
        // Auto-load from cloud
        if (isHydrated) {
          const res = await loadFromCloud(firebaseUser.uid);
          if (res.success && (res.files.length > 0 || res.numbers.length > 0)) {
            setFiles(res.files);
            setRawExtractedNumbers(res.numbers);
            showToast('Data Cloud berhasil dimuat!');
          }
        }
      }
    });
    return () => unsubscribe();
  }, [isHydrated]);

  // Cloud sync handler
  const handleCloudSync = async () => {
    if (!user.email || user.email === 'guest@example.com') {
      showToast('Silakan login menggunakan Google untuk sinkronisasi cloud.');
      return;
    }
    
    setIsProcessing(true);
    showToast('Sedang mensinkronisasikan ke Cloud...');
    const result = await syncToCloud(user.id, files, rawExtractedNumbers);
    setIsProcessing(false);
    
    if (result.success) {
      showToast(result.message);
    } else {
      alert(result.message);
    }
  };

  // Manual save handler
  const handleManualSave = useCallback(() => {
    setIsAutoSaving(true);
    const res = saveAppStateToStorage({
      files,
      rawExtractedNumbers,
      customRules,
    });
    if (res.success) {
      setLastSavedAt(res.timestamp);
      showToast('Data berhasil disimpan secara manual ke LocalStorage.');
    } else {
      showToast(res.error || 'Gagal menyimpan ke penyimpanan lokal.');
    }
    setIsAutoSaving(false);
  }, [files, rawExtractedNumbers, customRules]);

  // Clear saved storage & reset state
  const handleClearSavedData = useCallback(() => {
    clearAppStateFromStorage();
    setFiles([]);
    setRawExtractedNumbers([]);
    setLastSavedAt(null);
    showToast('Penyimpanan lokal dibersihkan. Sesi berhasil di-reset.');
  }, []);

  const handleUpgradeSuccess = () => {
    setUser((prev) => ({ ...prev, status: 'premium' }));
    showToast('Selamat! Akun Anda aktif sebagai Premium Member.');
  };

  const handleToggleUserTier = () => {
    setUser((prev) => ({
      ...prev,
      status: prev.status === 'free' ? 'premium' : 'free',
    }));
    showToast(
      user.status === 'free'
        ? 'Mode simulasi diubah ke: Premium'
        : 'Mode simulasi diubah ke: Free (Terkunci)'
    );
  };

  // Bulk Find & Replace handler
  const handleApplyFindReplace = (updatedItems: ExtractedNumber[], updatedCount: number) => {
    setRawExtractedNumbers(updatedItems);
    showToast(`${updatedCount} baris data berhasil diperbarui lewat Find & Replace!`);
  };

  // ML Auto-Categorizer Stats
  const mlStats = useMemo(() => {
    return getMlAutoCategorizeStats(rawExtractedNumbers);
  }, [rawExtractedNumbers]);

  const handleApplyMlClassification = (updatedItems: ExtractedNumber[], count: number) => {
    setRawExtractedNumbers(updatedItems);
    showToast(`${count} nomor berhasil diklasifikasikan menggunakan Machine Learning!`);
  };

  // Batch rename files and propagate to extracted data
  const handleBatchRename = (renamedMap: Record<string, string>) => {
    setFiles((prev) =>
      prev.map((f) => {
        if (renamedMap[f.id] && renamedMap[f.id] !== f.name) {
          return { ...f, name: renamedMap[f.id] };
        }
        return f;
      })
    );

    setRawExtractedNumbers((prev) =>
      prev.map((item) => {
        if (renamedMap[item.fileId] && renamedMap[item.fileId] !== item.fileName) {
          return { ...item, fileName: renamedMap[item.fileId] };
        }
        return item;
      })
    );

    const count = Object.keys(renamedMap).length;
    showToast(`Nama ${count} file PDF berhasil diperbarui.`);
  };

  // Rename a single file inline and update extracted data
  const handleRenameSingleFile = (fileId: string, newName: string) => {
    const cleanName = newName.trim();
    if (!cleanName) return;
    const finalName = cleanName.toLowerCase().endsWith('.pdf') ? cleanName : `${cleanName}.pdf`;

    setFiles((prev) =>
      prev.map((f) => (f.id === fileId ? { ...f, name: finalName } : f))
    );

    setRawExtractedNumbers((prev) =>
      prev.map((item) => (item.fileId === fileId ? { ...item, fileName: finalName } : item))
    );

    showToast(`Nama file diperbarui menjadi "${finalName}".`);
  };

  // Re-run extraction across all uploaded files whenever customRules change
  const reExtractAll = useCallback((uploadedFiles: PdfFileInfo[], rules: CustomRegexRule[]) => {
    let allNumbers: ExtractedNumber[] = [];
    const updatedFiles = uploadedFiles.map((file) => {
      let fileNumCount = 0;
      file.pages.forEach((page) => {
        const pageNumbers = extractNumbersFromText(page.text, file.name, file.id, page.pageNumber, rules);
        allNumbers = [...allNumbers, ...pageNumbers];
        fileNumCount += pageNumbers.length;
      });
      return { ...file, extractedCount: fileNumCount };
    });

    setFiles(updatedFiles);
    setRawExtractedNumbers(allNumbers);
  }, []);

  // Process incoming PDF files
  const handleFilesSelected = async (selectedFiles: FileList | File[]) => {
    setIsProcessing(true);
    const filesArray = Array.from(selectedFiles);
    const newFiles: PdfFileInfo[] = [];
    let newNumbers: ExtractedNumber[] = [];

    for (const file of filesArray) {
      const parsedFileInfo = await extractTextFromPdf(file, file.name);
      
      let fileNumbers: ExtractedNumber[] = [];
      parsedFileInfo.pages.forEach((page) => {
        const pageNums = extractNumbersFromText(page.text, file.name, parsedFileInfo.id, page.pageNumber, customRules);
        fileNumbers = [...fileNumbers, ...pageNums];
      });

      parsedFileInfo.extractedCount = fileNumbers.length;
      newFiles.push(parsedFileInfo);
      newNumbers = [...newNumbers, ...fileNumbers];
    }

    setFiles((prev) => [...prev, ...newFiles]);
    setRawExtractedNumbers((prev) => [...prev, ...newNumbers]);
    setIsProcessing(false);

    showToast(`Berhasil mengekstrak ${newNumbers.length} nomor dari ${newFiles.length} file PDF.`);
  };

  // Load interactive demo PDF samples
  const handleLoadSample = async (type: 'invoice' | 'contacts') => {
    setIsProcessing(true);
    const sample = type === 'invoice' ? generateSampleInvoicePdf() : generateSampleContactDirectoryPdf();
    
    const parsedFileInfo = await extractTextFromPdf(sample.buffer, sample.name);
    let fileNumbers: ExtractedNumber[] = [];
    parsedFileInfo.pages.forEach((page) => {
      const pageNums = extractNumbersFromText(page.text, sample.name, parsedFileInfo.id, page.pageNumber, customRules);
      fileNumbers = [...fileNumbers, ...pageNums];
    });

    parsedFileInfo.extractedCount = fileNumbers.length;
    setFiles((prev) => [...prev, parsedFileInfo]);
    setRawExtractedNumbers((prev) => [...prev, ...fileNumbers]);
    setIsProcessing(false);

    showToast(`Contoh ${sample.name} dimuat (${fileNumbers.length} nomor terdeteksi)!`);
  };

  // Remove single file
  const handleRemoveFile = (fileId: string) => {
    setFiles((prev) => prev.filter((f) => f.id !== fileId));
    setRawExtractedNumbers((prev) => prev.filter((n) => n.fileId !== fileId));
  };

  // Clear all files
  const handleClearAll = () => {
    if (window.confirm('Hapus semua file PDF dan nomor yang telah diekstrak?')) {
      setFiles([]);
      setRawExtractedNumbers([]);
    }
  };

  // Delete individual row
  const handleDeleteItem = (id: string) => {
    setRawExtractedNumbers((prev) => prev.filter((i) => i.id !== id));
  };

  // Delete selected rows
  const handleDeleteSelected = (ids: string[]) => {
    const idSet = new Set(ids);
    setRawExtractedNumbers((prev) => prev.filter((i) => !idSet.has(i.id)));
    showToast(`${ids.length} nomor terpilih telah dihapus.`);
  };

  // Toggle select row
  const handleToggleSelect = (id: string) => {
    setRawExtractedNumbers((prev) =>
      prev.map((i) => (i.id === id ? { ...i, selected: !i.selected } : i))
    );
  };

  // Select / Deselect all
  const handleSelectAll = (select: boolean) => {
    const visibleIds = new Set(filteredNumbers.map((i) => i.id));
    setRawExtractedNumbers((prev) =>
      prev.map((i) => (visibleIds.has(i.id) ? { ...i, selected: select } : i))
    );
  };

  // Save edited row
  const handleSaveEditedItem = (updated: ExtractedNumber) => {
    setRawExtractedNumbers((prev) =>
      prev.map((i) => (i.id === updated.id ? updated : i))
    );
    showToast('Data nomor berhasil diperbarui.');
  };

  // Add numbers from Gemini AI
  const handleAddAiExtractedNumbers = (newItems: ExtractedNumber[]) => {
    setRawExtractedNumbers((prev) => [...newItems, ...prev]);
    showToast(`${newItems.length} nomor dari analisis AI telah ditambahkan.`);
  };

  // Quick Copy WhatsApp list
  const handleQuickCopyWaList = (itemsToCopy: ExtractedNumber[]) => {
    const waNumbers = itemsToCopy
      .filter((i) => i.category === 'phone' || /^\d+$/.test(i.normalizedNumber))
      .map((i) => normalizePhoneNumber(i.rawNumber, 'e164_noplus'))
      .filter(Boolean);

    const dedup = Array.from(new Set(waNumbers));
    if (dedup.length === 0) {
      alert('Tidak ada nomor telepon yang tersedia untuk disalin.');
      return;
    }

    navigator.clipboard.writeText(dedup.join('\n'));
    showToast(`${dedup.length} nomor WhatsApp berhasil disalin ke clipboard!`);
  };

  // Merge Duplicates
  const handleMergeDuplicates = useCallback(() => {
    setRawExtractedNumbers((prev) => {
      const mergedMap = new Map<string, ExtractedNumber>();
      
      prev.forEach((item) => {
        // Use normalizedNumber and category as the unique key
        const key = `${item.category}_${item.normalizedNumber}`;
        if (mergedMap.has(key)) {
          const existing = mergedMap.get(key)!;
          
          // Combine contexts
          const existingContexts = existing.context.split('\n---\n');
          if (!existingContexts.includes(item.context)) {
             existing.context = `${existing.context}\n---\n${item.context}`;
          }
          
          // Combine fileNames if different
          const existingFiles = existing.fileName.split(', ');
          if (!existingFiles.includes(item.fileName)) {
             existing.fileName = `${existing.fileName}, ${item.fileName}`;
          }
          
          existing.occurrences = (existing.occurrences || 1) + (item.occurrences || 1);
        } else {
          mergedMap.set(key, { ...item, occurrences: item.occurrences || 1 });
        }
      });
      
      return Array.from(mergedMap.values());
    });
    
    showToast('Berhasil menggabungkan entri duplikat dan mengagregasi konteks!');
  }, []);

  // Batch Change Category
  const handleBatchChangeCategory = useCallback((newCategory: NumberCategory) => {
    setRawExtractedNumbers((prev) => {
      let changedCount = 0;
      const updated = prev.map((item) => {
        if (item.selected && item.category !== newCategory) {
          changedCount++;
          return { ...item, category: newCategory, selected: false };
        }
        return item;
      });
      if (changedCount > 0) {
        showToast(`Berhasil mengubah kategori untuk ${changedCount} item.`);
      }
      return updated;
    });
  }, []);

  const handleExtractPages = async () => {
    const selectedItems = rawExtractedNumbers.filter(i => i.selected);
    if (selectedItems.length === 0) return;
    
    setIsProcessing(true);
    const result = await extractPdfPagesFromNumbers(selectedItems, files);
    setIsProcessing(false);
    
    if (result.success) {
      showToast(result.message);
    } else {
      // Showing the error briefly or using an alert for longer messages
      alert(result.message);
    }
  };

  // Save custom rules & re-extract
  const handleSaveCustomRules = (updatedRules: CustomRegexRule[]) => {
    setCustomRules(updatedRules);
    reExtractAll(files, updatedRules);
  };

  // Data Health Check Analysis
  const healthReport: HealthCheckReport = useMemo(() => {
    return runDataHealthCheck(rawExtractedNumbers, healthRules);
  }, [rawExtractedNumbers, healthRules]);

  // Filtering & formatting pipeline
  const filteredNumbers = useMemo(() => {
    let result = rawExtractedNumbers.map((item) => {
      // Re-apply phone formatting dynamically based on filter choice
      let norm = item.normalizedNumber;
      if (item.category === 'phone') {
        norm = normalizePhoneNumber(item.rawNumber, filter.phoneFormat);
      }
      return {
        ...item,
        normalizedNumber: norm,
        healthIssues: healthReport.issuesByItem[item.id] || [],
      };
    });

    // 1. File filter
    if (filter.selectedFileId !== 'all') {
      result = result.filter((i) => i.fileId === filter.selectedFileId);
    }

    // 2. Category filter
    result = result.filter((i) => filter.categories.includes(i.category));

    // 3. Search filter
    if (filter.searchQuery.trim()) {
      const q = filter.searchQuery.toLowerCase().trim();
      result = result.filter(
        (i) =>
          i.normalizedNumber.toLowerCase().includes(q) ||
          i.rawNumber.toLowerCase().includes(q) ||
          i.label.toLowerCase().includes(q) ||
          (i.entityName && i.entityName.toLowerCase().includes(q)) ||
          i.context.toLowerCase().includes(q) ||
          i.fileName.toLowerCase().includes(q)
      );
    }

    // 4. Duplicate removal (Unique values only)
    if (filter.removeDuplicates) {
      const seen = new Set<string>();
      result = result.filter((item) => {
        const key = `${item.category}_${item.normalizedNumber}`;
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      });
    }

    // 5. Health Check issues only filter
    if (filter.onlyHealthIssues) {
      result = result.filter((item) => (item.healthIssues?.length ?? 0) > 0);
    }

    return result;
  }, [rawExtractedNumbers, filter, healthReport.issuesByItem]);

  // Global extraction statistics
  const stats: ExtractionStats = useMemo(() => {
    const totalFiles = files.length;
    const totalPages = files.reduce((acc, f) => acc + f.totalPages, 0);
    const totalNumbers = rawExtractedNumbers.length;
    const uniqueNumbers = new Set(rawExtractedNumbers.map((i) => i.normalizedNumber)).size;

    let phoneCount = 0;
    let invoiceCount = 0;
    let idCardCount = 0;
    let bankAccountCount = 0;
    let currencyCount = 0;
    let serialCount = 0;
    let otherCount = 0;

    rawExtractedNumbers.forEach((i) => {
      switch (i.category) {
        case 'phone': phoneCount++; break;
        case 'invoice': invoiceCount++; break;
        case 'id_card': idCardCount++; break;
        case 'bank_account': bankAccountCount++; break;
        case 'currency': currencyCount++; break;
        case 'serial_sku': serialCount++; break;
        default: otherCount++; break;
      }
    });

    return {
      totalNumbers,
      uniqueNumbers,
      phoneCount,
      invoiceCount,
      idCardCount,
      bankAccountCount,
      currencyCount,
      serialCount,
      otherCount,
      totalFiles,
      totalPages,
      healthScore: healthReport.healthScore,
      issueCount: healthReport.issues.length,
    };
  }, [files, rawExtractedNumbers, healthReport]);

  return (
    <div className="min-h-screen flex flex-col bg-[#F8FAFC] text-slate-900 font-sans relative overflow-x-hidden">
      
      {/* Dark Mode Background Elements (Hidden in Light Mode) */}
      <div className="hidden dark:block absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-cyan-500/10 blur-[120px] rounded-full mix-blend-screen pointer-events-none z-0"></div>
      <div className="hidden dark:block absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-600/10 blur-[120px] rounded-full mix-blend-screen pointer-events-none z-0"></div>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-2.5 rounded-xl shadow-lg flex items-center gap-2.5 text-xs font-medium animate-in slide-in-from-bottom-5 duration-200">
          <Check className="w-3.5 h-3.5 text-indigo-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      <div className="relative z-10 flex flex-col flex-1">
        {/* Header with Live Stats & Health Check (Admin Only) */}
        {user.role === 'admin' && (
          <Header
            stats={stats}
            healthReport={healthReport}
            user={user}
            currentView={currentView}
            dashboardMode={dashboardMode}
          onSwitchView={setCurrentView}
          onSwitchDashboardMode={setDashboardMode}
          autoSaveStatus={{
            lastSavedAt,
            isSaving: isAutoSaving,
          }}
          onManualSave={handleManualSave}
          onCloudSync={handleCloudSync}
          onClearSavedData={handleClearSavedData}
          onToggleUserStatus={handleToggleUserTier}
          onOpenUpgradeModal={() => setIsPaymentModalOpen(true)}
          onOpenLoginModal={() => setIsLoginModalOpen(true)}
          onOpenCustomRegex={() => setIsCustomRegexModalOpen(true)}
          onLoadSample={handleLoadSample}
          onOpenAiExtract={() => setIsAiExtractModalOpen(true)}
          onOpenHealthCheck={() => setIsHealthModalOpen(true)}
          onOpenMlCategorizer={() => setIsMlModalOpen(true)}
          hasFiles={files.length > 0}
        />
      )}

      {currentView === 'login' ? (
        <LoginPage
          onLoginSuccess={(loggedEmail) => {
            const isAdmin = loggedEmail.toLowerCase().includes('admin');
            setUser((prev) => ({ 
              ...prev, 
              email: loggedEmail, 
              name: loggedEmail.split('@')[0],
              role: isAdmin ? 'admin' : 'user'
            }));
            setCurrentView('dashboard');
            showToast(isAdmin ? `Selamat datang kembali, Admin ${loggedEmail}!` : `Selamat datang kembali, ${loggedEmail}!`);
          }}
          onContinueAsGuest={() => {
            setUser((prev) => ({ ...prev, role: 'user', email: 'guest@example.com' }));
            setCurrentView('dashboard');
            showToast('Melanjutkan ke Dashboard Ekstraksi sebagai Tamu.');
          }}
        />
      ) : (
        /* Main App Body */
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
          {dashboardMode === 'analytics' && user.role === 'admin' ? (
            <DashboardOverview items={filteredNumbers} files={files} />
          ) : (
            <>
              {/* PDF File Uploader Card */}
              <FileUploader
                files={files}
                isProcessing={isProcessing}
                onFilesSelected={handleFilesSelected}
                onRemoveFile={handleRemoveFile}
                onClearAll={handleClearAll}
                onLoadSample={handleLoadSample}
                onViewPdfText={(file) => {
                  setViewingPdfFile(file);
                  setViewingInitialPage(1);
                  setViewingHighlightText(undefined);
                  setViewingHighlightItem(null);
                }}
                onOpenBatchRename={() => setIsBatchRenameModalOpen(true)}
                onRenameSingleFile={handleRenameSingleFile}
              />

        {/* Feature Highlights Banner when no files are loaded */}
        {files.length === 0 && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 flex items-start gap-3.5">
              <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
                <Zap className="w-4 h-4" />
              </div>
              <div>
                <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                  Cepat & Otomatis
                </label>
                <h3 className="text-sm font-semibold text-slate-900 mt-0.5">Deteksi Multi-Format</h3>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  Mengenali otomatis nomor HP (+62 / 08xx), nomor Invoice / PO, NIK KTP, NPWP, nomor Rekening Bank, dan nominal harga.
                </p>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 flex items-start gap-3.5">
              <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
                <FileSpreadsheet className="w-4 h-4" />
              </div>
              <div>
                <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                  Excel & CSV
                </label>
                <h3 className="text-sm font-semibold text-slate-900 mt-0.5">Format Angka Terlindungi</h3>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  Hasil ekspor rapi tanpa terpotong (angka 0 di depan tetap utuh dan nomor panjang tidak berubah menjadi notasi ilmiah).
                </p>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 flex items-start gap-3.5">
              <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
                <Activity className="w-4 h-4" />
              </div>
              <div>
                <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                  Data Health Check
                </label>
                <h3 className="text-sm font-semibold text-slate-900 mt-0.5">Validasi & Deteksi Anomali</h3>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  Deteksi otomatis nomor HP terpotong, nominal minus, duplikasi nomor invoice, dan verifikasi digit standar NIK/NPWP.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Settings & Filter Controls (Visible when files exist) */}
        {files.length > 0 && (
          <PremiumAccessGate
            user={user}
            featureTitle="Akses Analitik Nomor, Auto-ML & Ekspor Spreadsheet"
            featureDescription="Nikmati efisiensi tanpa batas untuk validasi kesehatan data, klasifikasi Machine Learning NLP, integrasi WhatsApp, dan ekspor spreadsheet .xlsx instan."
            perks={[
              'Ekspor Excel (.xlsx) & CSV Tanpa Batas',
              'Machine Learning Auto-Categorizer Nomor',
              'Data Health Check Anomaly Validator',
              'Integrasi WhatsApp Generator Otomatis'
            ]}
            price="Rp 49.000"
            showTestingToggle={true}
            onToggleTestingTier={handleToggleUserTier}
            onPaymentSuccess={handleUpgradeSuccess}
          >
            <div className="space-y-6">
              <ExtractionSettings
                filter={filter}
                onChangeFilter={setFilter}
                files={files}
                totalRawCount={rawExtractedNumbers.length}
                filteredCount={filteredNumbers.length}
                healthIssueCount={healthReport.issues.length}
                onOpenHealthModal={() => setIsHealthModalOpen(true)}
              />

              {/* Extracted Numbers Data Table */}
              <NumberTable
                items={filteredNumbers}
                onDeleteItem={handleDeleteItem}
                onDeleteSelected={handleDeleteSelected}
                onToggleSelect={handleToggleSelect}
                onSelectAll={handleSelectAll}
                onEditItem={(item) => setEditingItem(item)}
                onMergeDuplicates={handleMergeDuplicates}
                onBatchChangeCategory={handleBatchChangeCategory}
                onViewContext={(item) => {
                  const targetFile = files.find((f) => f.id === item.fileId) || files[0];
                  setViewingPdfFile(targetFile);
                  setViewingInitialPage(item.pageNumber);
                  setViewingHighlightText(item.rawNumber);
                  setViewingHighlightItem(item);
                }}
                onOpenExportModal={() => setIsExportModalOpen(true)}
                onQuickCopyWaList={handleQuickCopyWaList}
                onOpenHealthModal={() => setIsHealthModalOpen(true)}
                healthIssueCount={healthReport.issues.length}
                onOpenMlModal={() => setIsMlModalOpen(true)}
                mlCandidateCount={mlStats.candidateCount}
                onOpenFindReplace={() => setIsFindReplaceModalOpen(true)}
                onExtractPages={handleExtractPages}
              />
            </div>
          </PremiumAccessGate>
        )}
        </>
      )}
      </main>
      )}

      {/* Modals */}
      <PaymentModal
        isOpen={isPaymentModalOpen}
        onClose={() => setIsPaymentModalOpen(false)}
        onPaymentSuccess={handleUpgradeSuccess}
        featureName="Akses Premium PDF Ekstraktor & Analitik"
        price="Rp 49.000"
      />
      <FindAndReplaceModal
        isOpen={isFindReplaceModalOpen}
        onClose={() => setIsFindReplaceModalOpen(false)}
        items={rawExtractedNumbers}
        onApplyReplace={handleApplyFindReplace}
      />

      <MlCategorizerModal
        isOpen={isMlModalOpen}
        onClose={() => setIsMlModalOpen(false)}
        items={rawExtractedNumbers}
        onApplyClassification={handleApplyMlClassification}
      />

      <DataHealthModal
        isOpen={isHealthModalOpen}
        onClose={() => setIsHealthModalOpen(false)}
        items={rawExtractedNumbers}
        report={healthReport}
        rules={healthRules}
        onUpdateRules={setHealthRules}
        onUpdateItems={setRawExtractedNumbers}
        onEditItem={(item) => setEditingItem(item)}
        onFilterTableToIssues={() => setFilter((prev) => ({ ...prev, onlyHealthIssues: true }))}
      />

      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        items={
          filteredNumbers.some((i) => i.selected)
            ? filteredNumbers.filter((i) => i.selected)
            : filteredNumbers
        }
        selectedCount={filteredNumbers.filter((i) => i.selected).length}
      />

      <CustomRegexModal
        isOpen={isCustomRegexModalOpen}
        onClose={() => setIsCustomRegexModalOpen(false)}
        rules={customRules}
        onSaveRules={handleSaveCustomRules}
      />

      <AiExtractionModal
        isOpen={isAiExtractModalOpen}
        onClose={() => setIsAiExtractModalOpen(false)}
        files={files}
        onAddAiExtractedNumbers={handleAddAiExtractedNumbers}
      />

      <PdfViewerModal
        file={viewingPdfFile}
        initialPage={viewingInitialPage}
        highlightText={viewingHighlightText}
        highlightItem={viewingHighlightItem}
        extractedNumbers={
          viewingPdfFile
            ? rawExtractedNumbers.filter((n) => n.fileId === viewingPdfFile.id)
            : []
        }
        onClose={() => {
          setViewingPdfFile(null);
          setViewingHighlightItem(null);
          setViewingHighlightText(undefined);
        }}
      />

      <EditNumberModal
        item={editingItem}
        isOpen={Boolean(editingItem)}
        onClose={() => setEditingItem(null)}
        onSave={handleSaveEditedItem}
      />

      <BatchRenameModal
        isOpen={isBatchRenameModalOpen}
        onClose={() => setIsBatchRenameModalOpen(false)}
        files={files}
        onApplyRename={handleBatchRename}
      />

      <LoginPageModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        onLoginSuccess={(loggedEmail) => {
          setUser((prev) => ({ ...prev, email: loggedEmail, name: loggedEmail.split('@')[0] }));
          showToast(`Berhasil masuk sebagai ${loggedEmail}`);
        }}
      />

      {/* Footer (Admin Only) */}
      {user.role === 'admin' && (
        <footer className="bg-white border-t border-slate-200 py-6 text-center text-xs text-slate-400 mt-12">
          <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
            <p className="font-medium text-slate-600">
              PDF Number Extractor to Excel (.xlsx) & CSV
            </p>
            <p className="text-slate-400">
              Presisi ekstraksi nomor dokumen PDF, validasi kesehatan data, dan ekspor spreadsheet terstruktur
            </p>
          </div>
        </footer>
      )}
      </div>
    </div>
  );
}
