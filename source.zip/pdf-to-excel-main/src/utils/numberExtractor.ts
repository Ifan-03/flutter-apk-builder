import { CustomRegexRule, ExtractedNumber, NumberCategory } from '../types';
import { classifyUnknownNumber } from './mlAutoCategorizer';

/**
 * Normalizes phone numbers into various standards.
 */
export function normalizePhoneNumber(
  raw: string,
  format: 'original' | 'e164_plus' | 'e164_noplus' | 'local_08' | 'clean_digits' = 'e164_noplus'
): string {
  if (format === 'original') return raw.trim();

  // Strip all non-digits except initial plus
  let clean = raw.replace(/[^\d+]/g, '');
  
  // Clean all non-digits
  let digitsOnly = raw.replace(/\D/g, '');

  // Handle Indonesian phone number format logic
  if (clean.startsWith('+62')) {
    digitsOnly = clean.substring(1); // 628...
  } else if (clean.startsWith('62') && clean.length >= 10) {
    // Already starts with 62
  } else if (clean.startsWith('08') || clean.startsWith('02') || clean.startsWith('03') || clean.startsWith('07') || clean.startsWith('09')) {
    // Indonesian local format 08xx -> convert to 628xx
    digitsOnly = '62' + clean.substring(1);
  }

  if (format === 'clean_digits') return digitsOnly;

  if (format === 'e164_plus') {
    return `+${digitsOnly}`;
  }

  if (format === 'e164_noplus') {
    return digitsOnly;
  }

  if (format === 'local_08') {
    if (digitsOnly.startsWith('628')) {
      return '0' + digitsOnly.substring(2);
    }
    return '0' + digitsOnly;
  }

  return raw.trim();
}

/**
 * Extracts context surrounding a matched number in text.
 */
function extractContext(fullText: string, matchIndex: number, matchLength: number): string {
  const start = Math.max(0, matchIndex - 35);
  const end = Math.min(fullText.length, matchIndex + matchLength + 35);
  let snippet = fullText.substring(start, end).replace(/\s+/g, ' ').trim();
  
  if (start > 0) snippet = '...' + snippet;
  if (end < fullText.length) snippet = snippet + '...';
  
  return snippet;
}

/**
 * Detects entity label near a number in the context.
 */
function detectEntityLabel(context: string, category: NumberCategory): { label: string; entityName?: string } {
  const lower = context.toLowerCase();

  // Check for bank indicators
  if (lower.includes('bca')) return { label: 'Rekening BCA', entityName: 'Bank BCA' };
  if (lower.includes('mandiri')) return { label: 'Rekening Mandiri', entityName: 'Bank Mandiri' };
  if (lower.includes('bri')) return { label: 'Rekening BRI', entityName: 'Bank BRI' };
  if (lower.includes('bni')) return { label: 'Rekening BNI', entityName: 'Bank BNI' };
  if (lower.includes('bsi')) return { label: 'Rekening BSI', entityName: 'Bank BSI' };
  if (lower.includes('cimb')) return { label: 'Rekening CIMB', entityName: 'CIMB Niaga' };
  if (lower.includes('permata')) return { label: 'Rekening Permata', entityName: 'Permata Bank' };
  if (lower.includes('jago')) return { label: 'Bank Jago', entityName: 'Bank Jago' };
  if (lower.includes('virtual account') || lower.includes(' va ')) return { label: 'Virtual Account' };

  // Check for specific labels
  if (lower.includes('whatsapp') || lower.includes(' wa ')) return { label: 'WhatsApp' };
  if (lower.includes('telepon') || lower.includes('telp') || lower.includes('phone') || lower.includes('hp')) return { label: 'No. Telepon / HP' };
  if (lower.includes('invoice') || lower.includes('faktur')) return { label: 'No. Invoice' };
  if (lower.includes('po ') || lower.includes('purchase order')) return { label: 'No. PO' };
  if (lower.includes('resi') || lower.includes('awb') || lower.includes('tracking')) return { label: 'No. Resi / Tracking' };
  if (lower.includes('surat jalan') || lower.includes('delivery order')) return { label: 'Surat Jalan' };
  if (lower.includes('nik') || lower.includes('ktp')) return { label: 'NIK / KTP' };
  if (lower.includes('npwp')) return { label: 'NPWP' };
  if (lower.includes('total') || lower.includes('subtotal') || lower.includes('jumlah')) return { label: 'Nominal Total' };

  // Default labels by category
  switch (category) {
    case 'phone': return { label: 'No. Telepon / HP' };
    case 'invoice': return { label: 'No. Dokumen / Invoice' };
    case 'id_card': return { label: 'Nomor Identitas' };
    case 'bank_account': return { label: 'No. Rekening Bank' };
    case 'currency': return { label: 'Nominal Uang' };
    case 'serial_sku': return { label: 'Serial / SKU' };
    default: return { label: 'Nomor' };
  }
}

/**
 * Main function that extracts all numbers and codes from page text.
 */
export function extractNumbersFromText(
  text: string,
  fileName: string,
  fileId: string,
  pageNumber: number,
  customRules: CustomRegexRule[] = []
): ExtractedNumber[] {
  const results: ExtractedNumber[] = [];
  const seenRawMatches = new Set<string>();

  const pushResult = (
    rawNumber: string,
    category: NumberCategory,
    matchIndex: number,
    confidence: number = 0.9,
    overrideLabel?: string,
    overrideNormalized?: string
  ) => {
    const trimmed = rawNumber.trim();
    if (!trimmed || trimmed.length < 3) return;
    
    // Key to prevent duplicate extraction on the same line/page
    const dedupKey = `${pageNumber}_${category}_${trimmed}_${matchIndex}`;
    if (seenRawMatches.has(dedupKey)) return;
    seenRawMatches.add(dedupKey);

    const context = extractContext(text, matchIndex, trimmed.length);
    let finalCategory = category;
    let finalLabel = overrideLabel;
    let finalEntityName = undefined;
    let isMlCategorized = false;
    let mlConfidence = undefined;
    let mlExplanation = undefined;

    // If category is 'other' or ambiguous, run ML Auto-Categorizer
    if (finalCategory === 'other' || finalCategory === 'custom') {
      const mlResult = classifyUnknownNumber(context, trimmed, finalCategory);
      if (mlResult.isClassified && mlResult.predictedCategory) {
        finalCategory = mlResult.predictedCategory;
        finalLabel = overrideLabel || mlResult.suggestedLabel;
        finalEntityName = mlResult.suggestedEntity;
        isMlCategorized = true;
        mlConfidence = mlResult.confidence;
        mlExplanation = mlResult.explanation;
        confidence = Math.max(confidence, mlResult.confidence);
      }
    }

    const { label: detectedLabel, entityName } = detectEntityLabel(context, finalCategory);
    if (!finalLabel) finalLabel = detectedLabel;
    if (!finalEntityName) finalEntityName = entityName;
    
    let normalized = overrideNormalized;
    if (!normalized) {
      if (finalCategory === 'phone') {
        normalized = normalizePhoneNumber(trimmed, 'e164_noplus');
      } else if (finalCategory === 'currency') {
        // Clean currency to numeric representation
        const digits = trimmed.replace(/[^\d.,]/g, '');
        normalized = digits;
      } else {
        normalized = trimmed.replace(/\s+/g, ' ');
      }
    }

    results.push({
      id: `num_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      rawNumber: trimmed,
      normalizedNumber: normalized,
      category: finalCategory,
      label: finalLabel,
      entityName: finalEntityName,
      fileName,
      fileId,
      pageNumber,
      context,
      confidence,
      isMlCategorized,
      mlConfidence,
      mlExplanation,
      selected: false,
    });
  };

  // 1. Phone Numbers (Indonesian & International)
  // Matches: 0812-3456-7890, +6281234567890, 6281234567890, (021) 1234567, +1-800-555-0199, etc.
  const phoneRegexes = [
    // Standard ID Mobile (+628... or 08... or 628...) with separators
    /(?:(?:\+62|62|0)8[1-9][0-9]{1,2}[-.\s]?[0-9]{3,4}[-.\s]?[0-9]{3,5})\b/g,
    // ID Landline (021, 022, 031, etc.)
    /(?:\(0[2-9][0-9]\)\s*|[0-9]{3,4}[-.\s])[0-9]{3,4}[-.\s]?[0-9]{3,4}\b/g,
    // International standard format with + prefix
    /(?:\+[1-9]{1,3}[-.\s]?(?:\([0-9]{1,4}\)[-.\s]?)?[0-9]{2,4}[-.\s]?[0-9]{3,4}[-.\s]?[0-9]{3,4})\b/g,
  ];

  for (const regex of phoneRegexes) {
    let match: RegExpExecArray | null;
    while ((match = regex.exec(text)) !== null) {
      const val = match[0].trim();
      const digitCount = val.replace(/\D/g, '').length;
      if (digitCount >= 8 && digitCount <= 16) {
        pushResult(val, 'phone', match.index, 0.95);
      }
    }
  }

  // 2. Invoice, PO, Surat Jalan, Resi, Faktur Codes
  // Matches: INV/2024/08/001, PO-98213-X, RESI-JP129381, Faktur: 010.002-24.12345678
  const docCodeRegexes = [
    /\b(?:INV|INVOICE|FAKTUR|KWT|BILL|KWITANSI)[/:-]?\s*([A-Za-z0-9/._-]{4,30})\b/gi,
    /\b(?:PO|PURCHASE[-_ ]?ORDER)[/:-]?\s*([A-Za-z0-9/._-]{4,25})\b/gi,
    /\b(?:SJ|SURAT[-_ ]?JALAN|DO|DELIVERY[-_ ]?ORDER)[/:-]?\s*([A-Za-z0-9/._-]{4,25})\b/gi,
    /\b(?:RESI|AWB|TRX|TXN|NO[-_ ]?ORDER|ORDER[-_ ]?ID|ORDER[-_ ]?NO)[/:-]?\s*([A-Za-z0-9/._-]{4,30})\b/gi,
    /\b(?:[0-9]{3}\.[0-9]{3}-[0-9]{2}\.[0-9]{8})\b/g, // Faktur Pajak format
    /\b(?:[A-Z]{2,4}[0-9]{6,16}[A-Z0-9]{0,4})\b/g, // Standard shipping tracking format (e.g., SPXID0291029381)
  ];

  for (const regex of docCodeRegexes) {
    let match: RegExpExecArray | null;
    while ((match = regex.exec(text)) !== null) {
      const fullMatch = match[0].trim();
      const codeOnly = match[1] ? match[1].trim() : fullMatch;
      
      // Ensure it has at least one digit and reasonable length
      if (/\d/.test(codeOnly) && codeOnly.length >= 4 && codeOnly.length <= 32) {
        pushResult(fullMatch, 'invoice', match.index, 0.92, undefined, codeOnly);
      }
    }
  }

  // 3. ID / NIK (16 digits) & NPWP (15/16 digits)
  // NIK: 16 digits continuous or formatted
  const nikRegex = /\b(?:NIK|KTP|NO\.?\s*KTP|NO\.?\s*IDENTITAS)?[:\s]*([1-9][0-9]{15})\b/gi;
  let nikMatch: RegExpExecArray | null;
  while ((nikMatch = nikRegex.exec(text)) !== null) {
    const val = nikMatch[1] || nikMatch[0];
    const digits = val.replace(/\D/g, '');
    if (digits.length === 16) {
      pushResult(digits, 'id_card', nikMatch.index, 0.95, 'NIK / No. KTP');
    }
  }

  // NPWP: 01.234.567.8-012.000 or 15/16 digits
  const npwpRegex = /\b(?:NPWP)?[:\s]*([0-9]{2}\.[0-9]{3}\.[0-9]{3}\.[0-9]{1}-[0-9]{3}\.[0-9]{3})\b/gi;
  let npwpMatch: RegExpExecArray | null;
  while ((npwpMatch = npwpRegex.exec(text)) !== null) {
    pushResult(npwpMatch[1] || npwpMatch[0], 'id_card', npwpMatch.index, 0.95, 'NPWP');
  }

  // 4. Bank Accounts & Virtual Accounts
  // Bank Account pattern near bank keywords or formatted:
  const bankAccountRegex = /\b(?:Rekening|No\.?\s*Rek|A\/C|ACC(?:OUNT)?|VA|Virtual\s*Account|BCA|Mandiri|BRI|BNI|BSI|Permata|CIMB)[:\s]+([0-9]{9,18}|[0-9]{3,4}-[0-9]{2,4}-[0-9]{4,6}-[0-9]{1,2})\b/gi;
  let bankMatch: RegExpExecArray | null;
  while ((bankMatch = bankAccountRegex.exec(text)) !== null) {
    const rawAcc = bankMatch[1].trim();
    const digits = rawAcc.replace(/\D/g, '');
    if (digits.length >= 9 && digits.length <= 18) {
      pushResult(bankMatch[0].trim(), 'bank_account', bankMatch.index, 0.9, undefined, digits);
    }
  }

  // 5. Currency & Financial Amounts
  // Rupiah (Rp 1.500.000, Rp. 250.000,00, IDR 1,500,000) or USD ($1,500.00)
  const currencyRegex = /\b(?:Rp\.?|IDR|\$|EUR|€)\s*([0-9]{1,3}(?:[.,][0-9]{3})*(?:[.,][0-9]{2})?)\b/gi;
  let currMatch: RegExpExecArray | null;
  while ((currMatch = currencyRegex.exec(text)) !== null) {
    const rawVal = currMatch[0].trim();
    pushResult(rawVal, 'currency', currMatch.index, 0.9);
  }

  // 6. Serial Numbers / SKU / Barcodes
  const serialRegex = /\b(?:S\/N|SN|SERIAL|SKU|BARCODE|IMEI|PART\s*NO)[:\s-]*([A-Z0-9-]{6,25})\b/gi;
  let snMatch: RegExpExecArray | null;
  while ((snMatch = serialRegex.exec(text)) !== null) {
    const rawSN = snMatch[1] || snMatch[0];
    if (/\d/.test(rawSN)) {
      pushResult(snMatch[0].trim(), 'serial_sku', snMatch.index, 0.88, undefined, rawSN.trim());
    }
  }

  // 7. General Long Numeric Strings (10-20 continuous digits that weren't caught yet)
  const genericNumberRegex = /\b([0-9]{8,20})\b/g;
  let genMatch: RegExpExecArray | null;
  while ((genMatch = genericNumberRegex.exec(text)) !== null) {
    const digits = genMatch[1];
    // Check if it looks like phone, NIK, or generic
    if (digits.startsWith('08') || digits.startsWith('628')) {
      if (digits.length >= 10 && digits.length <= 14) {
        pushResult(digits, 'phone', genMatch.index, 0.85);
      }
    } else if (digits.length === 16) {
      pushResult(digits, 'id_card', genMatch.index, 0.8, '16 Digit ID / NIK');
    } else if (digits.length >= 9 && digits.length <= 15) {
      pushResult(digits, 'other', genMatch.index, 0.75, 'Nomor / Kode Angka');
    }
  }

  // 8. Apply Custom User-Defined Regex Rules
  for (const rule of customRules) {
    if (!rule.enabled || !rule.pattern) continue;
    try {
      const customRegex = new RegExp(rule.pattern, rule.flags || 'g');
      let customMatch: RegExpExecArray | null;
      while ((customMatch = customRegex.exec(text)) !== null) {
        const val = customMatch[1] || customMatch[0];
        pushResult(val, rule.category || 'custom', customMatch.index, 0.99, rule.label || rule.name);
      }
    } catch (err) {
      console.warn(`Invalid custom regex "${rule.pattern}":`, err);
    }
  }

  return results;
}
