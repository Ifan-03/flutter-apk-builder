import { jsPDF } from 'jspdf';

/**
 * Generates sample PDF documents as ArrayBuffer for immediate interactive testing.
 */

export function generateSampleInvoicePdf(): { name: string; buffer: ArrayBuffer } {
  const doc = new jsPDF();
  
  // Set Document Properties / Metadata
  doc.setDocumentProperties({
    title: 'Faktur Penjualan & Invoice PT Maju Jaya Nusantara',
    subject: 'Faktur Penjualan Resmi No. INV/2025/08/9821-X',
    author: 'Divisi Keuangan PT Maju Jaya Nusantara (Dewi Finance)',
    keywords: 'invoice, faktur, bca, rekening, pengadaan, server',
    creator: 'Enterprise ERP Billing System v4.2',
  });
  
  // Header
  doc.setFontSize(20);
  doc.setTextColor(15, 23, 42); // Slate-900
  doc.text('PT MAJU JAYA NUSANTARA', 14, 22);
  
  doc.setFontSize(10);
  doc.setTextColor(100, 116, 139);
  doc.text('Jl. Sudirman Tower No. 45, Jakarta Selatan 12190', 14, 28);
  doc.text('Telepon: +62 21-555-8910 | WhatsApp CS: +62 812-9876-5432', 14, 34);
  doc.text('NPWP Perusahaan: 01.234.567.8-012.000', 14, 40);

  // Line divider
  doc.setDrawColor(226, 232, 240);
  doc.setLineWidth(0.5);
  doc.line(14, 44, 196, 44);

  // Invoice Details
  doc.setFontSize(14);
  doc.setTextColor(15, 23, 42);
  doc.text('FAKTUR PENJUALAN / INVOICE', 14, 54);

  doc.setFontSize(10);
  doc.setTextColor(51, 65, 85);
  doc.text('No. Invoice    : INV/2025/08/9821-X', 14, 62);
  doc.text('No. PO         : PO-2025-JKT-0419', 14, 68);
  doc.text('No. Surat Jalan: SJ-99120-VIII', 14, 74);
  doc.text('Tanggal        : 17 Agustus 2025', 14, 80);
  doc.text('Jatuh Tempo    : 31 Agustus 2025', 14, 86);

  // Customer Details
  doc.text('Ditagihkan Kepada:', 110, 62);
  doc.setFont(undefined, 'bold');
  doc.text('Bpk. Hendra Gunawan (PT Sinar Berkah)', 110, 68);
  doc.setFont(undefined, 'normal');
  doc.text('NIK: 3171012508890003', 110, 74);
  doc.text('No. HP / WA: 0813-8822-1945', 110, 80);
  doc.text('Email: hendra.gunawan@sinarberkah.co.id', 110, 86);

  // Items Table Header
  doc.setFillColor(241, 245, 249);
  doc.rect(14, 94, 182, 10, 'F');
  doc.setFont(undefined, 'bold');
  doc.text('No', 18, 100);
  doc.text('Deskripsi Barang / Layanan', 30, 100);
  doc.text('Kode SKU', 105, 100);
  doc.text('Qty', 135, 100);
  doc.text('Total (Rp)', 160, 100);

  // Items Rows
  doc.setFont(undefined, 'normal');
  const items = [
    { no: '1', desc: 'Server Rack 42U Enterprise', sku: 'SKU-SRV-42U', qty: '2 Unit', total: 'Rp 24.500.000' },
    { no: '2', desc: 'Cisco Gigabit Switch 24-Port', sku: 'SKU-CS-24P-G', qty: '4 Unit', total: 'Rp 18.200.000' },
    { no: '3', desc: 'Kabel Fiber Optic 100m Roll', sku: 'SKU-FIB-100M', qty: '5 Roll', total: 'Rp 4.750.000' },
    { no: '4', desc: 'Jasa Instalasi & Konfigurasi', sku: 'SRV-INST-01', qty: '1 Paket', total: 'Rp 6.000.000' },
  ];

  let y = 110;
  items.forEach((item) => {
    doc.text(item.no, 18, y);
    doc.text(item.desc, 30, y);
    doc.text(item.sku, 105, y);
    doc.text(item.qty, 135, y);
    doc.text(item.total, 160, y);
    y += 8;
  });

  // Totals
  doc.line(14, y + 2, 196, y + 2);
  y += 10;
  doc.setFont(undefined, 'bold');
  doc.text('Subtotal:', 125, y);
  doc.text('Rp 53.450.000', 160, y);
  y += 7;
  doc.text('PPN 11%:', 125, y);
  doc.text('Rp 5.879.500', 160, y);
  y += 8;
  doc.setFillColor(236, 253, 245); // Emerald-50
  doc.rect(120, y - 5, 76, 12, 'F');
  doc.setTextColor(4, 120, 87);
  doc.setFontSize(11);
  doc.text('TOTAL PEMBAYARAN:', 125, y + 3);
  doc.text('Rp 59.329.500', 160, y + 3);

  // Bank Payment Info
  doc.setTextColor(15, 23, 42);
  doc.setFontSize(10);
  doc.setFont(undefined, 'bold');
  doc.text('Informasi Pembayaran Rekening Bank Resmi:', 14, 175);
  
  doc.setFont(undefined, 'normal');
  doc.text('1. Bank BCA: 8830-1928-31 a/n PT Maju Jaya Nusantara', 14, 183);
  doc.text('2. Bank Mandiri: 137-00-9928192-3 a/n PT Maju Jaya Nusantara', 14, 190);
  doc.text('3. BCA Virtual Account: 80777081298765432 (Otomatis Verifikasi)', 14, 197);
  doc.text('Konfirmasi Transfer via WhatsApp Keuangan: 0857-1122-3344', 14, 204);

  // Page 2: Delivery & Warranty Details
  doc.addPage();
  doc.setFontSize(16);
  doc.text('LAMPIRAN SURAT JALAN & GARANSI', 14, 22);
  
  doc.setFontSize(10);
  doc.text('No. Resi Logistik JNE Cargo: JNECG-99218273612', 14, 32);
  doc.text('No. Polisi Armada: B 9421 KDA (Driver WA: 0878-7711-9922)', 14, 38);
  doc.text('No. Serial S/N Produk 1: SN-SRV-20250819-0199', 14, 46);
  doc.text('No. Serial S/N Produk 2: SN-SRV-20250819-0200', 14, 52);
  doc.text('Layanan Bantuan 24 Jam Hotline: 021-8991234 atau 0811-2345-6789', 14, 60);

  const pdfOutput = doc.output('arraybuffer');
  return {
    name: 'Sample_Invoice_PT_Maju_Jaya.pdf',
    buffer: pdfOutput,
  };
}

export function generateSampleContactDirectoryPdf(): { name: string; buffer: ArrayBuffer } {
  const doc = new jsPDF();
  
  // Set Document Properties / Metadata
  doc.setDocumentProperties({
    title: 'Direktori Kontak Pelanggan & Vendor Nasional',
    subject: 'Rekapitulasi Kontak Tim Marketing & Sales',
    author: 'Admin Operasional PT Maju Jaya (Budi Santoso)',
    keywords: 'kontak, whatsapp, vendor, direktori, sales, nlp',
    creator: 'Customer Directory Generator Pro',
  });
  
  doc.setFontSize(18);
  doc.text('DIREKTORI KONTAK PELANGGAN & VENDOR', 14, 20);
  doc.setFontSize(10);
  doc.setTextColor(100, 116, 139);
  doc.text('Rekapitulasi database kontak tim marketing & sales', 14, 26);
  doc.text('Tanggal cetak: 17 Agustus 2025', 14, 32);

  const contacts = [
    { name: 'Ahmad Fauzi', role: 'Distributor Jabodetabek', phone: '0812-3456-7890', nik: '3201011504880002', code: 'CUST-001' },
    { name: 'Siti Rahmawati', role: 'Owner Toko Berkah Jaya', phone: '0857-8910-1112', nik: '3174025409920005', code: 'CUST-002' },
    { name: 'Budi Santoso', role: 'Manager Pengadaan', phone: '+62 813-9988-7766', nik: '3374011203850001', code: 'CUST-003' },
    { name: 'Dewi Lestari', role: 'Koordinator Wilayah Jabar', phone: '0878-1234-5678', nik: '3273014506940004', code: 'CUST-004' },
    { name: 'Eko Prasetyo', role: 'Supplier Komponen Logam', phone: '0852-6789-0123', nik: '3578012307870008', code: 'CUST-005' },
    { name: 'Fitri Handayani', role: 'Agen Reseller Surabaya', phone: '+62 811-2233-4455', nik: '3578026101950002', code: 'CUST-006' },
    { name: 'Gunawan Wibowo', role: 'Kepala Gudang Logistik', phone: '0896-7890-1234', nik: '3171010908860009', code: 'CUST-007' },
    { name: 'Hani Kusuma', role: 'Finance PT Anugerah Abadi', phone: '0815-4321-8765', nik: '3204016712910003', code: 'CUST-008' },
    { name: 'Indra Pratama', role: 'Vendor IT Solution', phone: '+62 818-0912-3456', nik: '3175011905890007', code: 'CUST-009' },
    { name: 'Joko Widodo SE', role: 'Direktur CV Karya Bersama', phone: '0821-3456-9870', nik: '3311012806830006', code: 'CUST-010' },
    { name: 'Kartika Sari', role: 'Spesialis Pengadaan Alat', phone: '0856-1122-3399', nik: '3271015010930001', code: 'CUST-011' },
    { name: 'Lukman Hakim', role: 'Kepala Cabang Medan', phone: '0813-7001-9283', nik: '1271011402860004', code: 'CUST-012' },
  ];

  doc.setFillColor(241, 245, 249);
  doc.rect(14, 38, 182, 8, 'F');
  doc.setTextColor(15, 23, 42);
  doc.setFont(undefined, 'bold');
  doc.text('Nama Kontak', 16, 44);
  doc.text('Kode', 62, 44);
  doc.text('No. WhatsApp / HP', 88, 44);
  doc.text('NIK KTP', 135, 44);

  let y = 52;
  doc.setFont(undefined, 'normal');
  contacts.forEach((c) => {
    doc.text(c.name, 16, y);
    doc.text(c.code, 62, y);
    doc.text(c.phone, 88, y);
    doc.text(c.nik, 135, y);
    y += 9;
  });

  const pdfOutput = doc.output('arraybuffer');
  return {
    name: 'Sample_Direktori_Kontak_WhatsApp.pdf',
    buffer: pdfOutput,
  };
}
