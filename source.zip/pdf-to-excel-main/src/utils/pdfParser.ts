import * as pdfjsLib from 'pdfjs-dist';
import { PdfDocumentMetadata, PdfFileInfo, PdfPageContent } from '../types';

// Configure pdfjs worker safely
try {
  if (typeof window !== 'undefined') {
    // Set CDN worker matching installed version or fallback
    const workerVersion = pdfjsLib.version || '4.10.38';
    pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdn.jsdelivr.net/npm/pdfjs-dist@${workerVersion}/build/pdf.worker.min.mjs`;
  }
} catch (e) {
  console.warn('Failed to set pdfjs worker url:', e);
}

/**
 * Parses and formats PDF date string (e.g. "D:20250817143000+07'00'" or ISO string)
 */
export function parsePdfDate(pdfDateStr?: string): string | undefined {
  if (!pdfDateStr || typeof pdfDateStr !== 'string') return undefined;

  try {
    let cleanStr = pdfDateStr.trim();
    if (cleanStr.startsWith('D:')) {
      cleanStr = cleanStr.substring(2);
      const year = cleanStr.substring(0, 4);
      const month = cleanStr.substring(4, 6) || '01';
      const day = cleanStr.substring(6, 8) || '01';
      const hour = cleanStr.substring(8, 10) || '00';
      const min = cleanStr.substring(10, 12) || '00';
      const sec = cleanStr.substring(12, 14) || '00';

      const isoStr = `${year}-${month}-${day}T${hour}:${min}:${sec}`;
      const d = new Date(isoStr);
      if (!isNaN(d.getTime())) {
        return d.toLocaleDateString('id-ID', {
          year: 'numeric',
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        });
      }
    }

    const d = new Date(pdfDateStr);
    if (!isNaN(d.getTime())) {
      return d.toLocaleDateString('id-ID', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    }
  } catch {}

  return pdfDateStr;
}

/**
 * Formats byte size to human readable units
 */
export function formatFileSize(bytes: number): string {
  if (!bytes || bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

export const pdfMemoryCache = new Map<string, ArrayBuffer>();

/**
 * Extracts text from a PDF File or ArrayBuffer page by page along with document metadata.
 */
export async function extractTextFromPdf(
  file: File | ArrayBuffer,
  fileName: string,
  onProgress?: (current: number, total: number) => void
): Promise<PdfFileInfo> {
  const fileId = `file_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  const arrayBuffer = file instanceof File ? await file.arrayBuffer() : file;
  const fileSize = file instanceof File ? file.size : arrayBuffer.byteLength;

  pdfMemoryCache.set(fileId, arrayBuffer);

  try {
    const loadingTask = pdfjsLib.getDocument({
      data: arrayBuffer,
      cMapUrl: 'https://cdn.jsdelivr.net/npm/pdfjs-dist@4.10.38/cmaps/',
      cMapPacked: true,
    });

    const pdfDoc = await loadingTask.promise;
    const totalPages = pdfDoc.numPages;
    const pages: PdfPageContent[] = [];
    let fullText = '';

    // Extract Document Metadata
    let metadata: PdfDocumentMetadata | undefined = undefined;
    try {
      const metaObj = await pdfDoc.getMetadata();
      const info = (metaObj?.info as Record<string, any>) || {};

      metadata = {
        title: typeof info.Title === 'string' && info.Title.trim() ? info.Title.trim() : undefined,
        author: typeof info.Author === 'string' && info.Author.trim() ? info.Author.trim() : undefined,
        creator: typeof info.Creator === 'string' && info.Creator.trim() ? info.Creator.trim() : undefined,
        producer: typeof info.Producer === 'string' && info.Producer.trim() ? info.Producer.trim() : undefined,
        creationDate: parsePdfDate(info.CreationDate) || info.CreationDate || undefined,
        modificationDate: parsePdfDate(info.ModDate) || info.ModDate || undefined,
        subject: typeof info.Subject === 'string' && info.Subject.trim() ? info.Subject.trim() : undefined,
        keywords: typeof info.Keywords === 'string' && info.Keywords.trim() ? info.Keywords.trim() : undefined,
        pdfFormatVersion: typeof info.PDFFormatVersion === 'string' ? info.PDFFormatVersion : undefined,
        pageCount: totalPages,
        encrypted: Boolean(info.IsEncrypted),
        fileSizeFormatted: formatFileSize(fileSize),
        rawInfo: info,
      };
    } catch (mErr) {
      console.warn('Unable to get PDF metadata:', mErr);
    }

    for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
      if (onProgress) {
        onProgress(pageNum, totalPages);
      }

      const page = await pdfDoc.getPage(pageNum);
      const textContent = await page.getTextContent();
      
      // Group text items with smart spacing based on layout
      const items = textContent.items as Array<{ str?: string; hasEOL?: boolean; transform?: number[] }>;
      const lines: string[] = [];
      let currentLine = '';
      let lastY: number | null = null;

      for (const item of items) {
        if (!item.str) continue;
        
        // Approximate line break detection from Y coordinate transform
        const currentY = item.transform ? Math.round(item.transform[5]) : null;
        
        if (lastY !== null && currentY !== null && Math.abs(currentY - lastY) > 5) {
          if (currentLine.trim()) {
            lines.push(currentLine.trim());
          }
          currentLine = item.str;
        } else {
          currentLine += (currentLine ? ' ' : '') + item.str;
        }
        
        lastY = currentY;
      }

      if (currentLine.trim()) {
        lines.push(currentLine.trim());
      }

      const pageText = lines.join('\n');
      pages.push({
        pageNumber: pageNum,
        text: pageText,
        rawItems: items.map(i => i.str || '').filter(Boolean),
      });

      fullText += (fullText ? '\n\n' : '') + `--- Halaman ${pageNum} ---\n` + pageText;
    }

    return {
      id: fileId,
      name: fileName,
      size: fileSize,
      totalPages,
      extractedCount: 0,
      status: 'completed',
      pages,
      rawTextFull: fullText,
      metadata,
    };
  } catch (err: any) {
    console.error(`Error parsing PDF ${fileName}:`, err);
    return {
      id: fileId,
      name: fileName,
      size: fileSize,
      totalPages: 0,
      extractedCount: 0,
      status: 'error',
      error: err.message || 'Gagal memproses file PDF',
      pages: [],
      rawTextFull: '',
    };
  }
}
