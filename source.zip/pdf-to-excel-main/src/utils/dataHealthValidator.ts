import { DataHealthIssue, ExtractedNumber, HealthCheckReport, HealthRuleConfig, HealthSeverity, NumberCategory } from '../types';

export const DEFAULT_HEALTH_RULES: HealthRuleConfig[] = [
  {
    id: 'rule_phone_length',
    name: 'Nomor Telepon Tidak Lengkap / Terlalu Panjang',
    category: 'phone',
    severity: 'critical',
    description: 'Mendeteksi nomor telepon dengan digit < 9 digit (tidak lengkap) atau > 15 digit (melanggar standar E.164).',
    enabled: true,
    params: {
      minPhoneDigits: 9,
      maxPhoneDigits: 15,
    },
  },
  {
    id: 'rule_phone_prefix',
    name: 'Format / Awalan Telepon Mencurigakan',
    category: 'phone',
    severity: 'warning',
    description: 'Memeriksa apakah nomor telepon Indonesia memiliki awalan valid (08, 62, +62, atau kode area 02x/03x).',
    enabled: true,
  },
  {
    id: 'rule_currency_negative',
    name: 'Nominal Mata Uang Negatif atau Minus',
    category: 'currency',
    severity: 'critical',
    description: 'Mendeteksi nilai mata uang negatif (-Rp 50.000 atau kurung akuntansi) yang mungkin menandakan diskon/retur atau kesalahan parse.',
    enabled: true,
    params: {
      allowNegativeCurrency: false,
    },
  },
  {
    id: 'rule_currency_zero',
    name: 'Nominal Uang Bernilai Nol (Rp 0)',
    category: 'currency',
    severity: 'warning',
    description: 'Mendeteksi nominal uang bernilai 0 yang berpotensi merupakan faktur batal atau nilai kosong.',
    enabled: true,
  },
  {
    id: 'rule_invoice_duplicate',
    name: 'Duplikasi Nomor Invoice / PO / Resi',
    category: 'invoice',
    severity: 'warning',
    description: 'Mendeteksi nomor invoice atau dokumen transaksi yang identik muncul lebih dari satu kali.',
    enabled: true,
    params: {
      checkDuplicateInvoices: true,
    },
  },
  {
    id: 'rule_id_card_nik_length',
    name: 'Digit NIK KTP Tidak Tepat 16 Angka',
    category: 'id_card',
    severity: 'critical',
    description: 'Standar NIK KTP Indonesia wajib tepat 16 digit numerik. Flagging jika terpotong (14/15 digit) atau berlebih.',
    enabled: true,
    params: {
      requireExactNikDigits: 16,
    },
  },
  {
    id: 'rule_id_card_npwp_length',
    name: 'Digit NPWP Tidak Sesuai Standar (15 / 16 Angka)',
    category: 'id_card',
    severity: 'warning',
    description: 'Standar NPWP Indonesia adalah 15 digit (format lama) atau 16 digit (format NIK baru).',
    enabled: true,
    params: {
      requireNpwpDigits: [15, 16],
    },
  },
  {
    id: 'rule_bank_account_short',
    name: 'Nomor Rekening Bank Terlalu Pendek',
    category: 'bank_account',
    severity: 'warning',
    description: 'Nomor rekening bank di Indonesia umumnya memiliki panjang minimal 9-10 digit.',
    enabled: true,
    params: {
      minBankAccountDigits: 8,
    },
  },
  {
    id: 'rule_blank_or_invalid_symbols',
    name: 'Karakter Kosong atau Simbol Placeholder',
    category: 'all',
    severity: 'critical',
    description: 'Mendeteksi nilai hasil ekstraksi yang hanya berupa tanda hubung, titik, placeholder N/A, atau tidak memiliki angka/huruf valid.',
    enabled: true,
  },
];

/**
 * Runs the comprehensive Data Health Check across all extracted numbers.
 */
export function runDataHealthCheck(
  items: ExtractedNumber[],
  rules: HealthRuleConfig[] = DEFAULT_HEALTH_RULES
): HealthCheckReport {
  const issues: DataHealthIssue[] = [];
  const issuesByItem: Record<string, DataHealthIssue[]> = {};
  const activeRulesMap = new Map(rules.filter((r) => r.enabled).map((r) => [r.id, r]));

  // Track invoice numbers for duplicate detection
  const invoiceOccurrences = new Map<string, ExtractedNumber[]>();
  if (activeRulesMap.has('rule_invoice_duplicate')) {
    items.forEach((item) => {
      if (item.category === 'invoice') {
        const cleanInv = item.normalizedNumber.trim().toUpperCase();
        if (cleanInv && cleanInv.length > 2) {
          const list = invoiceOccurrences.get(cleanInv) || [];
          list.push(item);
          invoiceOccurrences.set(cleanInv, list);
        }
      }
    });
  }

  // Evaluate each item against active rules
  items.forEach((item) => {
    const itemIssues: DataHealthIssue[] = [];
    const raw = item.rawNumber.trim();
    const normalized = item.normalizedNumber.trim();
    const digitsOnly = raw.replace(/\D/g, '');

    // 1. Blank or placeholder symbols check
    if (activeRulesMap.has('rule_blank_or_invalid_symbols')) {
      const isPlaceholder = 
        !normalized || 
        /^[-_.\s/\\,;:?#*!]+$/.test(normalized) || 
        /^(n\/a|null|undefined|none|kosong|sample|dummy|test)$/i.test(normalized);

      if (isPlaceholder) {
        itemIssues.push({
          id: `issue_${item.id}_blank`,
          itemId: item.id,
          ruleId: 'rule_blank_or_invalid_symbols',
          ruleName: 'Karakter Kosong / Simbol Placeholder',
          severity: 'critical',
          title: 'Data Kosong atau Karakter Tidak Valid',
          description: `Nilai "${raw}" hanya berupa simbol atau placeholder kosong yang tidak bermakna.`,
          suggestedFix: 'Hapus baris data ini atau edit dengan nilai asli dari dokumen.',
          canAutoFix: false,
        });
      }
    }

    // 2. Phone category checks
    if (item.category === 'phone') {
      // 2a. Phone length check
      if (activeRulesMap.has('rule_phone_length')) {
        const minDigits = activeRulesMap.get('rule_phone_length')?.params?.minPhoneDigits ?? 9;
        const maxDigits = activeRulesMap.get('rule_phone_length')?.params?.maxPhoneDigits ?? 15;

        if (digitsOnly.length < minDigits) {
          itemIssues.push({
            id: `issue_${item.id}_phone_short`,
            itemId: item.id,
            ruleId: 'rule_phone_length',
            ruleName: 'Nomor Telepon Tidak Lengkap',
            severity: 'critical',
            title: 'Nomor Telepon Terlalu Pendek (Incomplete)',
            description: `Hanya terdeteksi ${digitsOnly.length} digit ("${raw}"). Standar nomor seluler Indonesia memerlukan minimal ${minDigits} digit.`,
            suggestedFix: 'Periksa kembali teks dokumen asli jika ada digit yang terpotong.',
            canAutoFix: false,
          });
        } else if (digitsOnly.length > maxDigits) {
          itemIssues.push({
            id: `issue_${item.id}_phone_long`,
            itemId: item.id,
            ruleId: 'rule_phone_length',
            ruleName: 'Nomor Telepon Terlalu Panjang',
            severity: 'warning',
            title: 'Panjang Nomor Melebihi Batas Standar',
            description: `Memiliki ${digitsOnly.length} digit (melebihi standar internasional maksimal ${maxDigits} digit). Kemungkinan merupakan gabungan dua nomor.`,
            suggestedFix: 'Pisahkan menjadi dua entri kontak terpisah.',
            canAutoFix: false,
          });
        }
      }

      // 2b. Phone prefix check
      if (activeRulesMap.has('rule_phone_prefix') && digitsOnly.length >= 9) {
        const hasValidIndonesianPrefix = 
          digitsOnly.startsWith('628') || 
          digitsOnly.startsWith('08') || 
          raw.startsWith('+62') ||
          /^(021|022|024|031|0274|061|0411|0711)/.test(digitsOnly);

        if (!hasValidIndonesianPrefix && !raw.startsWith('+')) {
          itemIssues.push({
            id: `issue_${item.id}_phone_prefix`,
            itemId: item.id,
            ruleId: 'rule_phone_prefix',
            ruleName: 'Awalan Nomor Telepon Tidak Standar',
            severity: 'warning',
            title: 'Awalan Nomor HP Tidak Standar',
            description: `Nomor "${raw}" tidak diawali dengan 08, +62, atau kode area umum.`,
            suggestedFix: 'Tambahkan kode negara +62 atau awalan 08 jika nomor ini adalah kontak lokal.',
            canAutoFix: digitsOnly.startsWith('8'),
            autoFixType: 'format_phone_prefix',
            autoFixValue: `62${digitsOnly}`,
          });
        }
      }
    }

    // 3. Currency category checks
    if (item.category === 'currency') {
      // 3a. Negative currency check
      if (activeRulesMap.has('rule_currency_negative')) {
        const isNegative = 
          raw.includes('-') || 
          /^\s*\(.+\)\s*$/.test(raw) || 
          raw.toLowerCase().includes('minus') ||
          raw.toLowerCase().includes('diskon') ||
          raw.toLowerCase().includes('potongan');

        if (isNegative) {
          const positiveVal = normalized.replace(/[-()]/g, '').trim();
          itemIssues.push({
            id: `issue_${item.id}_currency_neg`,
            itemId: item.id,
            ruleId: 'rule_currency_negative',
            ruleName: 'Nominal Negatif Terdeteksi',
            severity: 'critical',
            title: 'Nominal Uang Bernilai Negatif / Minus',
            description: `Nilai "${raw}" berformat minus atau dalam tanda kurung. Jika diekspor sebagai total pendapatan, hal ini dapat menyebabkan ketidaksesuaian pembukuan.`,
            suggestedFix: 'Konversikan ke nilai absolut positif jika ini adalah angka transaksi utama.',
            canAutoFix: true,
            autoFixType: 'strip_negative',
            autoFixValue: positiveVal,
          });
        }
      }

      // 3b. Zero currency check
      if (activeRulesMap.has('rule_currency_zero')) {
        const numOnly = digitsOnly;
        if (numOnly === '0' || numOnly === '00' || numOnly === '000' || /^0+([.,]0+)?$/.test(normalized)) {
          itemIssues.push({
            id: `issue_${item.id}_currency_zero`,
            itemId: item.id,
            ruleId: 'rule_currency_zero',
            ruleName: 'Nominal Bernilai Nol (Rp 0)',
            severity: 'warning',
            title: 'Nominal Berisi Nilai Nol (Rp 0)',
            description: `Nominal transaksi terdeteksi Rp 0 ("${raw}"). Pastikan ini bukan baris kosong atau faktur yang dibatalkan.`,
            suggestedFix: 'Periksa subtotal atau rincian item invoice pada dokumen asli.',
            canAutoFix: false,
          });
        }
      }
    }

    // 4. Duplicate Invoices check
    if (item.category === 'invoice' && activeRulesMap.has('rule_invoice_duplicate')) {
      const cleanInv = normalized.trim().toUpperCase();
      const duplicates = invoiceOccurrences.get(cleanInv) || [];
      if (duplicates.length > 1) {
        const isFirstInstance = duplicates[0].id === item.id;
        const otherFiles = Array.from(new Set(duplicates.map((d) => `${d.fileName} (Hal. ${d.pageNumber})`))).join(', ');

        itemIssues.push({
          id: `issue_${item.id}_inv_duplicate`,
          itemId: item.id,
          ruleId: 'rule_invoice_duplicate',
          ruleName: 'Duplikasi Nomor Invoice',
          severity: isFirstInstance ? 'info' : 'warning',
          title: isFirstInstance ? 'Nomor Invoice Muncul Berulang' : 'Duplikat Nomor Invoice / PO',
          description: `Nomor invoice "${normalized}" ditemukan ${duplicates.length} kali di dokumen: ${otherFiles}.`,
          suggestedFix: isFirstInstance 
            ? 'Ini adalah kemunculan pertama dari invoice berulang.' 
            : 'Hapus baris duplikat ini jika data hanya perlu dicatat satu kali.',
          canAutoFix: !isFirstInstance,
          autoFixType: 'remove_duplicate',
        });
      }
    }

    // 5. NIK & NPWP length validation
    if (item.category === 'id_card') {
      const isNik = item.label.toLowerCase().includes('nik') || item.label.toLowerCase().includes('ktp') || digitsOnly.length === 16;
      const isNpwp = item.label.toLowerCase().includes('npwp');

      if (isNik && activeRulesMap.has('rule_id_card_nik_length')) {
        const requiredNikLen = activeRulesMap.get('rule_id_card_nik_length')?.params?.requireExactNikDigits ?? 16;
        if (digitsOnly.length !== requiredNikLen && digitsOnly.length > 5) {
          itemIssues.push({
            id: `issue_${item.id}_nik_len`,
            itemId: item.id,
            ruleId: 'rule_id_card_nik_length',
            ruleName: 'Panjang NIK KTP Tidak Valid',
            severity: 'critical',
            title: `Digit NIK Tidak Tepat ${requiredNikLen} Angka`,
            description: `Terdeteksi ${digitsOnly.length} digit ("${raw}"). NIK KTP Indonesia resmi selalu memiliki tepat ${requiredNikLen} digit angka.`,
            suggestedFix: 'Periksa scan KTP asli, kemungkinan ada digit awal 0 atau digit akhir yang tidak terbaca.',
            canAutoFix: false,
          });
        }
      }

      if (isNpwp && activeRulesMap.has('rule_id_card_npwp_length')) {
        const allowedLengths = activeRulesMap.get('rule_id_card_npwp_length')?.params?.requireNpwpDigits ?? [15, 16];
        if (!allowedLengths.includes(digitsOnly.length) && digitsOnly.length > 5) {
          itemIssues.push({
            id: `issue_${item.id}_npwp_len`,
            itemId: item.id,
            ruleId: 'rule_id_card_npwp_length',
            ruleName: 'Digit NPWP Tidak Sesuai Standar',
            severity: 'warning',
            title: 'Digit NPWP Tidak Standar (Bukan 15 / 16 Digit)',
            description: `Terdeteksi ${digitsOnly.length} digit ("${raw}"). Format NPWP resmi adalah 15 digit (lama) atau 16 digit (NIK baru).`,
            suggestedFix: 'Lakukan verifikasi dengan kartu NPWP fisik atau DJP Online.',
            canAutoFix: false,
          });
        }
      }
    }

    // 6. Bank Account Length check
    if (item.category === 'bank_account' && activeRulesMap.has('rule_bank_account_short')) {
      const minBankLen = activeRulesMap.get('rule_bank_account_short')?.params?.minBankAccountDigits ?? 8;
      if (digitsOnly.length > 0 && digitsOnly.length < minBankLen) {
        itemIssues.push({
          id: `issue_${item.id}_bank_short`,
          itemId: item.id,
          ruleId: 'rule_bank_account_short',
          ruleName: 'Nomor Rekening Terlalu Pendek',
          severity: 'warning',
          title: 'Digit Rekening Bank Mencurigakan',
          description: `Hanya memiliki ${digitsOnly.length} digit ("${raw}"). Rekening bank BCA, Mandiri, BRI, BNI umumnya minimal 10-13 digit.`,
          suggestedFix: 'Periksa apakah ada digit 0 di depan yang terpotong saat diekstraksi.',
          canAutoFix: false,
        });
      }
    }

    // 7. Custom Rules Evaluation
    rules.filter((r) => r.isCustom && r.enabled).forEach((customRule) => {
      if (customRule.customRegex) {
        try {
          const re = new RegExp(customRule.customRegex, 'i');
          const matches = re.test(normalized) || re.test(raw);
          if (matches) {
            itemIssues.push({
              id: `issue_${item.id}_${customRule.id}`,
              itemId: item.id,
              ruleId: customRule.id,
              ruleName: customRule.name,
              severity: customRule.severity,
              title: `Aturan Kustom: ${customRule.name}`,
              description: customRule.description || `Data cocok dengan pola regex kustom: /${customRule.customRegex}/i`,
              suggestedFix: 'Periksa kecocokan data dengan aturan kustom Anda.',
              canAutoFix: false,
            });
          }
        } catch {
          // Ignore invalid regex
        }
      }
    });

    if (itemIssues.length > 0) {
      issues.push(...itemIssues);
      issuesByItem[item.id] = itemIssues;
    }
  });

  // Calculate statistics
  const totalRecords = items.length;
  const flaggedCount = Object.keys(issuesByItem).length;
  const healthyCount = Math.max(0, totalRecords - flaggedCount);

  let criticalCount = 0;
  let warningCount = 0;
  let infoCount = 0;

  issues.forEach((iss) => {
    if (iss.severity === 'critical') criticalCount++;
    else if (iss.severity === 'warning') warningCount++;
    else infoCount++;
  });

  // Health Score algorithm (0 - 100%)
  // Critical errors weigh 3x, warnings weigh 1.5x, info weighs 0.5x
  let healthScore = 100;
  if (totalRecords > 0) {
    const penalty = (criticalCount * 12 + warningCount * 5 + infoCount * 2) / totalRecords;
    healthScore = Math.max(0, Math.min(100, Math.round(100 - penalty * 10)));
  }

  // Category stats
  const categoryStats: Record<string, { total: number; issues: number }> = {};
  items.forEach((item) => {
    if (!categoryStats[item.category]) {
      categoryStats[item.category] = { total: 0, issues: 0 };
    }
    categoryStats[item.category].total++;
    if (issuesByItem[item.id]) {
      categoryStats[item.category].issues++;
    }
  });

  return {
    timestamp: Date.now(),
    totalRecords,
    healthyCount,
    flaggedCount,
    healthScore,
    criticalCount,
    warningCount,
    infoCount,
    issues,
    issuesByItem,
    categoryStats,
  };
}

/**
 * Applies an automatic fix to a single item based on its detected issue.
 */
export function applyAutoFixToItem(
  items: ExtractedNumber[],
  issue: DataHealthIssue
): { updatedItems: ExtractedNumber[]; success: boolean } {
  if (!issue.canAutoFix) return { updatedItems: items, success: false };

  if (issue.autoFixType === 'remove_duplicate') {
    const filtered = items.filter((i) => i.id !== issue.itemId);
    return { updatedItems: filtered, success: true };
  }

  if (issue.autoFixType === 'strip_negative' && issue.autoFixValue) {
    const updated = items.map((i) => {
      if (i.id === issue.itemId) {
        return {
          ...i,
          rawNumber: issue.autoFixValue || i.rawNumber.replace(/[-()]/g, '').trim(),
          normalizedNumber: issue.autoFixValue || i.normalizedNumber.replace(/[-()]/g, '').trim(),
        };
      }
      return i;
    });
    return { updatedItems: updated, success: true };
  }

  if (issue.autoFixType === 'format_phone_prefix' && issue.autoFixValue) {
    const updated = items.map((i) => {
      if (i.id === issue.itemId) {
        return {
          ...i,
          normalizedNumber: issue.autoFixValue || i.normalizedNumber,
        };
      }
      return i;
    });
    return { updatedItems: updated, success: true };
  }

  return { updatedItems: items, success: false };
}

/**
 * Batch applies all safe auto-fixes across all reported issues.
 */
export function applyBatchAutoFixes(
  items: ExtractedNumber[],
  issues: DataHealthIssue[]
): { updatedItems: ExtractedNumber[]; fixedCount: number } {
  const fixableIssues = issues.filter((iss) => iss.canAutoFix);
  if (fixableIssues.length === 0) return { updatedItems: items, fixedCount: 0 };

  const idsToRemove = new Set<string>();
  const updatesMap = new Map<string, { raw?: string; normalized?: string }>();

  fixableIssues.forEach((issue) => {
    if (issue.autoFixType === 'remove_duplicate') {
      idsToRemove.add(issue.itemId);
    } else if (issue.autoFixType === 'strip_negative' && issue.autoFixValue) {
      updatesMap.set(issue.itemId, {
        raw: issue.autoFixValue,
        normalized: issue.autoFixValue,
      });
    } else if (issue.autoFixType === 'format_phone_prefix' && issue.autoFixValue) {
      updatesMap.set(issue.itemId, {
        normalized: issue.autoFixValue,
      });
    }
  });

  let fixedCount = 0;
  const updatedItems = items
    .filter((item) => {
      if (idsToRemove.has(item.id)) {
        fixedCount++;
        return false;
      }
      return true;
    })
    .map((item) => {
      const update = updatesMap.get(item.id);
      if (update) {
        fixedCount++;
        return {
          ...item,
          rawNumber: update.raw !== undefined ? update.raw : item.rawNumber,
          normalizedNumber: update.normalized !== undefined ? update.normalized : item.normalizedNumber,
        };
      }
      return item;
    });

  return { updatedItems, fixedCount };
}
