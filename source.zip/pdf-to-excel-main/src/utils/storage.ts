import { CustomRegexRule, ExtractedNumber, PdfFileInfo } from '../types';

const STORAGE_KEYS = {
  FILES: 'pdf_extractor_saved_files_v1',
  NUMBERS: 'pdf_extractor_saved_numbers_v1',
  RULES: 'pdf_extractor_saved_rules_v1',
  META: 'pdf_extractor_autosave_meta_v1',
};

export interface AutoSavePayload {
  files: PdfFileInfo[];
  rawExtractedNumbers: ExtractedNumber[];
  customRules?: CustomRegexRule[];
}

export interface AutoSaveMeta {
  lastSavedAt: number;
  fileCount: number;
  numberCount: number;
  version: string;
}

export interface LoadStorageResult {
  files: PdfFileInfo[];
  rawExtractedNumbers: ExtractedNumber[];
  customRules: CustomRegexRule[];
  lastSavedAt: number | null;
}

/**
 * Safely saves the current extraction session to browser localStorage.
 * Includes fallback handling if localStorage quota is exceeded.
 */
export function saveAppStateToStorage(payload: AutoSavePayload): {
  success: boolean;
  timestamp: number;
  error?: string;
} {
  const timestamp = Date.now();
  if (typeof window === 'undefined' || !window.localStorage) {
    return { success: false, timestamp, error: 'LocalStorage tidak tersedia' };
  }

  try {
    // 1. Save extracted numbers
    localStorage.setItem(STORAGE_KEYS.NUMBERS, JSON.stringify(payload.rawExtractedNumbers));

    // 2. Save custom rules if present
    if (payload.customRules) {
      localStorage.setItem(STORAGE_KEYS.RULES, JSON.stringify(payload.customRules));
    }

    // 3. Save files
    // To prevent QuotaExceeded on very large PDFs, we optimize and trim redundant binary/deep caches if needed
    try {
      localStorage.setItem(STORAGE_KEYS.FILES, JSON.stringify(payload.files));
    } catch (quotaErr) {
      console.warn('LocalStorage quota limit reached, saving trimmed file structures:', quotaErr);
      // Fallback: strip heavy rawItems array while keeping essential text and metadata
      const trimmedFiles: PdfFileInfo[] = payload.files.map((f) => ({
        ...f,
        pages: f.pages.map((p) => ({
          pageNumber: p.pageNumber,
          text: p.text,
        })),
      }));
      localStorage.setItem(STORAGE_KEYS.FILES, JSON.stringify(trimmedFiles));
    }

    // 4. Update metadata
    const meta: AutoSaveMeta = {
      lastSavedAt: timestamp,
      fileCount: payload.files.length,
      numberCount: payload.rawExtractedNumbers.length,
      version: '1.0.0',
    };
    localStorage.setItem(STORAGE_KEYS.META, JSON.stringify(meta));

    return { success: true, timestamp };
  } catch (err: any) {
    console.error('Failed to auto-save app state to localStorage:', err);
    return {
      success: false,
      timestamp,
      error: err?.message || 'Gagal menyimpan ke penyimpanan lokal',
    };
  }
}

/**
 * Loads saved state from browser localStorage.
 */
export function loadAppStateFromStorage(): LoadStorageResult {
  const result: LoadStorageResult = {
    files: [],
    rawExtractedNumbers: [],
    customRules: [],
    lastSavedAt: null,
  };

  if (typeof window === 'undefined' || !window.localStorage) {
    return result;
  }

  try {
    // Load metadata
    const metaRaw = localStorage.getItem(STORAGE_KEYS.META);
    if (metaRaw) {
      try {
        const meta: AutoSaveMeta = JSON.parse(metaRaw);
        result.lastSavedAt = meta.lastSavedAt || null;
      } catch {}
    }

    // Load extracted numbers
    const numbersRaw = localStorage.getItem(STORAGE_KEYS.NUMBERS);
    if (numbersRaw) {
      const parsedNumbers = JSON.parse(numbersRaw);
      if (Array.isArray(parsedNumbers)) {
        result.rawExtractedNumbers = parsedNumbers;
      }
    }

    // Load files
    const filesRaw = localStorage.getItem(STORAGE_KEYS.FILES);
    if (filesRaw) {
      const parsedFiles = JSON.parse(filesRaw);
      if (Array.isArray(parsedFiles)) {
        result.files = parsedFiles;
      }
    }

    // Load custom rules
    const rulesRaw = localStorage.getItem(STORAGE_KEYS.RULES);
    if (rulesRaw) {
      const parsedRules = JSON.parse(rulesRaw);
      if (Array.isArray(parsedRules)) {
        result.customRules = parsedRules;
      }
    }
  } catch (err) {
    console.error('Failed to restore app state from localStorage:', err);
  }

  return result;
}

/**
 * Clears saved extraction data from localStorage.
 */
export function clearAppStateFromStorage(): boolean {
  if (typeof window === 'undefined' || !window.localStorage) return false;
  try {
    localStorage.removeItem(STORAGE_KEYS.FILES);
    localStorage.removeItem(STORAGE_KEYS.NUMBERS);
    localStorage.removeItem(STORAGE_KEYS.RULES);
    localStorage.removeItem(STORAGE_KEYS.META);
    return true;
  } catch (err) {
    console.error('Failed to clear app storage:', err);
    return false;
  }
}

/**
 * Formats a timestamp into human-readable time (e.g. "17:05:30")
 */
export function formatAutoSaveTime(timestamp: number | null): string {
  if (!timestamp) return 'Belum tersimpan';
  const d = new Date(timestamp);
  return d.toLocaleTimeString('id-ID', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
}
