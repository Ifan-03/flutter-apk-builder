import ExcelJS from 'exceljs';
import { ExtractedNumber } from '../types';

/**
 * Maps category keys to human readable Indonesian labels.
 */
export function getCategoryLabel(category: string): string {
  switch (category) {
    case 'phone': return 'Nomor Telepon / WhatsApp';
    case 'invoice': return 'No. Invoice / Dokumen';
    case 'id_card': return 'NIK / NPWP / Identitas';
    case 'bank_account': return 'No. Rekening / VA';
    case 'currency': return 'Nominal Keuangan';
    case 'serial_sku': return 'Serial / SKU / Barcode';
    case 'date_time': return 'Tanggal / Waktu';
    case 'custom': return 'Custom Regex';
    default: return 'Nomor Lainnya';
  }
}

/**
 * Category color badge classes for UI.
 */
export function getCategoryBadgeStyle(category: string): { bg: string; text: string; border: string; label: string } {
  switch (category) {
    case 'phone':
      return { bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-200', label: 'Telepon / WA' };
    case 'invoice':
      return { bg: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-200', label: 'Invoice / Dokumen' };
    case 'id_card':
      return { bg: 'bg-purple-50', text: 'text-purple-700', border: 'border-purple-200', label: 'NIK / NPWP' };
    case 'bank_account':
      return { bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200', label: 'Rekening Bank' };
    case 'currency':
      return { bg: 'bg-teal-50', text: 'text-teal-700', border: 'border-teal-200', label: 'Nominal' };
    case 'serial_sku':
      return { bg: 'bg-indigo-50', text: 'text-indigo-700', border: 'border-indigo-200', label: 'Serial / SKU' };
    case 'custom':
      return { bg: 'bg-rose-50', text: 'text-rose-700', border: 'border-rose-200', label: 'Custom Rule' };
    default:
      return { bg: 'bg-slate-100', text: 'text-slate-700', border: 'border-slate-300', label: 'Nomor Lain' };
  }
}

/**
 * Triggers a browser file download from Blob.
 */
export function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Generates and downloads a rich, styled Excel file (.xlsx) with multiple sheets.
 */
export async function exportToExcel(
  items: ExtractedNumber[],
  filename: string = 'Ekstraksi_Nomor_PDF.xlsx'
): Promise<void> {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'PDF Number Extractor';
  workbook.created = new Date();

  // 1. Data Sheet
  const worksheet = workbook.addWorksheet('Daftar Nomor', {
    views: [{ state: 'frozen', ySplit: 1 }],
  });

  worksheet.columns = [
    { header: 'No', key: 'index', width: 6 },
    { header: 'Nomor Asli (Original)', key: 'rawNumber', width: 22 },
    { header: 'Nomor Ternormalisasi / WA', key: 'normalizedNumber', width: 25 },
    { header: 'Kategori', key: 'categoryLabel', width: 22 },
    { header: 'Label / Keterangan', key: 'label', width: 22 },
    { header: 'Nama / Entitas', key: 'entityName', width: 22 },
    { header: 'Nama File PDF', key: 'fileName', width: 26 },
    { header: 'Halaman', key: 'pageNumber', width: 10 },
    { header: 'Konteks Teks', key: 'context', width: 45 },
    { header: 'Link WhatsApp', key: 'waLink', width: 30 },
  ];

  // Header Row Style
  const headerRow = worksheet.getRow(1);
  headerRow.height = 28;
  headerRow.eachCell((cell) => {
    cell.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FF0F172A' }, // Slate-900
    };
    cell.font = {
      name: 'Calibri',
      size: 11,
      bold: true,
      color: { argb: 'FFFFFFFF' },
    };
    cell.alignment = {
      vertical: 'middle',
      horizontal: 'center',
    };
    cell.border = {
      bottom: { style: 'medium', color: { argb: 'FF334155' } },
    };
  });

  // Populate data rows
  items.forEach((item, idx) => {
    const isPhone = item.category === 'phone';
    const waLink = isPhone && item.normalizedNumber
      ? `https://wa.me/${item.normalizedNumber.replace(/\D/g, '')}`
      : '-';

    const row = worksheet.addRow({
      index: idx + 1,
      rawNumber: item.rawNumber,
      normalizedNumber: item.normalizedNumber,
      categoryLabel: getCategoryLabel(item.category),
      label: item.label || '-',
      entityName: item.entityName || '-',
      fileName: item.fileName,
      pageNumber: item.pageNumber,
      context: item.context,
      waLink: waLink,
    });

    row.height = 22;

    // Formatting for text to prevent Excel from converting 0812... to 812... or NIK to scientific notation
    const rawCell = row.getCell('rawNumber');
    rawCell.numFmt = '@';
    rawCell.alignment = { vertical: 'middle', horizontal: 'left' };

    const normCell = row.getCell('normalizedNumber');
    normCell.numFmt = '@';
    normCell.alignment = { vertical: 'middle', horizontal: 'left' };

    const indexCell = row.getCell('index');
    indexCell.alignment = { vertical: 'middle', horizontal: 'center' };

    const pageCell = row.getCell('pageNumber');
    pageCell.alignment = { vertical: 'middle', horizontal: 'center' };

    const waCell = row.getCell('waLink');
    if (waLink !== '-') {
      waCell.value = {
        text: 'Chat via WhatsApp',
        hyperlink: waLink,
      };
      waCell.font = { color: { argb: 'FF0D9488' }, underline: true };
    }

    // Zebra striping for readability
    if (idx % 2 === 1) {
      row.eachCell({ includeEmpty: true }, (cell) => {
        if (!cell.fill) {
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFF8FAFC' },
          };
        }
      });
    }
  });

  // 2. Summary Sheet
  const summarySheet = workbook.addWorksheet('Ringkasan & Statistik');
  summarySheet.columns = [
    { header: 'Parameter', key: 'param', width: 30 },
    { header: 'Nilai', key: 'value', width: 25 },
  ];

  const sumHeader = summarySheet.getRow(1);
  sumHeader.height = 26;
  sumHeader.eachCell((cell) => {
    cell.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FF047857' }, // Emerald-700
    };
    cell.font = { name: 'Calibri', size: 11, bold: true, color: { argb: 'FFFFFFFF' } };
    cell.alignment = { vertical: 'middle' };
  });

  const uniqueNumbers = new Set(items.map((i) => i.normalizedNumber)).size;
  const categoriesCount: Record<string, number> = {};
  items.forEach((i) => {
    categoriesCount[i.category] = (categoriesCount[i.category] || 0) + 1;
  });

  summarySheet.addRow({ param: 'Total Nomor Ditemukan', value: items.length });
  summarySheet.addRow({ param: 'Total Nomor Unik (Dedup)', value: uniqueNumbers });
  summarySheet.addRow({ param: 'Waktu Ekstraksi', value: new Date().toLocaleString('id-ID') });
  summarySheet.addRow({ param: '', value: '' });
  summarySheet.addRow({ param: '--- BREAKDOWN KATEGORI ---', value: '' });

  Object.entries(categoriesCount).forEach(([cat, count]) => {
    summarySheet.addRow({
      param: getCategoryLabel(cat),
      value: `${count} item (${((count / (items.length || 1)) * 100).toFixed(1)}%)`,
    });
  });

  // Export buffer
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  triggerDownload(blob, filename.endsWith('.xlsx') ? filename : `${filename}.xlsx`);
}

export type CsvDelimiter = ',' | ';' | '\t' | '|' | string;
export type CsvEncoding = 'utf-8-bom' | 'utf-8' | 'windows-1252' | 'ascii';
export type CsvNumberStyle = 'excel_formula' | 'quoted_text';

export interface CsvExportOptions {
  filename?: string;
  delimiter?: CsvDelimiter;
  encoding?: CsvEncoding;
  numberStyle?: CsvNumberStyle;
  includeHeaders?: boolean;
}

/**
 * Generates formatted CSV string based on configurable delimiter, number styling, and headers.
 */
export function generateCsvString(
  items: ExtractedNumber[],
  options: CsvExportOptions = {}
): string {
  const {
    delimiter = ';',
    numberStyle = 'excel_formula',
    includeHeaders = true,
  } = options;

  const headers = [
    'No',
    'Nomor Asli',
    'Nomor Ternormalisasi',
    'Kategori',
    'Label',
    'Nama/Entitas',
    'File PDF',
    'Halaman',
    'Konteks',
  ];

  const escapeCell = (val: any): string => {
    if (val === undefined || val === null) return '""';
    const str = String(val).replace(/"/g, '""');
    return `"${str}"`;
  };

  const rows = items.map((item, idx) => {
    const rawVal = numberStyle === 'excel_formula'
      ? `="${item.rawNumber}"`
      : item.rawNumber;

    const normVal = numberStyle === 'excel_formula'
      ? `="${item.normalizedNumber}"`
      : item.normalizedNumber;

    return [
      idx + 1,
      rawVal,
      normVal,
      getCategoryLabel(item.category),
      item.label || '',
      item.entityName || '',
      item.fileName,
      item.pageNumber,
      item.context.replace(/[\r\n]+/g, ' '),
    ];
  });

  const lines: string[] = [];
  if (includeHeaders) {
    lines.push(headers.map(escapeCell).join(delimiter));
  }

  rows.forEach((r) => {
    lines.push(r.map(escapeCell).join(delimiter));
  });

  return lines.join('\r\n');
}

/**
 * Exports to CSV with configurable delimiter and character encoding options.
 */
export function exportToCsv(
  items: ExtractedNumber[],
  filename: string = 'Ekstraksi_Nomor_PDF.csv',
  optionsOrDelimiter: CsvExportOptions | (',' | ';') = ';'
): void {
  const options: CsvExportOptions = 
    typeof optionsOrDelimiter === 'string'
      ? { delimiter: optionsOrDelimiter, encoding: 'utf-8-bom', numberStyle: 'excel_formula' }
      : {
          delimiter: optionsOrDelimiter.delimiter ?? ';',
          encoding: optionsOrDelimiter.encoding ?? 'utf-8-bom',
          numberStyle: optionsOrDelimiter.numberStyle ?? 'excel_formula',
          includeHeaders: optionsOrDelimiter.includeHeaders ?? true,
        };

  let csvText = generateCsvString(items, options);
  let blob: Blob;

  if (options.encoding === 'ascii') {
    // Replace non-ascii chars
    const asciiText = csvText.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\x00-\x7F]/g, '?');
    blob = new Blob([asciiText], { type: 'text/csv;charset=us-ascii;' });
  } else if (options.encoding === 'windows-1252') {
    // Encode as Windows-1252 / ISO-8859-1 byte array
    const bytes = new Uint8Array(csvText.length);
    for (let i = 0; i < csvText.length; i++) {
      const code = csvText.charCodeAt(i);
      bytes[i] = code < 256 ? code : 63; // 63 is '?'
    }
    blob = new Blob([bytes], { type: 'text/csv;charset=windows-1252;' });
  } else if (options.encoding === 'utf-8') {
    // Plain UTF-8 without BOM
    blob = new Blob([csvText], { type: 'text/csv;charset=utf-8;' });
  } else {
    // Default: UTF-8 with BOM (Best for Excel localized compatibility)
    const withBom = '\uFEFF' + csvText;
    blob = new Blob([withBom], { type: 'text/csv;charset=utf-8;' });
  }

  const finalFilename = filename.endsWith('.csv') || filename.endsWith('.tsv') || filename.endsWith('.txt')
    ? filename
    : `${filename}.csv`;

  triggerDownload(blob, finalFilename);
}

/**
 * Exports phone numbers to a .vcf (vCard 3.0) file for importing into Google Contacts / smartphones.
 */
export function exportToVcf(items: ExtractedNumber[], filename: string = 'Kontak_Ekstraksi.vcf'): void {
  const phoneItems = items.filter((i) => i.category === 'phone');
  if (phoneItems.length === 0) {
    alert('Tidak ada nomor telepon yang dipilih untuk diekspor ke VCF.');
    return;
  }

  let vcfContent = '';
  phoneItems.forEach((item, idx) => {
    const contactName = item.entityName || item.label || `Kontak PDF ${idx + 1}`;
    const cleanPhone = item.normalizedNumber.startsWith('+')
      ? item.normalizedNumber
      : `+${item.normalizedNumber.replace(/\D/g, '')}`;

    vcfContent += `BEGIN:VCARD\r\n`;
    vcfContent += `VERSION:3.0\r\n`;
    vcfContent += `FN:${contactName}\r\n`;
    vcfContent += `TEL;TYPE=CELL:${cleanPhone}\r\n`;
    vcfContent += `NOTE:Diekstrak dari ${item.fileName} Halaman ${item.pageNumber}\r\n`;
    vcfContent += `END:VCARD\r\n`;
  });

  const blob = new Blob([vcfContent], { type: 'text/vcard;charset=utf-8;' });
  triggerDownload(blob, filename.endsWith('.vcf') ? filename : `${filename}.vcf`);
}

/**
 * Returns newline-separated clean list (e.g. for WhatsApp Broadcast / CRM).
 */
export function getCleanNumberList(items: ExtractedNumber[]): string {
  return items
    .map((i) => i.normalizedNumber)
    .filter(Boolean)
    .join('\n');
}

export function exportCleanPhoneNumbersToTxt(
  items: ExtractedNumber[],
  filename: string = 'Nomor_Telepon_Terpilih.txt'
): void {
  const phoneItems = items.filter((i) => i.category === 'phone');
  if (phoneItems.length === 0) {
    alert('Tidak ada nomor telepon yang dapat diekspor.');
    return;
  }
  const content = phoneItems.map((i) => i.normalizedNumber || i.rawNumber).join('\r\n');
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8;' });
  triggerDownload(blob, filename);
}

/**
 * Exports to Plain Text file (.txt) with configurable formats:
 * - 'numbers_only': Just normalized numbers per line
 * - 'detailed': Structured lines with labels and context
 * - 'comma_inline': Comma separated on a single line
 */
export function exportToTxt(
  items: ExtractedNumber[],
  filename: string = 'Ekstraksi_Nomor_PDF.txt',
  style: 'numbers_only' | 'detailed' | 'comma_inline' = 'detailed'
): void {
  let content = '';

  if (style === 'numbers_only') {
    content = items.map((i) => i.normalizedNumber || i.rawNumber).join('\r\n');
  } else if (style === 'comma_inline') {
    content = items.map((i) => i.normalizedNumber || i.rawNumber).join(', ');
  } else {
    content = `=== HASIL EKSTRAKSI NOMOR DOKUMEN PDF ===\r\n`;
    content += `Tanggal: ${new Date().toLocaleString('id-ID')}\r\n`;
    content += `Total Nomor: ${items.length}\r\n`;
    content += `------------------------------------------------------------\r\n\r\n`;

    items.forEach((item, idx) => {
      content += `[#${idx + 1}] ${item.normalizedNumber || item.rawNumber}\r\n`;
      content += `  Kategori  : ${getCategoryLabel(item.category)}\r\n`;
      if (item.label) content += `  Label     : ${item.label}\r\n`;
      if (item.entityName) content += `  Entitas   : ${item.entityName}\r\n`;
      content += `  File/Hal  : ${item.fileName} (Hal. ${item.pageNumber})\r\n`;
      content += `  Konteks   : "${item.context.replace(/[\r\n]+/g, ' ').trim()}"\r\n`;
      content += `\r\n`;
    });
  }

  const blob = new Blob([content], { type: 'text/plain;charset=utf-8;' });
  triggerDownload(blob, filename.endsWith('.txt') ? filename : `${filename}.txt`);
}

/**
 * Exports to Markdown Table file (.md)
 */
export function generateMarkdownString(items: ExtractedNumber[]): string {
  let md = `# Hasil Ekstraksi Nomor PDF\n\n`;
  md += `_Diekstrak pada: ${new Date().toLocaleString('id-ID')} | Total: ${items.length} nomor_\n\n`;
  md += `| No | Nomor Asli | Nomor Ternormalisasi | Kategori | Label / Entitas | Sumber File | Hal. |\n`;
  md += `|:---|:---|:---|:---|:---|:---|:---|\n`;

  items.forEach((item, idx) => {
    const labelEnt = [item.label, item.entityName].filter(Boolean).join(' - ') || '-';
    const cleanRaw = item.rawNumber.replace(/\|/g, '\\|');
    const cleanNorm = item.normalizedNumber.replace(/\|/g, '\\|');
    const cleanFile = item.fileName.replace(/\|/g, '\\|');
    md += `| ${idx + 1} | \`${cleanRaw}\` | **\`${cleanNorm}\`** | ${getCategoryLabel(item.category)} | ${labelEnt} | ${cleanFile} | ${item.pageNumber} |\n`;
  });

  return md;
}

export function exportToMarkdown(
  items: ExtractedNumber[],
  filename: string = 'Ekstraksi_Nomor_PDF.md'
): void {
  const content = generateMarkdownString(items);
  const blob = new Blob([content], { type: 'text/markdown;charset=utf-8;' });
  triggerDownload(blob, filename.endsWith('.md') ? filename : `${filename}.md`);
}

/**
 * Exports to Standalone Styled HTML Table file (.html)
 */
export function generateHtmlString(items: ExtractedNumber[], title: string = 'Ekstraksi Nomor PDF'): string {
  const rowsHtml = items.map((item, idx) => `
    <tr>
      <td class="center text-muted">${idx + 1}</td>
      <td><code>${escapeHtml(item.rawNumber)}</code></td>
      <td><strong><code>${escapeHtml(item.normalizedNumber)}</code></strong></td>
      <td><span class="badge badge-${item.category}">${getCategoryLabel(item.category)}</span></td>
      <td>${escapeHtml([item.label, item.entityName].filter(Boolean).join(' - ') || '-')}</td>
      <td class="truncate" title="${escapeHtml(item.fileName)}">${escapeHtml(item.fileName)}</td>
      <td class="center">${item.pageNumber}</td>
      <td class="context">${escapeHtml(item.context.replace(/[\r\n]+/g, ' '))}</td>
    </tr>
  `).join('');

  return `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapeHtml(title)}</title>
  <style>
    :root {
      --primary: #4f46e5;
      --bg: #f8fafc;
      --card: #ffffff;
      --text: #0f172a;
      --muted: #64748b;
      --border: #e2e8f0;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      background: var(--bg);
      color: var(--text);
      padding: 32px 16px;
      margin: 0;
    }
    .container {
      max-width: 1200px;
      margin: 0 auto;
      background: var(--card);
      border-radius: 12px;
      border: 1px solid var(--border);
      box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.05);
      overflow: hidden;
    }
    .header {
      padding: 24px 32px;
      border-bottom: 1px solid var(--border);
      background: #ffffff;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 16px;
    }
    h1 { margin: 0; font-size: 20px; font-weight: 700; color: #1e1b4b; }
    .meta { font-size: 12px; color: var(--muted); margin-top: 4px; }
    .btn-print {
      background: var(--primary);
      color: white;
      border: none;
      padding: 8px 16px;
      border-radius: 6px;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
    }
    .table-wrap { overflow-x: auto; }
    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 12px;
      text-align: left;
    }
    th {
      background: #f1f5f9;
      color: #475569;
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      padding: 12px 16px;
      border-bottom: 1px solid var(--border);
      white-space: nowrap;
    }
    td {
      padding: 10px 16px;
      border-bottom: 1px solid var(--border);
      vertical-align: middle;
    }
    tr:hover { background: #f8fafc; }
    .center { text-align: center; }
    .text-muted { color: var(--muted); }
    code { font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; font-size: 11.5px; }
    .badge {
      display: inline-block;
      padding: 2px 8px;
      border-radius: 9999px;
      font-size: 10px;
      font-weight: 600;
      background: #e0e7ff;
      color: #3730a3;
    }
    .badge-phone { background: #dcfce7; color: #166534; }
    .badge-invoice { background: #e0e7ff; color: #3730a3; }
    .badge-id_card { background: #fef3c7; color: #92400e; }
    .badge-bank_account { background: #f3e8ff; color: #6b21a8; }
    .badge-currency { background: #ccfbf1; color: #115e59; }
    .context { font-size: 11px; color: var(--muted); max-width: 300px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    @media print {
      body { background: white; padding: 0; }
      .container { border: none; box-shadow: none; }
      .btn-print { display: none; }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div>
        <h1>${escapeHtml(title)}</h1>
        <div class="meta">Waktu Ekstraksi: ${new Date().toLocaleString('id-ID')} • Total: ${items.length} Data</div>
      </div>
      <button class="btn-print" onclick="window.print()">Cetak / Simpan PDF</button>
    </div>
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th class="center" style="width: 40px;">#</th>
            <th>Nomor Asli</th>
            <th>Nomor Normalisasi</th>
            <th>Kategori</th>
            <th>Label / Entitas</th>
            <th>Nama File</th>
            <th class="center">Hal</th>
            <th>Konteks Dokumen</th>
          </tr>
        </thead>
        <tbody>
          ${rowsHtml}
        </tbody>
      </table>
    </div>
  </div>
</body>
</html>`;
}

function escapeHtml(str: string): string {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

export function exportToHtml(
  items: ExtractedNumber[],
  filename: string = 'Ekstraksi_Nomor_PDF.html',
  title: string = 'Ekstraksi Nomor PDF'
): void {
  const content = generateHtmlString(items, title);
  const blob = new Blob([content], { type: 'text/html;charset=utf-8;' });
  triggerDownload(blob, filename.endsWith('.html') ? filename : `${filename}.html`);
}

/**
 * Exports to SQL script (.sql) with CREATE TABLE and INSERT statements
 */
export function generateSqlString(
  items: ExtractedNumber[],
  dialect: 'postgres' | 'mysql' | 'sqlite' = 'postgres',
  tableName: string = 'extracted_pdf_numbers'
): string {
  const safeTable = tableName.replace(/[^a-zA-Z0-9_]/g, '_');
  
  const escapeSql = (val: any): string => {
    if (val === null || val === undefined) return 'NULL';
    const str = String(val).replace(/'/g, "''");
    return `'${str}'`;
  };

  let sql = `-- ==========================================================\n`;
  sql += `-- SQL Dump: Hasil Ekstraksi Nomor PDF\n`;
  sql += `-- Dialek: ${dialect.toUpperCase()} | Tanggal: ${new Date().toISOString()}\n`;
  sql += `-- Total Record: ${items.length}\n`;
  sql += `-- ==========================================================\n\n`;

  sql += `CREATE TABLE IF NOT EXISTS ${safeTable} (\n`;
  sql += `  id SERIAL PRIMARY KEY,\n`;
  sql += `  raw_number VARCHAR(255) NOT NULL,\n`;
  sql += `  normalized_number VARCHAR(255) NOT NULL,\n`;
  sql += `  category VARCHAR(50) NOT NULL,\n`;
  sql += `  label VARCHAR(255),\n`;
  sql += `  entity_name VARCHAR(255),\n`;
  sql += `  file_name VARCHAR(255) NOT NULL,\n`;
  sql += `  page_number INT NOT NULL,\n`;
  sql += `  context TEXT,\n`;
  sql += `  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n`;
  sql += `);\n\n`;

  if (items.length === 0) return sql;

  sql += `INSERT INTO ${safeTable} (\n`;
  sql += `  raw_number, normalized_number, category, label, entity_name, file_name, page_number, context\n`;
  sql += `) VALUES\n`;

  const valuesArr = items.map((item) => {
    return `  (${escapeSql(item.rawNumber)}, ${escapeSql(item.normalizedNumber)}, ${escapeSql(item.category)}, ${escapeSql(item.label)}, ${escapeSql(item.entityName)}, ${escapeSql(item.fileName)}, ${item.pageNumber || 1}, ${escapeSql(item.context)})`;
  });

  sql += valuesArr.join(',\n') + ';\n';
  return sql;
}

export function exportToSql(
  items: ExtractedNumber[],
  filename: string = 'Ekstraksi_Nomor_PDF.sql',
  dialect: 'postgres' | 'mysql' | 'sqlite' = 'postgres',
  tableName: string = 'extracted_pdf_numbers'
): void {
  const content = generateSqlString(items, dialect, tableName);
  const blob = new Blob([content], { type: 'application/sql;charset=utf-8;' });
  triggerDownload(blob, filename.endsWith('.sql') ? filename : `${filename}.sql`);
}

/**
 * Exports to XML Dataset (.xml)
 */
export function generateXmlString(items: ExtractedNumber[]): string {
  let xml = `<?xml version="1.0" encoding="UTF-8"?>\n`;
  xml += `<PdfNumberExtraction generatedAt="${new Date().toISOString()}" totalItems="${items.length}">\n`;

  items.forEach((item, idx) => {
    xml += `  <Record id="${idx + 1}">\n`;
    xml += `    <RawNumber><![CDATA[${item.rawNumber}]]></RawNumber>\n`;
    xml += `    <NormalizedNumber><![CDATA[${item.normalizedNumber}]]></NormalizedNumber>\n`;
    xml += `    <Category>${item.category}</Category>\n`;
    xml += `    <CategoryLabel>${escapeHtml(getCategoryLabel(item.category))}</CategoryLabel>\n`;
    xml += `    <Label><![CDATA[${item.label || ''}]]></Label>\n`;
    xml += `    <EntityName><![CDATA[${item.entityName || ''}]]></EntityName>\n`;
    xml += `    <FileName><![CDATA[${item.fileName}]]></FileName>\n`;
    xml += `    <PageNumber>${item.pageNumber}</PageNumber>\n`;
    xml += `    <Context><![CDATA[${item.context}]]></Context>\n`;
    xml += `  </Record>\n`;
  });

  xml += `</PdfNumberExtraction>\n`;
  return xml;
}

export function exportToXml(
  items: ExtractedNumber[],
  filename: string = 'Ekstraksi_Nomor_PDF.xml'
): void {
  const content = generateXmlString(items);
  const blob = new Blob([content], { type: 'application/xml;charset=utf-8;' });
  triggerDownload(blob, filename.endsWith('.xml') ? filename : `${filename}.xml`);
}

