import { PDFDocument } from 'pdf-lib';
import { pdfMemoryCache } from './pdfParser';
import { ExtractedNumber, PdfFileInfo } from '../types';

export async function extractPdfPagesFromNumbers(
  selectedItems: ExtractedNumber[],
  files: PdfFileInfo[]
): Promise<{ success: boolean; message: string }> {
  try {
    // 1. Group selected items by fileId and collect unique page numbers
    const filePageMap = new Map<string, Set<number>>();
    
    for (const item of selectedItems) {
      if (!filePageMap.has(item.fileId)) {
        filePageMap.set(item.fileId, new Set<number>());
      }
      filePageMap.get(item.fileId)!.add(item.pageNumber);
    }
    
    if (filePageMap.size === 0) {
      return { success: false, message: 'Tidak ada data valid yang dipilih.' };
    }

    // Create a new empty PDF
    const newPdfDoc = await PDFDocument.create();
    let pagesCopied = 0;

    // 2. Iterate over each required file
    for (const [fileId, pagesSet] of filePageMap.entries()) {
      const arrayBuffer = pdfMemoryCache.get(fileId);
      const fileInfo = files.find(f => f.id === fileId);
      
      if (!arrayBuffer) {
        return { 
          success: false, 
          message: `Gagal: File "${fileInfo?.name || fileId}" tidak ada dalam memori sesi. Silakan unggah ulang file tersebut jika baru saja memuat ulang halaman.` 
        };
      }

      // Load original PDF
      const srcPdf = await PDFDocument.load(arrayBuffer);
      
      // Convert page numbers (1-indexed) to indices (0-indexed)
      // and sort them to maintain sequential order
      const pageIndices = Array.from(pagesSet)
        .map(pageNum => pageNum - 1)
        .filter(idx => idx >= 0 && idx < srcPdf.getPageCount())
        .sort((a, b) => a - b);
      
      if (pageIndices.length === 0) continue;

      // Copy pages to the new document
      const copiedPages = await newPdfDoc.copyPages(srcPdf, pageIndices);
      copiedPages.forEach(page => newPdfDoc.addPage(page));
      pagesCopied += copiedPages.length;
    }

    if (pagesCopied === 0) {
      return { success: false, message: 'Tidak ada halaman yang berhasil disalin.' };
    }

    // 3. Serialize and Download
    const pdfBytes = await newPdfDoc.save();
    const blob = new Blob([pdfBytes], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `Extracted_Pages_${Date.now()}.pdf`;
    document.body.appendChild(link);
    link.click();
    
    // Cleanup
    setTimeout(() => {
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }, 100);

    return { success: true, message: `Berhasil mengekstrak ${pagesCopied} halaman ke file PDF baru.` };
  } catch (error) {
    console.error('Error extracting PDF pages:', error);
    return { success: false, message: 'Terjadi kesalahan sistem saat mengekstrak halaman PDF.' };
  }
}
