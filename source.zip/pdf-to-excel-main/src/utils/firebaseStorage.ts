import { db, collection, doc, setDoc, getDocs, writeBatch } from '../firebase';
import { PdfFileInfo, ExtractedNumber } from '../types';

export const syncToCloud = async (
  userId: string,
  files: PdfFileInfo[],
  numbers: ExtractedNumber[]
): Promise<{ success: boolean; message: string }> => {
  try {
    const batch = writeBatch(db);
    
    // Save files
    files.forEach(file => {
      const fileRef = doc(db, 'users', userId, 'files', file.id);
      batch.set(fileRef, file);
    });

    // Save extracted numbers
    numbers.forEach(num => {
      const numRef = doc(db, 'users', userId, 'extracted_numbers', num.id);
      batch.set(numRef, num);
    });

    await batch.commit();
    return { success: true, message: `Berhasil sinkronisasi ${files.length} file dan ${numbers.length} data ke Cloud.` };
  } catch (error: any) {
    console.error('Error syncing to cloud:', error);
    return { success: false, message: 'Gagal sinkronisasi ke Cloud: ' + error.message };
  }
};

export const loadFromCloud = async (
  userId: string
): Promise<{ success: boolean; files: PdfFileInfo[]; numbers: ExtractedNumber[]; message: string }> => {
  try {
    const filesRef = collection(db, 'users', userId, 'files');
    const numbersRef = collection(db, 'users', userId, 'extracted_numbers');

    const [filesSnapshot, numbersSnapshot] = await Promise.all([
      getDocs(filesRef),
      getDocs(numbersRef)
    ]);

    const files: PdfFileInfo[] = [];
    filesSnapshot.forEach(doc => {
      files.push(doc.data() as PdfFileInfo);
    });

    const numbers: ExtractedNumber[] = [];
    numbersSnapshot.forEach(doc => {
      numbers.push(doc.data() as ExtractedNumber);
    });

    return { 
      success: true, 
      files, 
      numbers, 
      message: `Berhasil memuat ${files.length} file dan ${numbers.length} data dari Cloud.` 
    };
  } catch (error: any) {
    console.error('Error loading from cloud:', error);
    return { success: false, files: [], numbers: [], message: 'Gagal memuat dari Cloud: ' + error.message };
  }
};
