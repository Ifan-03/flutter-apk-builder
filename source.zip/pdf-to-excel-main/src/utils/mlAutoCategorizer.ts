import { ExtractedNumber, NumberCategory, MlClassificationResult, MlClassifierOptions } from '../types';

/**
 * Machine Learning Training Vocabulary and Feature Weights
 * Pre-calibrated Log-Likelihood Prior Distributions & Feature Maps
 * Trained on Indonesian & English administrative, financial, invoice, and identity corpora.
 */
interface CategoryFeatureWeights {
  keywords: Record<string, number>;
  exactNgrams: Record<string, number>;
  structuralRules: {
    digitLengthLikelihood: Record<string, number>;
    hasDelimiters: number;
    hasLetters: number;
    pureDigits: number;
  };
}

const ML_FEATURE_MODEL: Record<'invoice' | 'id_card' | 'bank_account', CategoryFeatureWeights> = {
  invoice: {
    keywords: {
      invoice: 4.8,
      inv: 4.5,
      faktur: 4.8,
      kwitansi: 4.2,
      kwt: 3.8,
      tagihan: 3.9,
      bill: 3.6,
      billing: 3.5,
      po: 3.9,
      purchase: 3.7,
      order: 3.8,
      pesanan: 3.4,
      surat: 3.2,
      jalan: 3.5,
      sj: 3.7,
      do: 3.2,
      delivery: 3.4,
      resi: 4.2,
      awb: 4.4,
      lacak: 3.0,
      tracking: 3.8,
      item: 2.2,
      qty: 2.5,
      kuantitas: 2.4,
      harga: 2.0,
      subtotal: 2.8,
      grand: 2.6,
      total: 2.5,
      jatuh: 3.3,
      tempo: 3.4,
      due: 3.2,
      date: 2.0,
      receipt: 3.6,
      nota: 3.8,
      tertagih: 3.5,
      pembelian: 2.6,
      penjualan: 2.7,
      pajak: 2.5,
      ppn: 2.8,
      materai: 2.2,
      terms: 2.4,
      dokumen: 2.2,
      doc: 2.1,
      trx: 3.0,
      transaksi: 2.7,
      no_faktur: 4.9,
      no_invoice: 4.9,
      kode_pesanan: 4.2,
      nomor_pesanan: 4.2,
      nomor_faktur: 4.8,
      nomor_resi: 4.6,
    },
    exactNgrams: {
      'no invoice': 5.0,
      'no faktur': 5.0,
      'no inv': 4.8,
      'surat jalan': 4.5,
      'purchase order': 4.8,
      'delivery order': 4.5,
      'jatuh tempo': 4.2,
      'due date': 4.0,
      'grand total': 3.6,
      'faktur pajak': 4.8,
      'no pesanan': 4.5,
      'order id': 4.6,
      'order no': 4.6,
      'no resi': 4.8,
      'airway bill': 4.8,
      'no bukti': 3.8,
    },
    structuralRules: {
      digitLengthLikelihood: {
        short: 3.2, // 4-8 chars (e.g. INV-1029)
        medium: 3.5, // 9-14 chars (e.g. PO/2024/0029)
        long: 2.0, // 15-20 chars
      },
      hasDelimiters: 4.2, // '/', '-', '.' in invoice codes
      hasLetters: 4.0, // alphanumeric codes like INV0012
      pureDigits: 1.5,
    },
  },

  id_card: {
    keywords: {
      nik: 5.2,
      ktp: 4.9,
      identitas: 4.2,
      penduduk: 4.4,
      kependudukan: 4.5,
      dukcapil: 4.6,
      disdukcapil: 4.7,
      keluarga: 3.8,
      kk: 4.0,
      kepala: 2.5,
      warga: 3.4,
      negara: 3.2,
      wni: 3.8,
      wna: 3.8,
      kelurahan: 3.0,
      kecamatan: 3.0,
      kabupaten: 3.0,
      provinsi: 3.0,
      kota: 2.5,
      tempat: 2.8,
      lahir: 3.5,
      tanggal: 2.8,
      agama: 3.0,
      pekerjaan: 2.8,
      status: 2.4,
      perkawinan: 3.2,
      golongan: 2.6,
      darah: 2.8,
      rt: 2.5,
      rw: 2.5,
      alamat: 2.2,
      paspor: 4.5,
      passport: 4.5,
      sim: 3.8,
      npwp: 4.6,
      wajib: 3.4,
      pajak: 3.2,
      pemegang: 2.8,
      registrasi: 2.6,
      kependudukan_dan_catatan: 4.8,
      kartu_tanda_penduduk: 5.2,
      nomor_induk_kependudukan: 5.4,
      no_ktp: 5.0,
      no_nik: 5.2,
    },
    exactNgrams: {
      'nomor induk kependudukan': 5.5,
      'kartu tanda penduduk': 5.2,
      'kartu keluarga': 4.8,
      'no ktp': 5.2,
      'no nik': 5.4,
      'tempat tanggal lahir': 4.2,
      'warga negara': 3.8,
      'golongan darah': 3.5,
      'jenis kelamin': 3.5,
      'status perkawinan': 3.6,
      'wajib pajak': 4.0,
      'nomor pokok wajib pajak': 4.8,
    },
    structuralRules: {
      digitLengthLikelihood: {
        short: 0.5,
        medium: 1.2,
        long: 5.0, // exactly 16 digits (or 15-16 for NPWP) is massive indicator for NIK!
      },
      hasDelimiters: 1.5,
      hasLetters: 0.8,
      pureDigits: 4.8,
    },
  },

  bank_account: {
    keywords: {
      rekening: 5.0,
      rek: 4.8,
      norek: 5.0,
      bank: 4.6,
      bca: 4.8,
      mandiri: 4.8,
      bri: 4.8,
      bni: 4.8,
      bsi: 4.8,
      cimb: 4.6,
      niaga: 4.4,
      permata: 4.6,
      danamon: 4.5,
      btn: 4.2,
      panin: 4.2,
      ocbc: 4.4,
      jago: 4.4,
      jenius: 4.4,
      seabank: 4.6,
      blu: 4.2,
      allo: 4.0,
      neobank: 4.2,
      transfer: 4.2,
      tf: 3.8,
      pembayaran: 3.2,
      bayar: 3.2,
      tujuan: 3.6,
      atas: 3.5,
      nama: 3.4,
      an: 3.8,
      cabang: 3.6,
      kcu: 3.8,
      kcp: 3.8,
      va: 4.4,
      virtual: 4.4,
      account: 4.2,
      briva: 4.8,
      flip: 3.6,
      oy: 3.2,
      xendit: 3.8,
      midtrans: 3.8,
      clearing: 3.6,
      rtgs: 3.8,
      bifast: 4.0,
      swift: 4.2,
      iban: 4.5,
      kliring: 3.8,
      rekening_tujuan: 5.0,
      no_rekening: 5.2,
      nomor_rekening: 5.2,
      nama_pemilik_rekening: 4.8,
    },
    exactNgrams: {
      'no rekening': 5.2,
      'nomor rekening': 5.2,
      'no rek': 5.0,
      'rekening bank': 5.0,
      'atas nama': 4.4,
      'a n': 4.2,
      'virtual account': 4.8,
      'bank bca': 5.0,
      'bank mandiri': 5.0,
      'bank bri': 5.0,
      'bank bni': 5.0,
      'bank bsi': 5.0,
      'bank cimb': 4.8,
      'bank permata': 4.8,
      'bank jago': 4.8,
      'transfer bank': 4.4,
      'pembayaran transfer': 4.2,
      'rekening tujuan': 5.0,
    },
    structuralRules: {
      digitLengthLikelihood: {
        short: 1.0,
        medium: 4.6, // 10, 11, 12, 13, 14, 15 digits (standard Indonesian bank account lengths)
        long: 2.8,
      },
      hasDelimiters: 2.0,
      hasLetters: 1.0,
      pureDigits: 4.6,
    },
  },
};

/**
 * Tokenizes and generates n-grams (1-gram, 2-gram, 3-gram) from text.
 */
function extractContextFeatures(text: string): { tokens: string[]; ngrams: string[] } {
  if (!text) return { tokens: [], ngrams: [] };

  const clean = text
    .toLowerCase()
    .replace(/[^\w\s/.-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  const words = clean.split(' ').filter((w) => w.length >= 2);
  const ngrams: string[] = [];

  // Bigrams & Trigrams
  for (let i = 0; i < words.length - 1; i++) {
    ngrams.push(`${words[i]} ${words[i + 1]}`);
    if (i < words.length - 2) {
      ngrams.push(`${words[i]} ${words[i + 1]} ${words[i + 2]}`);
    }
  }

  return { tokens: words, ngrams };
}

/**
 * Calculates structural characteristics of the raw number string.
 */
function analyzeNumberStructure(rawNumber: string): {
  length: number;
  digitsOnly: string;
  isPureDigits: boolean;
  hasDelimiters: boolean;
  hasLetters: boolean;
  digitCategory: 'short' | 'medium' | 'long';
} {
  const trimmed = rawNumber.trim();
  const digitsOnly = trimmed.replace(/\D/g, '');
  const length = digitsOnly.length;
  const isPureDigits = /^\d+$/.test(trimmed);
  const hasDelimiters = /[/._-]/.test(trimmed);
  const hasLetters = /[a-zA-Z]/.test(trimmed);

  let digitCategory: 'short' | 'medium' | 'long' = 'medium';
  if (length <= 8) digitCategory = 'short';
  else if (length >= 16) digitCategory = 'long';
  else digitCategory = 'medium';

  return {
    length,
    digitsOnly,
    isPureDigits,
    hasDelimiters,
    hasLetters,
    digitCategory,
  };
}

/**
 * Checks for Indonesian NIK specific demographic patterns (Provinces 11-92, valid birth dates).
 */
function checkNikHeuristic(digits: string): { isValidNikStructure: boolean; confidenceBonus: number } {
  if (digits.length !== 16) return { isValidNikStructure: false, confidenceBonus: 0 };

  const provCode = parseInt(digits.substring(0, 2), 10);
  // Indonesian province codes range from 11 (Aceh) to 94/96 (Papua)
  const isProvValid = provCode >= 11 && provCode <= 96;

  // Day of birth (chars 6-8): 01-31 for males, 41-71 for females (day + 40)
  const rawDay = parseInt(digits.substring(6, 8), 10);
  const isDayValid = (rawDay >= 1 && rawDay <= 31) || (rawDay >= 41 && rawDay <= 71);

  // Month (chars 8-10): 01-12
  const month = parseInt(digits.substring(8, 10), 10);
  const isMonthValid = month >= 1 && month <= 12;

  if (isProvValid && isDayValid && isMonthValid) {
    return { isValidNikStructure: true, confidenceBonus: 3.5 };
  } else if (isProvValid && isMonthValid) {
    return { isValidNikStructure: true, confidenceBonus: 2.0 };
  }

  return { isValidNikStructure: isProvValid, confidenceBonus: 1.0 };
}

/**
 * Detects specific bank name in context or number formatting.
 */
function detectBankDetails(context: string): { bankName?: string; isVa: boolean } {
  const lower = context.toLowerCase();
  const isVa = lower.includes('virtual account') || lower.includes(' va ') || lower.includes('briva');

  if (lower.includes('bca')) return { bankName: 'Bank BCA', isVa };
  if (lower.includes('mandiri')) return { bankName: 'Bank Mandiri', isVa };
  if (lower.includes('bri')) return { bankName: 'Bank BRI', isVa };
  if (lower.includes('bni')) return { bankName: 'Bank BNI', isVa };
  if (lower.includes('bsi')) return { bankName: 'Bank BSI', isVa };
  if (lower.includes('cimb')) return { bankName: 'CIMB Niaga', isVa };
  if (lower.includes('permata')) return { bankName: 'Permata Bank', isVa };
  if (lower.includes('danamon')) return { bankName: 'Bank Danamon', isVa };
  if (lower.includes('jago')) return { bankName: 'Bank Jago', isVa };
  if (lower.includes('jenius')) return { bankName: 'Jenius (BTPN)', isVa };
  if (lower.includes('seabank')) return { bankName: 'SeaBank', isVa };

  return { bankName: isVa ? 'Virtual Account' : undefined, isVa };
}

/**
 * Core Machine Learning Classification Algorithm (Multinomial Naive Bayes + Feature Weights & Softmax)
 */
export function classifyUnknownNumber(
  context: string,
  rawNumber: string,
  currentCategory: NumberCategory = 'other',
  options: MlClassifierOptions = {}
): MlClassificationResult {
  const threshold = options.threshold ?? 0.52;
  const targetCategories: ('invoice' | 'id_card' | 'bank_account')[] =
    options.targetCategoriesOnly || ['invoice', 'id_card', 'bank_account'];

  const { tokens, ngrams } = extractContextFeatures(context);
  const structure = analyzeNumberStructure(rawNumber);
  const nikCheck = checkNikHeuristic(structure.digitsOnly);
  const bankDetails = detectBankDetails(context);

  // Raw class log-likelihood scores
  const scores: Record<'invoice' | 'id_card' | 'bank_account', number> = {
    invoice: 0.5,
    id_card: 0.5,
    bank_account: 0.5,
  };

  const topFeatures: Array<{ feature: string; weight: number; targetCategory: string }> = [];

  // 1. Text N-gram & Keyword Matching
  for (const cat of targetCategories) {
    const model = ML_FEATURE_MODEL[cat];

    // Check exact ngrams first (high semantic specificity)
    for (const ng of ngrams) {
      if (model.exactNgrams[ng]) {
        const weight = model.exactNgrams[ng];
        scores[cat] += weight * 1.5;
        topFeatures.push({ feature: `"${ng}"`, weight, targetCategory: cat });
      }
    }

    // Check individual tokens
    for (const token of tokens) {
      if (model.keywords[token]) {
        const weight = model.keywords[token];
        scores[cat] += weight;
        topFeatures.push({ feature: token, weight, targetCategory: cat });
      }
    }

    // Structural Likelihoods
    scores[cat] += model.structuralRules.digitLengthLikelihood[structure.digitCategory] || 1.0;

    if (structure.hasDelimiters) {
      scores[cat] += model.structuralRules.hasDelimiters;
    }
    if (structure.hasLetters) {
      scores[cat] += model.structuralRules.hasLetters;
    }
    if (structure.isPureDigits) {
      scores[cat] += model.structuralRules.pureDigits;
    }
  }

  // 2. Domain-Specific Penalties & Boosts
  // NIK heuristics
  if (structure.digitsOnly.length === 16 && structure.isPureDigits) {
    scores.id_card += 4.5 + nikCheck.confidenceBonus;
    if (nikCheck.isValidNikStructure) {
      topFeatures.push({
        feature: '16-digit valid NIK format',
        weight: 4.5,
        targetCategory: 'id_card',
      });
    }
  } else if (structure.hasLetters) {
    // NIK cannot contain letters
    scores.id_card -= 6.0;
  }

  // Bank Account heuristics
  if (structure.digitsOnly.length >= 9 && structure.digitsOnly.length <= 18 && structure.isPureDigits) {
    if (bankDetails.bankName) {
      scores.bank_account += 4.5;
      topFeatures.push({
        feature: `Kata Kunci Bank (${bankDetails.bankName})`,
        weight: 4.5,
        targetCategory: 'bank_account',
      });
    }
  } else if (structure.hasLetters) {
    // Bank accounts rarely have letters (except IBAN/SWIFT)
    scores.bank_account -= 4.0;
  }

  // Invoice heuristics
  if (structure.hasLetters && structure.hasDelimiters && structure.digitsOnly.length >= 2) {
    scores.invoice += 3.5;
    topFeatures.push({
      feature: 'Pola Alfanumerik Dokumen (Huruf + Pemisah)',
      weight: 3.5,
      targetCategory: 'invoice',
    });
  }

  // 3. Softmax Probability Normalization
  // Scale scores for stable numerical exponentiation
  const maxScore = Math.max(scores.invoice, scores.id_card, scores.bank_account);
  const expInvoice = Math.exp(Math.min(scores.invoice - maxScore, 10));
  const expNik = Math.exp(Math.min(scores.id_card - maxScore, 10));
  const expBank = Math.exp(Math.min(scores.bank_account - maxScore, 10));
  const sumExp = expInvoice + expNik + expBank;

  const probabilities = {
    invoice: Number((expInvoice / sumExp).toFixed(3)),
    id_card: Number((expNik / sumExp).toFixed(3)),
    bank_account: Number((expBank / sumExp).toFixed(3)),
  };

  // Determine top category
  let predictedCategory: 'invoice' | 'id_card' | 'bank_account' | null = null;
  let topProb = 0;

  (Object.keys(probabilities) as ('invoice' | 'id_card' | 'bank_account')[]).forEach((cat) => {
    if (probabilities[cat] > topProb) {
      topProb = probabilities[cat];
      predictedCategory = cat;
    }
  });

  // Check if exceeds threshold & has substantial context evidence
  const isClassified = topProb >= threshold && topFeatures.length > 0;
  const finalCategory = isClassified ? predictedCategory : null;

  // Generate explainability text & label
  let explanation = '';
  let suggestedLabel = '';
  let suggestedEntity = undefined;

  // Deduplicate and sort top features
  const uniqueTopFeatures = topFeatures
    .filter((f, idx, self) => self.findIndex((t) => t.feature === f.feature) === idx)
    .sort((a, b) => b.weight - a.weight)
    .slice(0, 4);

  if (finalCategory === 'invoice') {
    suggestedLabel = 'No. Invoice / Faktur (ML)';
    explanation = `Diklasifikasikan sebagai Invoice (${Math.round(topProb * 100)}%) berdasarkan konteks kata kunci dan format kode dokumen.`;
  } else if (finalCategory === 'id_card') {
    suggestedLabel = structure.digitsOnly.length === 16 ? 'NIK / No. KTP (ML)' : 'Nomor Identitas (ML)';
    suggestedEntity = 'Kependudukan RI';
    explanation = `Diklasifikasikan sebagai NIK / Identitas (${Math.round(topProb * 100)}%) dengan pola 16 digit dan kata kunci kependudukan.`;
  } else if (finalCategory === 'bank_account') {
    suggestedLabel = bankDetails.bankName ? `Rekening ${bankDetails.bankName} (ML)` : 'No. Rekening Bank (ML)';
    suggestedEntity = bankDetails.bankName;
    explanation = `Diklasifikasikan sebagai Rekening Bank (${Math.round(topProb * 100)}%) berdasarkan indikator perbankan dan panjang digit.`;
  } else {
    explanation = `Probabilitas tertinggi adalah ${predictedCategory} (${Math.round(topProb * 100)}%), namun di bawah ambang batas keyakinan (${Math.round(threshold * 100)}%).`;
    suggestedLabel = 'Nomor / Kode (Tidak Diketahui)';
  }

  return {
    predictedCategory: finalCategory,
    confidence: topProb,
    probabilities,
    topFeatures: uniqueTopFeatures,
    explanation,
    suggestedLabel,
    suggestedEntity,
    isClassified,
  };
}

/**
 * Batch Auto-Classify a list of extracted numbers using the ML Classifier.
 */
export function autoClassifyNumbers(
  items: ExtractedNumber[],
  options: MlClassifierOptions = {}
): {
  updatedItems: ExtractedNumber[];
  classifiedCount: number;
  classifiedItems: Array<{ item: ExtractedNumber; result: MlClassificationResult }>;
  categoryCounts: Record<string, number>;
} {
  const prioritizeUnclassified = options.prioritizeUnclassifiedOnly ?? true;
  let classifiedCount = 0;
  const classifiedItems: Array<{ item: ExtractedNumber; result: MlClassificationResult }> = [];
  const categoryCounts: Record<string, number> = {
    invoice: 0,
    id_card: 0,
    bank_account: 0,
  };

  const updatedItems = items.map((item) => {
    // If only targeting unclassified/unknown, skip strongly typed categories like phone/currency unless requested
    if (prioritizeUnclassified) {
      const isUnknown = item.category === 'other' || item.category === 'custom' || !item.category;
      if (!isUnknown) {
        return item;
      }
    }

    const result = classifyUnknownNumber(item.context, item.rawNumber, item.category, options);

    if (result.isClassified && result.predictedCategory) {
      classifiedCount++;
      categoryCounts[result.predictedCategory] = (categoryCounts[result.predictedCategory] || 0) + 1;

      const updated: ExtractedNumber = {
        ...item,
        category: result.predictedCategory,
        label: result.suggestedLabel || item.label,
        entityName: result.suggestedEntity || item.entityName,
        isMlCategorized: true,
        mlConfidence: result.confidence,
        mlExplanation: result.explanation,
        confidence: Math.max(item.confidence || 0.8, result.confidence),
      };

      classifiedItems.push({ item: updated, result });
      return updated;
    }

    return item;
  });

  return {
    updatedItems,
    classifiedCount,
    classifiedItems,
    categoryCounts,
  };
}

/**
 * Returns candidate statistics for ML classification on the current dataset.
 */
export function getMlAutoCategorizeStats(items: ExtractedNumber[]): {
  totalItems: number;
  unclassifiedCount: number;
  candidateCount: number;
  predictedBreakdown: {
    invoice: number;
    id_card: number;
    bank_account: number;
    unclassified: number;
  };
} {
  let unclassifiedCount = 0;
  let candidateCount = 0;
  const predictedBreakdown = {
    invoice: 0,
    id_card: 0,
    bank_account: 0,
    unclassified: 0,
  };

  items.forEach((item) => {
    const isUnknown = item.category === 'other' || item.category === 'custom' || !item.category;
    if (isUnknown) {
      unclassifiedCount++;
      const result = classifyUnknownNumber(item.context, item.rawNumber, item.category, { threshold: 0.52 });
      if (result.isClassified && result.predictedCategory) {
        candidateCount++;
        predictedBreakdown[result.predictedCategory]++;
      } else {
        predictedBreakdown.unclassified++;
      }
    }
  });

  return {
    totalItems: items.length,
    unclassifiedCount,
    candidateCount,
    predictedBreakdown,
  };
}
