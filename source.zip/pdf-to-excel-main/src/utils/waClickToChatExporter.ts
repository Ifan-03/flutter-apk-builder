import { ExtractedNumber } from '../types';
import { normalizePhoneNumber } from './numberExtractor';

export interface WaChatContact {
  id: string;
  name: string;
  phone: string;
  formattedPhone: string;
  rawNumber: string;
  category: string;
  fileName: string;
  pageNumber: number;
  context?: string;
  waLink: string;
}

/**
 * Filter and prepare phone number items for WhatsApp click-to-chat
 */
export function prepareWaContacts(
  items: ExtractedNumber[],
  customMessage: string = ''
): WaChatContact[] {
  const seen = new Set<string>();
  const results: WaChatContact[] = [];

  items.forEach((item) => {
    // Only include phone items or valid digit sequences (9-15 digits)
    const digitsOnly = item.rawNumber.replace(/\D/g, '');
    const isPhoneCategory = item.category === 'phone';
    const isLikelyPhone = digitsOnly.length >= 9 && digitsOnly.length <= 15;

    if (!isPhoneCategory && !isLikelyPhone) {
      return;
    }

    const cleanE164 = normalizePhoneNumber(item.rawNumber, 'e164_noplus');
    if (!cleanE164 || cleanE164.length < 8) return;

    if (seen.has(cleanE164)) return;
    seen.add(cleanE164);

    const baseUrl = `https://wa.me/${cleanE164}`;
    const waLink = customMessage.trim()
      ? `${baseUrl}?text=${encodeURIComponent(customMessage.trim())}`
      : baseUrl;

    const formattedPhone = normalizePhoneNumber(item.rawNumber, 'e164_plus');
    const name = item.entityName || item.label || 'Kontak WhatsApp';

    results.push({
      id: item.id,
      name,
      phone: cleanE164,
      formattedPhone,
      rawNumber: item.rawNumber,
      category: item.category,
      fileName: item.fileName,
      pageNumber: item.pageNumber,
      context: item.context,
      waLink,
    });
  });

  return results;
}

/**
 * Generates a single self-contained shareable data:text/html or app link
 * or a batch click-to-chat HTML file containing all click-to-chat links, direct launch actions,
 * batch open features, search filters, and individual QR codes.
 */
export function generateBatchWaClickToChatHtml(
  contacts: WaChatContact[],
  title: string = 'Daftar WhatsApp Click-to-Chat',
  customMessage: string = ''
): string {
  const generatedTime = new Date().toLocaleString('id-ID', {
    dateStyle: 'medium',
    timeStyle: 'short',
  });

  const cardsJson = JSON.stringify(
    contacts.map((c, idx) => ({
      idx: idx + 1,
      name: c.name,
      phone: c.phone,
      formattedPhone: c.formattedPhone,
      fileName: c.fileName,
      page: c.pageNumber,
      context: c.context || '',
      link: c.waLink,
    }))
  );

  return `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title} (${contacts.length} Kontak)</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;600&display=swap" rel="stylesheet">
  <style>
    :root {
      --wa-green: #25D366;
      --wa-dark: #128C7E;
      --wa-hover: #1EBE5D;
      --slate-900: #0f172a;
      --slate-800: #1e293b;
      --slate-700: #334155;
      --slate-600: #475569;
      --slate-500: #64748b;
      --slate-400: #94a3b8;
      --slate-200: #e2e8f0;
      --slate-100: #f1f5f9;
      --slate-50: #f8fafc;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background-color: #f1f5f9;
      color: var(--slate-900);
      min-height: 100vh;
      padding-bottom: 60px;
    }
    .header {
      background: linear-gradient(135deg, #075e54 0%, #128c7e 50%, #25d366 100%);
      color: #ffffff;
      padding: 36px 20px;
      box-shadow: 0 4px 20px -2px rgba(7, 94, 84, 0.25);
    }
    .header-content {
      max-width: 1000px;
      margin: 0 auto;
    }
    .badge-pill {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: rgba(255, 255, 255, 0.2);
      backdrop-filter: blur(8px);
      padding: 4px 12px;
      border-radius: 9999px;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.5px;
      text-transform: uppercase;
      margin-bottom: 12px;
    }
    .title {
      font-size: 26px;
      font-weight: 800;
      letter-spacing: -0.5px;
      margin-bottom: 8px;
    }
    .subtitle {
      font-size: 13.5px;
      color: rgba(255, 255, 255, 0.9);
      max-width: 700px;
      line-height: 1.5;
    }
    .container {
      max-width: 1000px;
      margin: -24px auto 0;
      padding: 0 16px;
    }
    .toolbar-card {
      background: #ffffff;
      border-radius: 16px;
      padding: 16px 20px;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.01);
      border: 1px solid var(--slate-200);
      margin-bottom: 24px;
      display: flex;
      flex-direction: column;
      gap: 14px;
    }
    .toolbar-top {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
    }
    .search-box {
      flex: 1;
      min-width: 240px;
      position: relative;
    }
    .search-input {
      width: 100%;
      padding: 10px 14px 10px 38px;
      font-size: 13px;
      border: 1px solid var(--slate-200);
      border-radius: 10px;
      background: var(--slate-50);
      outline: none;
      transition: all 0.2s;
    }
    .search-input:focus {
      border-color: var(--wa-green);
      background: #ffffff;
      box-shadow: 0 0 0 3px rgba(37, 211, 102, 0.15);
    }
    .search-icon {
      position: absolute;
      left: 12px;
      top: 50%;
      transform: translateY(-50%);
      color: var(--slate-400);
      pointer-events: none;
    }
    .btn-group {
      display: flex;
      align-items: center;
      gap: 8px;
      flex-wrap: wrap;
    }
    .btn {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 8px 14px;
      border-radius: 8px;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      border: none;
      transition: all 0.15s;
      text-decoration: none;
    }
    .btn-primary {
      background: var(--wa-green);
      color: #ffffff;
    }
    .btn-primary:hover {
      background: var(--wa-hover);
      transform: translateY(-1px);
      box-shadow: 0 4px 12px rgba(37, 211, 102, 0.3);
    }
    .btn-secondary {
      background: var(--slate-100);
      color: var(--slate-700);
    }
    .btn-secondary:hover {
      background: var(--slate-200);
    }
    .msg-preview-bar {
      background: #f0fdf4;
      border: 1px dashed #86efac;
      padding: 10px 14px;
      border-radius: 8px;
      font-size: 12px;
      color: #166534;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
    }
    .msg-preview-text {
      font-style: italic;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .stats-bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 12px;
      color: var(--slate-500);
      padding: 0 4px;
      margin-bottom: 12px;
    }
    .cards-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 16px;
    }
    .contact-card {
      background: #ffffff;
      border-radius: 14px;
      border: 1px solid var(--slate-200);
      padding: 16px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      transition: all 0.2s;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.02);
    }
    .contact-card:hover {
      border-color: #86efac;
      transform: translateY(-2px);
      box-shadow: 0 8px 20px -4px rgba(37, 211, 102, 0.12);
    }
    .card-top {
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      margin-bottom: 10px;
    }
    .contact-idx {
      font-family: 'JetBrains Mono', monospace;
      font-size: 10.5px;
      font-weight: 700;
      background: var(--slate-100);
      color: var(--slate-600);
      padding: 2px 8px;
      border-radius: 6px;
    }
    .file-meta {
      font-size: 10px;
      color: var(--slate-400);
      text-align: right;
    }
    .contact-name {
      font-size: 14.5px;
      font-weight: 700;
      color: var(--slate-900);
      margin-bottom: 4px;
      word-break: break-word;
    }
    .contact-phone {
      font-family: 'JetBrains Mono', monospace;
      font-size: 13px;
      font-weight: 700;
      color: #047857;
      margin-bottom: 8px;
      display: inline-block;
    }
    .contact-context {
      font-size: 11px;
      color: var(--slate-500);
      background: var(--slate-50);
      padding: 6px 10px;
      border-radius: 6px;
      border: 1px solid var(--slate-100);
      margin-bottom: 14px;
      line-height: 1.4;
      max-height: 48px;
      overflow: hidden;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
    }
    .card-actions {
      display: grid;
      grid-template-columns: 1fr auto auto;
      gap: 6px;
      padding-top: 10px;
      border-top: 1px solid var(--slate-100);
    }
    .btn-chat {
      background: var(--wa-green);
      color: #ffffff;
      font-size: 11.5px;
      font-weight: 700;
      padding: 8px 12px;
      border-radius: 8px;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      transition: background 0.15s;
    }
    .btn-chat:hover {
      background: var(--wa-hover);
    }
    .btn-icon {
      background: var(--slate-100);
      color: var(--slate-700);
      border: none;
      border-radius: 8px;
      padding: 8px 10px;
      cursor: pointer;
      font-size: 11px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      transition: all 0.15s;
    }
    .btn-icon:hover {
      background: var(--slate-200);
    }
    .btn-icon.copied {
      background: #dcfce7;
      color: #15803d;
    }
    .footer {
      text-align: center;
      margin-top: 40px;
      font-size: 11.5px;
      color: var(--slate-400);
    }
    /* QR Popup modal */
    .qr-modal-overlay {
      position: fixed;
      inset: 0;
      background: rgba(15, 23, 42, 0.6);
      backdrop-filter: blur(4px);
      display: none;
      align-items: center;
      justify-content: center;
      z-index: 999;
      padding: 16px;
    }
    .qr-modal-overlay.open {
      display: flex;
    }
    .qr-modal {
      background: #ffffff;
      border-radius: 16px;
      padding: 24px;
      max-width: 320px;
      width: 100%;
      text-align: center;
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.2);
    }
    .qr-modal h4 {
      font-size: 15px;
      font-weight: 700;
      margin-bottom: 4px;
    }
    .qr-modal p {
      font-size: 12px;
      color: var(--slate-500);
      margin-bottom: 16px;
    }
    .qr-box {
      background: #ffffff;
      padding: 12px;
      border-radius: 12px;
      border: 1px solid var(--slate-200);
      display: inline-block;
      margin-bottom: 16px;
    }
    @media (max-width: 640px) {
      .cards-grid { grid-template-columns: 1fr; }
      .header { padding: 24px 16px; }
      .title { font-size: 20px; }
    }
  </style>
</head>
<body>

  <header class="header">
    <div class="header-content">
      <div class="badge-pill">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
        WhatsApp Click-to-Chat Batch
      </div>
      <h1 class="title">${title}</h1>
      <p class="subtitle">Kumpulan tautan chat WhatsApp instan langsung ke nomor tujuan tanpa perlu menyimpan kontak di buku telepon. Dibuat pada ${generatedTime}.</p>
    </div>
  </header>

  <div class="container">
    <div class="toolbar-card">
      <div class="toolbar-top">
        <div class="search-box">
          <svg class="search-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
          <input type="text" id="searchInput" class="search-input" placeholder="Cari nama kontak, nomor HP, atau sumber file..." oninput="handleFilter()" />
        </div>

        <div class="btn-group">
          <button class="btn btn-secondary" onclick="copyAllLinks()" title="Salin semua tautan wa.me">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>
            <span id="copyAllLabel">Salin Semua Link</span>
          </button>
          <button class="btn btn-secondary" onclick="window.print()" title="Cetak daftar kontak ini">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect width="12" height="8" x="6" y="14"/></svg>
            <span>Cetak Halaman</span>
          </button>
        </div>
      </div>

      ${
        customMessage.trim()
          ? `
      <div class="msg-preview-bar">
        <span style="font-weight:700; shrink-0;">Pesan Awal:</span>
        <span class="msg-preview-text">"${customMessage.trim()}"</span>
      </div>`
          : ''
      }
    </div>

    <div class="stats-bar">
      <span>Menampilkan <strong id="visibleCount">${contacts.length}</strong> dari ${contacts.length} nomor WhatsApp</span>
      <span>Klik 'Buka Chat' untuk membuka percakapan di WhatsApp Web / App</span>
    </div>

    <div id="cardsGrid" class="cards-grid">
      <!-- Injected via JavaScript -->
    </div>

    <footer class="footer">
      Dibuat secara otomatis oleh PDF Number Extractor & Export Manager
    </footer>
  </div>

  <!-- QR Code Modal -->
  <div id="qrModal" class="qr-modal-overlay" onclick="closeQrModal(event)">
    <div class="qr-modal" onclick="event.stopPropagation()">
      <h4 id="qrModalName">Nama Kontak</h4>
      <p id="qrModalPhone">+62 812-3456-7890</p>
      <div class="qr-box">
        <img id="qrModalImg" src="" alt="QR Code" width="180" height="180" />
      </div>
      <div>
        <button class="btn btn-secondary" style="width:100%" onclick="closeQrModal()">Tutup</button>
      </div>
    </div>
  </div>

  <script>
    const contactsData = ${cardsJson};

    function renderCards(list) {
      const grid = document.getElementById('cardsGrid');
      if (list.length === 0) {
        grid.innerHTML = '<div style="grid-column: 1/-1; text-align:center; padding: 40px; color:#64748b; background:#fff; border-radius:12px; border:1px dashed #cbd5e1;">Tidak ada kontak yang cocok dengan pencarian Anda.</div>';
        document.getElementById('visibleCount').textContent = '0';
        return;
      }

      document.getElementById('visibleCount').textContent = list.length;
      grid.innerHTML = list.map(c => {
        const qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' + encodeURIComponent(c.link);
        return \`
          <div class="contact-card">
            <div>
              <div class="card-top">
                <span class="contact-idx">#\${c.idx}</span>
                <span class="file-meta">\${c.fileName} (Hal. \${c.page})</span>
              </div>
              <div class="contact-name">\${escapeHtml(c.name)}</div>
              <div class="contact-phone">\${c.formattedPhone}</div>
              \${c.context ? \`<div class="contact-context">"\${escapeHtml(c.context)}"</div>\` : ''}
            </div>

            <div class="card-actions">
              <a href="\${c.link}" target="_blank" rel="noopener noreferrer" class="btn-chat">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                Buka Chat
              </a>
              <button class="btn-icon" onclick="copySingleLink('\${c.link}', this)" title="Salin link wa.me">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>
              </button>
              <button class="btn-icon" onclick="showQrModal('\${escapeHtml(c.name)}', '\${c.formattedPhone}', '\${qrUrl}')" title="Tampilkan QR Code">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="5" height="5" x="3" y="3" rx="1"/><rect width="5" height="5" x="16" y="3" rx="1"/><rect width="5" height="5" x="3" y="16" rx="1"/><path d="M21 16h-3a2 2 0 0 0-2 2v3"/><path d="M21 21v.01"/><path d="M12 7v3a2 2 0 0 1-2 2H7"/><path d="M3 12h.01"/><path d="M12 3h.01"/><path d="M12 16v.01"/><path d="M16 12h1"/><path d="M21 12v.01"/><path d="M12 21v-1"/></svg>
              </button>
            </div>
          </div>
        \`;
      }).join('');
    }

    function escapeHtml(str) {
      return (str || '').replace(/[&<>"']/g, function(m) {
        return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m];
      });
    }

    function handleFilter() {
      const q = document.getElementById('searchInput').value.toLowerCase().trim();
      if (!q) {
        renderCards(contactsData);
        return;
      }
      const filtered = contactsData.filter(c => 
        c.name.toLowerCase().includes(q) ||
        c.phone.includes(q) ||
        c.formattedPhone.toLowerCase().includes(q) ||
        c.fileName.toLowerCase().includes(q) ||
        c.context.toLowerCase().includes(q)
      );
      renderCards(filtered);
    }

    function copySingleLink(url, btn) {
      navigator.clipboard.writeText(url);
      btn.classList.add('copied');
      const orig = btn.innerHTML;
      btn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>';
      setTimeout(() => {
        btn.classList.remove('copied');
        btn.innerHTML = orig;
      }, 1800);
    }

    function copyAllLinks() {
      const links = contactsData.map(c => c.name + ': ' + c.link).join('\\n');
      navigator.clipboard.writeText(links);
      const label = document.getElementById('copyAllLabel');
      label.textContent = 'Semua Link Tersalin!';
      setTimeout(() => {
        label.textContent = 'Salin Semua Link';
      }, 2000);
    }

    function showQrModal(name, phone, qrUrl) {
      document.getElementById('qrModalName').textContent = name;
      document.getElementById('qrModalPhone').textContent = phone;
      document.getElementById('qrModalImg').src = qrUrl;
      document.getElementById('qrModal').classList.add('open');
    }

    function closeQrModal() {
      document.getElementById('qrModal').classList.remove('open');
    }

    // Initial render
    renderCards(contactsData);
  </script>
</body>
</html>`;
}

/**
 * Creates a standalone Blob URL for the HTML file so users can either download
 * or open/share directly.
 */
export function exportBatchWaHtmlFile(
  items: ExtractedNumber[],
  filename: string = 'WhatsApp_Click_to_Chat',
  customMessage: string = ''
): { html: string; download: () => void; shareUrl: string } {
  const contacts = prepareWaContacts(items, customMessage);
  const html = generateBatchWaClickToChatHtml(contacts, filename, customMessage);
  const blob = new Blob([html], { type: 'text/html;charset=utf-8;' });
  const shareUrl = URL.createObjectURL(blob);

  const download = () => {
    const a = document.createElement('a');
    a.href = shareUrl;
    a.download = `${filename}_ClickToChat.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return { html, download, shareUrl };
}
